from pathlib import Path
import json, textwrap, subprocess, os, math
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/source-difficulty-check-ai-materials-20260510')
CHECKS = BASE/'checks'
CHECKS.mkdir(exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size)

def wrap(draw, text, fnt, max_w):
    out=[]
    for para in text.split('\n'):
        line=''
        for ch in para:
            test=line+ch
            if draw.textbbox((0,0), test, font=fnt)[2] <= max_w:
                line=test
            else:
                if line: out.append(line)
                line=ch
        if line: out.append(line)
    return out

# cover
W,H=1080,1920
img=Image.new('RGB',(W,H),'#0B1220')
d=ImageDraw.Draw(img)
# background cards
for i,(x,y,w,h,c) in enumerate([
    (80,170,920,260,'#1E3A8A'),(120,500,840,230,'#0F766E'),(120,780,840,230,'#7C2D12'),(120,1060,840,230,'#4C1D95')]):
    d.rounded_rectangle((x,y,x+w,y+h), radius=44, fill=c, outline='#FFFFFF', width=4)
# small material icons/cards
labels=['影片','文章','題目']
for i,l in enumerate(labels):
    x=150+i*260
    d.rounded_rectangle((x,1380,x+210,1545), radius=30, fill='#F8FAFC', outline='#38BDF8', width=5)
    d.text((x+105,1452), l, font=font(54), fill='#0F172A', anchor='mm')
d.text((540,220),'AI 找到一堆素材',font=font(64),fill='#E0F2FE',anchor='mm')
d.text((540,380),'但能直接上課嗎？',font=font(70),fill='#FFFFFF',anchor='mm')
d.text((540,615),'先過三關',font=font(92),fill='#FDE68A',anchor='mm')
for y,t in [(895,'來源能追嗎？'),(1175,'年級概念對嗎？')]:
    d.text((540,y),t,font=font(66),fill='#FFFFFF',anchor='mm')
d.text((540,1670),'素材要過濾',font=font(118),fill='#FFFFFF',anchor='mm',stroke_width=3,stroke_fill='#0B1220')
d.text((540,1805),'盧老師和 AI 夥伴',font=font(44),fill='#BAE6FD',anchor='mm')
img.save(BASE/'cover_source_difficulty_check_ai_materials_v1.png')

# VTT
cues=[
('00:00.000','00:05.000','AI 可以很快幫你找一堆影片、文章和題目。'),
('00:05.000','00:10.500','但素材很多，不代表適合這班學生。'),
('00:10.500','00:17.500','我會先問三件事：來源能不能追？年級概念對不對？難度能不能降一階？'),
('00:17.500','00:23.000','如果 AI 只給網址和摘要，我不會直接放進投影片。'),
('00:23.000','00:30.500','我會請它補上：適合哪個年級、會卡哪個迷思、老師要怎麼改。'),
('00:30.500','00:34.680','留言告訴我：你最怕 AI 推薦哪一種不適合的素材？'),
]
with open(BASE/'narration_35s_hsiaoyu.vtt','w',encoding='utf-8') as f:
    f.write('WEBVTT\n\n')
    for i,(a,b,t) in enumerate(cues,1):
        f.write(f'{i}\n{a} --> {b}\n{t}\n\n')

# concat file
slides=['slide_01_hook.png','slide_02_source.png','slide_03_grade.png','slide_04_difficulty.png','slide_05_cta.png']
durations=[5.0,5.5,7.0,7.0,10.18]
with open(BASE/'slides.ffconcat','w',encoding='utf-8') as f:
    f.write('ffconcat version 1.0\n')
    for s,dur in zip(slides,durations):
        f.write(f"file 'slides/{s}'\n")
        f.write(f'duration {dur:.3f}\n')
    f.write(f"file 'slides/{slides[-1]}'\n")

# upload kit
upload = '''# YouTube Upload Kit｜AI 找素材很快，但老師要檢查來源與難度

## 建議標題
1. AI 找素材很快，但老師要先過三關
2. 素材很多，不代表適合這班學生
3. 老師用 AI 找教材前，先檢查來源與難度

## 說明欄
AI 可以很快整理影片、文章和題目，但「素材很多」不等於「適合直接放進課堂」。這支 Shorts 示範老師在使用 AI 推薦教材前，至少先檢查三件事：來源能不能追、年級概念對不對、難度能不能降一階。

這不是反對老師用 AI，而是把 AI 放在備課助手的位置：先加速蒐集，再由老師把關。

## Hashtags
#AI教學 #教師備課 #物理教學 #AI工具 #教育科技 #Shorts

## 置頂留言草稿
你最怕 AI 推薦哪一種「看起來很棒、其實不適合學生」的素材？留言給我，我可以把它做成下一支檢查案例。

## 封面文字
素材要過濾

## 檔案
- MP4：`source-difficulty-check-ai-materials-35s.mp4`
- 封面：`cover_source_difficulty_check_ai_materials_v1.png`
- 旁白：`narration_35s_hsiaoyu.mp3`
- 字幕：`narration_35s_hsiaoyu.vtt`

## 人工操作卡點
- YouTube/Google 登入、頻道建立與實際上傳仍需使用者親自操作。
- 若使用真實教材、學生作品、付費教材截圖，發布前需再確認公開權限；目前本機草稿使用自製示意圖卡。
'''
(BASE/'youtube-upload-kit.md').write_text(upload,encoding='utf-8')

# update manifest
manifest=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
manifest['status']='shorts_mp4_upload_kit_complete'
manifest['assets'].update({
    'narration_text':'narration_35s.txt',
    'narration_audio':'narration_35s_hsiaoyu.mp3',
    'subtitles_vtt':'narration_35s_hsiaoyu.vtt',
    'cover':'cover_source_difficulty_check_ai_materials_v1.png',
    'video':'source-difficulty-check-ai-materials-35s.mp4',
    'upload_kit':'youtube-upload-kit.md',
    'qa_sheet':'checks/qa_sheet_mp4_cover_frames.png',
    'handoff_archive':'source-difficulty-check-ai-materials-upload-kit-20260510.tar.gz'
})
manifest['next_auto_push']='create_shareable_source_difficulty_checklist_or_pick_next_backlog_item'
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('built text assets')
