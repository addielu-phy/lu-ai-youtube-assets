from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/source-difficulty-check-ai-materials-20260510')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size)

def wrap(draw, text, fnt, max_width):
    lines=[]
    for para in text.split('\n'):
        buf=''
        for ch in para:
            test=buf+ch
            if draw.textbbox((0,0), test, font=fnt)[2] <= max_width:
                buf=test
            else:
                if buf:
                    lines.append(buf)
                buf=ch
        if buf:
            lines.append(buf)
    return lines

def draw_pill(d, xy, text, fill, fg=(255,255,255)):
    x,y,w,h=xy
    d.rounded_rectangle([x,y,x+w,y+h], radius=h//2, fill=fill)
    d.text((x+34,y+16), text, font=font(34), fill=fg)

def draw_card(filename, kicker, title, body, checklist, footer, accent):
    W,H=1080,1920
    img=Image.new('RGB',(W,H),(16,24,36))
    d=ImageDraw.Draw(img)
    # outer phone-safe panel
    d.rounded_rectangle([64,76,1016,1844], radius=58, fill=(248,249,242))
    d.rectangle([64,76,1016,320], fill=accent)
    d.rounded_rectangle([64,76,1016,390], radius=58, outline=accent, width=0)
    d.rectangle([64,300,1016,410], fill=(248,249,242))
    draw_pill(d,(112,124,360,72),kicker,(16,24,36))
    # title block
    y=410
    for line in wrap(d, title, font(82), 850):
        d.text((118,y), line, font=font(82), fill=(16,24,36))
        y += 104
    # material cards
    d.rounded_rectangle([118,850,962,1128], radius=38, fill=(255,255,255), outline=(219,224,216), width=4)
    by = 885
    for line in wrap(d, body, font(44), 760):
        d.text((158, by), line, font=font(44), fill=(40,53,70))
        by += 58
    # checklist
    d.rounded_rectangle([118,1210,962,1492], radius=40, fill=(31,45,64))
    cy=1258
    for item in checklist:
        d.ellipse([158,cy+6,190,cy+38], fill=accent)
        d.text((212,cy), item, font=font(43), fill=(255,246,218))
        cy += 72
    # footer
    d.rounded_rectangle([118,1580,962,1718], radius=34, fill=(255,247,226), outline=(238,218,172), width=3)
    for i,line in enumerate(wrap(d, footer, font(41), 760)[:2]):
        d.text((158,1618+i*56), line, font=font(41), fill=(92,69,25))
    d.text((118,1776), 'AI-agent × 物理教學｜素材過濾工作流', font=font(32), fill=(89,101,118))
    img.save(SLIDES / filename, quality=95)

slides = [
('slide_01_hook.png','HOOK 01','素材很多，\n不等於適合上課','AI 可能一次列出：影片／文章／題目', ['來源可信？','年級合適？','難度可調？'], '先不要急著貼進投影片。', (255,184,76)),
('slide_02_source.png','CHECK 02','第一關：\n來源能追嗎？','只給摘要，還不夠；要能回到原始來源。', ['作者／機構','發布時間','原始連結'], '找不到來源，就先不要公開用。', (115,196,154)),
('slide_03_grade.png','CHECK 03','第二關：\n年級概念對嗎？','同一個「力學素材」，可能跨了不同年級。', ['先備概念','符號／名詞','課綱位置'], '不是難就不好，是要放對位置。', (111,172,255)),
('slide_04_difficulty.png','CHECK 04','第三關：\n難度能降一階嗎？','好素材要能改成這班學生進得去的問題。', ['少一個變因','先畫圖','先問現象'], '能改寫，才是真的可教。', (204,143,255)),
('slide_05_cta.png','CTA 05','先過濾，\n再進課堂','請 AI 補上：適合年級、可能迷思、老師改法。', ['來源','年級','難度'], '留言：你最怕 AI 推哪種素材？', (255,122,122)),
]
for s in slides:
    draw_card(*s)
# 3+2 contact sheet with readable previews
thumb_w, thumb_h = 324, 576
sheet = Image.new('RGB', (1160, 1420), (16,24,36))
d = ImageDraw.Draw(sheet)
d.text((40,32), 'Storyboard QA｜AI 找素材：來源與難度檢查', font=font(42), fill=(255,255,255))
positions=[(40,120),(418,120),(796,120),(230,770),(608,770)]
for idx, (fname, *_rest) in enumerate(slides):
    im = Image.open(SLIDES/fname).resize((thumb_w, thumb_h))
    x,y=positions[idx]
    sheet.paste(im,(x,y))
    d.text((x,y+thumb_h+14), f'{idx+1}. {fname}', font=font(24), fill=(232,236,241))
sheet.save(CHECKS/'contact_sheet.png', quality=95)
print('rendered', BASE)
