
import tarfile, json
from pathlib import Path
base=Path('/home/adl/youtube-lu-ai-channel/shorts/force-diagram-first-check-20260511')
with tarfile.open(base/'force-diagram-first-check-upload-kit-20260511.tar.gz','r:gz') as t:
    names=t.getnames()
for must in ['README.md','youtube-upload-kit.md','manifest.json','force-diagram-first-check-shorts-35s.mp4','cover_force_diagram_first_check_v1.png','narration_35s_edge_hsiaoyu.vtt','checks/upload_qa_sheet.png']:
    print(must, must in names)
print('count', len(names))
