
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
BASE=Path('/home/adl/youtube-lu-ai-channel/shorts/force-diagram-first-check-20260511')
W,H=1080,1920
FONT='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(s): return ImageFont.truetype(FONT,s)
def wrap(draw,text,f,maxw):
    lines=[]; cur=''
    for ch in text:
        if ch=='\n':
            lines.append(cur); cur=''; continue
        if draw.textbbox((0,0), cur+ch, font=f)[2] <= maxw:
            cur += ch
        else:
            if cur: lines.append(cur)
            cur = ch
    if cur: lines.append(cur)
    return lines
img=Image.new('RGB',(W,H),'#07111F')
d=ImageDraw.Draw(img)
# background grid
for x in range(-300,W+400,80): d.line([(x,0),(x+500,H)], fill='#0D1B2F', width=2)
for y in range(0,H,120): d.line([(0,y),(W,y)], fill='#10243E', width=2)
# panel
d.rounded_rectangle((72,150,1008,1770), radius=56, fill='#0D1B2F', outline='#19D3FF', width=6)
d.rounded_rectangle((118,215,962,520), radius=36, fill='#FFD84D')
for line_i,line in enumerate(wrap(d,'AI 力圖\n第一眼看哪裡？',font(88),760)):
    d.text((160,245+line_i*112), line, font=font(88), fill='#07111F')
# simple force diagram
cx,cy=540,940
# block
d.rounded_rectangle((380,850,700,1010), radius=20, fill='#F4F7FB', outline='#DDE6F2', width=4)
d.text((430,900),'物體',font=font(60),fill='#07111F')
# arrows
arrow_color='#19D3FF'
def arrow(start,end,color,label,offset=(0,0)):
    d.line([start,end],fill=color,width=16)
    # simple head
    ex,ey=end; sx,sy=start
    import math
    ang=math.atan2(ey-sy, ex-sx)
    for a in (ang+2.55, ang-2.55):
        d.line([(ex,ey),(ex-44*math.cos(a),ey-44*math.sin(a))],fill=color,width=16)
    d.text((end[0]+offset[0],end[1]+offset[1]),label,font=font(44),fill=color)
arrow((540,850),(540,665),'#FFD84D','正向力',(-95,-75))
arrow((540,1010),(540,1215),'#FF4D6D','重力',(-70,25))
arrow((380,930),(210,930),'#19D3FF','摩擦？',(-155,-78))
# checklist
items=['1 有沒有漏力／多力','2 方向是否合理','3 誰對誰施力？']
y=1325
for it in items:
    d.rounded_rectangle((150,y,930,y+120),radius=28,fill='#132B46',outline='#FFD84D',width=3)
    d.text((205,y+29),it,font=font(50),fill='#FFFFFF')
    y+=145
# footer removed to keep cover uncluttered for mobile readability
img.save(BASE/'cover_force_diagram_first_check_v1.png')
