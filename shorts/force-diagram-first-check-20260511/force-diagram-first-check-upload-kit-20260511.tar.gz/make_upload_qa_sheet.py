
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
BASE=Path('/home/adl/youtube-lu-ai-channel/shorts/force-diagram-first-check-20260511')
items=[('封面',BASE/'cover_force_diagram_first_check_v1.png'),('01s',BASE/'checks/frame_01s.png'),('15s',BASE/'checks/frame_15s.png'),('31s',BASE/'checks/frame_31s.png')]
thumb_w, thumb_h = 360, 640
margin=36
W=margin*3+thumb_w*2; H=margin*3+(thumb_h+54)*2
sheet=Image.new('RGB',(W,H),'#07111F')
d=ImageDraw.Draw(sheet)
font=ImageFont.truetype('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',30)
for i,(label,p) in enumerate(items):
    im=Image.open(p).convert('RGB').resize((thumb_w,thumb_h))
    x=margin+(i%2)*(thumb_w+margin); y=margin+(i//2)*(thumb_h+54+margin)
    sheet.paste(im,(x,y+44)); d.text((x,y),label,font=font,fill='#FFFFFF')
sheet.save(BASE/'checks/upload_qa_sheet.png')
