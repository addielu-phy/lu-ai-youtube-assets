#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, textwrap, datetime

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/force-diagram-first-check-20260511')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
W, H = 1080, 1920
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size)

F = {
    'title': font(82), 'big': font(72), 'mid': font(54), 'body': font(44),
    'small': font(34), 'tiny': font(28), 'tag': font(30)
}

PALETTE = {
    'bg': (246, 249, 252), 'ink': (28, 38, 55), 'muted': (89, 103, 125),
    'blue': (37, 99, 235), 'cyan': (6, 182, 212), 'orange': (245, 127, 23),
    'red': (220, 38, 38), 'green': (22, 163, 74), 'white': (255, 255, 255),
    'line': (207, 216, 230), 'pale': (232, 240, 255), 'cream': (255, 248, 231)
}

slides = [
    {
        'file':'slide_01_hook.png', 'kicker':'第二季 01｜錯誤診斷進階',
        'title':'AI 畫的力圖，第一眼先看哪裡？',
        'body':['答案有字不夠。','圖錯，學生更容易被帶歪。'],
        'note':'先看圖，不先算式。'
    },
    {
        'file':'slide_02_all_forces.png', 'kicker':'第一眼：力有沒有漏？',
        'title':'先問：有哪些力？',
        'body':['重力 mg：一定在','正向力 N：接觸才有','摩擦力 f：有相對滑動趨勢才有'],
        'note':'不要讓 AI 憑空多畫一個力。'
    },
    {
        'file':'slide_03_direction.png', 'kicker':'第二眼：方向對不對？',
        'title':'箭頭方向，比公式更早檢查',
        'body':['重力永遠向下','正向力垂直接觸面','摩擦力反抗相對滑動趨勢'],
        'note':'方向錯，後面代數再漂亮也會偏。'
    },
    {
        'file':'slide_04_object_scope.png', 'kicker':'第三眼：畫的是誰？',
        'title':'只畫「這個物體」受到的力',
        'body':['不是把整個系統的力都塞進來','作用力／反作用力不要畫在同一物體上','先圈出受力物，再畫箭頭'],
        'note':'老師把關句：這個箭頭是誰施力？作用在誰身上？'
    },
    {
        'file':'slide_05_cta.png', 'kicker':'30 秒課堂用法',
        'title':'給學生三個檢查句',
        'body':['1. 有沒有漏力或多力？','2. 方向是否符合接觸／重力？','3. 這個力作用在同一物體嗎？'],
        'note':'下一步可做旁白＋MP4＋上傳包。'
    },
]


def wrap_text(draw, text, fnt, max_width):
    out, line = [], ''
    for ch in text:
        test = line + ch
        if draw.textbbox((0,0), test, font=fnt)[2] <= max_width:
            line = test
        else:
            if line: out.append(line)
            line = ch
    if line: out.append(line)
    return out

def rounded(draw, xy, r, fill, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

def draw_header(draw, kicker):
    rounded(draw, (64, 62, 1016, 128), 28, PALETTE['pale'])
    draw.text((92, 80), kicker, font=F['tag'], fill=PALETTE['blue'])

def draw_footer(draw, note):
    rounded(draw, (64, 1688, 1016, 1836), 34, PALETTE['cream'], outline=(255, 214, 150), width=3)
    lines = wrap_text(draw, note, F['small'], 860)
    y = 1718
    for line in lines[:3]:
        draw.text((108, y), line, font=F['small'], fill=PALETTE['ink'])
        y += 44

def draw_force_diagram(draw, variant):
    # card
    rounded(draw, (120, 770, 960, 1250), 42, PALETTE['white'], outline=PALETTE['line'], width=4)
    # slope
    draw.line((240, 1120, 820, 930), fill=(80, 90, 110), width=8)
    # block polygon
    block = [(475, 930), (635, 880), (685, 1035), (525, 1085)]
    draw.polygon(block, fill=(219, 234, 254), outline=PALETTE['blue'])
    cx, cy = 580, 985
    # arrows
    def arrow(start, end, color, label):
        draw.line((start, end), fill=color, width=9)
        ex, ey = end; sx, sy = start
        import math
        ang = math.atan2(ey-sy, ex-sx)
        for da in (2.55, -2.55):
            x = ex - 34*math.cos(ang+da); y = ey - 34*math.sin(ang+da)
            draw.line((ex, ey, x, y), fill=color, width=9)
        draw.text((ex+12 if ex>sx else ex-78, ey-32), label, font=F['small'], fill=color)
    arrow((cx, cy), (cx, cy+260), PALETTE['red'], 'mg')
    arrow((cx, cy), (cx-95, cy-270), PALETTE['green'], 'N')
    if variant == 'wrong':
        arrow((cx, cy), (cx+250, cy), PALETTE['orange'], '？')
        draw.text((205, 802), 'AI 圖：看似完整，但多了一個可疑箭頭', font=F['small'], fill=PALETTE['muted'])
    elif variant == 'direction':
        arrow((cx, cy), (cx+250, cy-80), PALETTE['orange'], 'f')
        draw.text((205, 802), '方向檢查：箭頭要符合接觸與滑動趨勢', font=F['small'], fill=PALETTE['muted'])
    else:
        draw.ellipse((cx-95, cy-95, cx+95, cy+95), outline=PALETTE['orange'], width=6)
        draw.text((205, 802), '先圈受力物：只畫它受到的力', font=F['small'], fill=PALETTE['muted'])

def render_slide(s, idx):
    img = Image.new('RGB', (W,H), PALETTE['bg'])
    d = ImageDraw.Draw(img)
    draw_header(d, s['kicker'])
    # title
    y = 180
    for line in wrap_text(d, s['title'], F['title'], 920):
        d.text((64, y), line, font=F['title'], fill=PALETTE['ink'])
        y += 100
    # body card
    rounded(d, (64, 500, 1016, 730), 36, PALETTE['white'], outline=PALETTE['line'], width=3)
    by = 530
    for b in s['body']:
        for line in wrap_text(d, b, F['body'], 840):
            d.text((112, by), line, font=F['body'], fill=PALETTE['ink'])
            by += 58
        by += 8
    if idx == 0:
        draw_force_diagram(d, 'wrong')
        # big stamp
        rounded(d, (210, 1295, 870, 1435), 36, (255,255,255), outline=PALETTE['red'], width=5)
        d.text((260, 1328), '先別急著相信圖', font=F['mid'], fill=PALETTE['red'])
    elif idx == 1:
        draw_force_diagram(d, 'wrong')
        rounded(d, (140, 1290, 940, 1515), 34, PALETTE['white'], outline=PALETTE['line'], width=3)
        d.text((190, 1320), '力圖第一問', font=F['small'], fill=PALETTE['muted'])
        d.text((190, 1370), '有沒有漏力／多力？', font=F['mid'], fill=PALETTE['blue'])
    elif idx == 2:
        draw_force_diagram(d, 'direction')
        rounded(d, (140, 1290, 940, 1515), 34, PALETTE['white'], outline=PALETTE['line'], width=3)
        d.text((190, 1320), '力圖第二問', font=F['small'], fill=PALETTE['muted'])
        d.text((190, 1370), '箭頭方向合理嗎？', font=F['mid'], fill=PALETTE['orange'])
    elif idx == 3:
        draw_force_diagram(d, 'scope')
        rounded(d, (140, 1290, 940, 1540), 34, PALETTE['white'], outline=PALETTE['line'], width=3)
        d.text((190, 1320), '力圖第三問', font=F['small'], fill=PALETTE['muted'])
        d.text((190, 1370), '施力者是誰？', font=F['mid'], fill=PALETTE['green'])
        d.text((190, 1440), '作用在哪個物體？', font=F['mid'], fill=PALETTE['green'])
    else:
        rounded(d, (96, 810, 984, 1370), 46, PALETTE['white'], outline=PALETTE['line'], width=4)
        checks = ['漏力或多力', '箭頭方向', '同一受力物']
        y2 = 895
        for n, c in enumerate(checks, 1):
            d.ellipse((150, y2, 222, y2+72), fill=PALETTE['blue'])
            d.text((174, y2+10), str(n), font=F['body'], fill=PALETTE['white'])
            d.text((260, y2+6), c, font=F['big'], fill=PALETTE['ink'])
            y2 += 150
    draw_footer(d, s['note'])
    # safe margin frame subtle
    d.rectangle((32,32,W-32,H-32), outline=(230,236,245), width=2)
    img.save(SLIDES / s['file'])
    return SLIDES / s['file']

paths = []
for i, s in enumerate(slides):
    paths.append(render_slide(s, i))

# contact sheet 3 + 2 layout with readable previews
thumb_w, thumb_h = 324, 576
sheet = Image.new('RGB', (1200, 1500), (250,252,255))
d = ImageDraw.Draw(sheet)
d.text((40, 24), '第二季優先題 1｜AI 畫的力圖，第一眼先看哪裡？ storyboard', font=F['small'], fill=PALETTE['ink'])
positions = [(48,100),(438,100),(828,100),(240,785),(630,785)]
for idx, (p, pos) in enumerate(zip(paths, positions), 1):
    im = Image.open(p).resize((thumb_w, thumb_h))
    sheet.paste(im, pos)
    d.text((pos[0], pos[1]+thumb_h+12), f'{idx}. {p.name}', font=F['tiny'], fill=PALETTE['muted'])
sheet.save(CHECKS / 'contact_sheet.png')

manifest = {
    'project':'force-diagram-first-check-20260511',
    'title':'AI 畫的力圖，第一眼先看哪裡？',
    'created_at': datetime.datetime.now().isoformat(timespec='seconds'),
    'format':'Shorts storyboard package, 1080x1920 PNG slides',
    'slides':[str(p.relative_to(BASE)) for p in paths],
    'contact_sheet':'checks/contact_sheet.png',
    'font':FONT,
    'next_auto_push':'擴成 30–40 秒 zh-TW 旁白、VTT、MP4、封面與 YouTube upload kit。'
}
(BASE / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(manifest, ensure_ascii=False, indent=2))
