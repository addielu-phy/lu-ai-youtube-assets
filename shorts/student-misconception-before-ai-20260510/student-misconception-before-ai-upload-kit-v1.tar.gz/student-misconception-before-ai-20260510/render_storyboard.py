from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import textwrap

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/student-misconception-before-ai-20260510')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size)

def wrap(draw, text, fnt, max_width):
    lines=[]
    for para in text.split('\n'):
        buf=''
        for ch in para:
            test=buf+ch
            if draw.textbbox((0,0), test, font=fnt)[2] <= max_width:
                buf=test
            else:
                if buf: lines.append(buf)
                buf=ch
        if buf: lines.append(buf)
    return lines

def draw_card(filename, kicker, title, body, footer, accent):
    W,H=1080,1920
    bg=(18,24,38)
    img=Image.new('RGB',(W,H),bg)
    d=ImageDraw.Draw(img)
    # background blocks
    d.rounded_rectangle([70,85,1010,1835], radius=54, fill=(245,247,241))
    d.rectangle([70,85,1010,330], fill=accent)
    d.rounded_rectangle([70,85,1010,430], radius=54, outline=accent, width=0)
    d.rectangle([70,300,1010,430], fill=(245,247,241))
    d.rounded_rectangle([110,130,470,205], radius=32, fill=(18,24,38))
    d.text((145,146), kicker, font=font(38), fill=(255,255,255))
    # title
    y=390
    for line in wrap(d, title, font(82), 860):
        d.text((120,y), line, font=font(82), fill=(18,24,38))
        y += 104
    # middle highlight
    d.rounded_rectangle([120,860,960,1215], radius=44, fill=(255,255,255), outline=(214,218,210), width=4)
    y2=910
    for line in wrap(d, body, font(54), 760):
        d.text((160,y2), line, font=font(54), fill=(39,52,72))
        y2 += 72
    # footer
    d.rounded_rectangle([120,1430,960,1665], radius=42, fill=(31,42,62))
    y3=1475
    for line in wrap(d, footer, font(48), 760):
        d.text((160,y3), line, font=font(48), fill=(255,244,214))
        y3 += 64
    d.text((120,1750), 'AI-agent × 物理教學', font=font(34), fill=(84,96,112))
    img.save(SLIDES / filename, quality=95)

slides = [
('slide_01_hook.png','HOOK 01','學生卡住，\n不是丟給 AI\n就結束','學生原句常常很亂，\n但裡面藏著真正的迷思。','先聽懂學生，\n再讓 AI 幫忙。',(255,194,87)),
('slide_02_collect.png','STEP 02','先收集\n學生原句','不要急著把話改漂亮：\n保留「錯在哪裡」的線索。','原句比標準答案\n更接近教學現場。',(126,202,156)),
('slide_03_sort.png','STEP 03','老師先分成\n3 類迷思','概念不清、條件誤讀、\n圖像／方向搞錯。','分類後，AI 才知道\n要幫哪一種忙。',(118,178,255)),
('slide_04_prompt.png','STEP 04','再請 AI\n出追問','請 AI 依三類迷思，\n各產生 2 句追問。','不要叫它直接判對錯，\n先叫它幫你提問。',(216,151,255)),
('slide_05_cta.png','CTA 05','最後判斷權\n留給老師','AI 可以整理、分類、出追問，\n但公開使用前要由老師審。','留言：你最常遇到\n哪一種學生迷思？',(255,128,128)),
]
for s in slides:
    draw_card(*s)

# Contact sheet: 3 + 2 large layout
thumb_w, thumb_h = 324, 576
sheet = Image.new('RGB', (1160, 1420), (18,24,38))
d = ImageDraw.Draw(sheet)
d.text((40,32), 'Storyboard QA｜學生迷思丟給 AI 前，先做什麼？', font=font(42), fill=(255,255,255))
positions=[(40,120),(418,120),(796,120),(230,770),(608,770)]
for idx, (fname, *_rest) in enumerate(slides):
    im = Image.open(SLIDES/fname).resize((thumb_w, thumb_h))
    x,y=positions[idx]
    sheet.paste(im,(x,y))
    d.text((x,y+thumb_h+14), f'{idx+1}. {fname}', font=font(24), fill=(232,236,241))
sheet.save(CHECKS/'contact_sheet.png', quality=95)
print('rendered', BASE)
