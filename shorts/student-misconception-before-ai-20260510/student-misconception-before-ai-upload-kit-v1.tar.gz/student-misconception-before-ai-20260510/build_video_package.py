#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import subprocess, json, textwrap, tarfile, time, shutil

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/student-misconception-before-ai-20260510')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
CHECKS.mkdir(exist_ok=True)

narration = (
    '學生卡住時，先不要急著把問題丟給 AI。\n'
    '第一步，請保留學生的原句，因為迷思常藏在用詞裡。\n'
    '第二步，老師先分成三類：概念混淆、圖像誤判、還是單位方向問題。\n'
    '第三步，再請 AI 幫你分類，並設計追問。\n'
    '記住：AI 可以整理，最後判斷仍然要回到老師。'
)
(BASE / 'narration_35s.txt').write_text(narration, encoding='utf-8')

# Generate TTS if not already usable
mp3 = BASE / 'narration_35s_zhTW_HsiaoYu.mp3'
edge = shutil.which('edge-tts') or '/home/adl/.hermes/hermes-agent/venv/bin/edge-tts'
subprocess.run([edge, '--voice', 'zh-TW-HsiaoYuNeural', '--rate=+22%', '--text', narration.replace('\n',' '), '--write-media', str(mp3)], check=True)

def ffprobe_duration(path: Path) -> float:
    out = subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(path)], text=True)
    return float(json.loads(out)['format']['duration'])

audio_dur = ffprobe_duration(mp3)
# Clamp visual to audio duration; distribute over 5 cards, first/last a bit longer.
weights = [1.10, 1.0, 1.0, 1.0, 1.15]
total_w = sum(weights)
durations = [audio_dur * w / total_w for w in weights]

# VTT sidecar with rough timing
segments = [
    '學生卡住時，先不要急著把問題丟給 AI。',
    '第一步：保留學生原句，迷思常藏在用詞裡。',
    '第二步：老師先分三類，概念、圖像、單位方向。',
    '第三步：再請 AI 分類，並設計追問。',
    'AI 可以整理；最後判斷仍然回到老師。',
]

def ts(sec):
    ms = int(round((sec - int(sec)) * 1000))
    sec_i = int(sec)
    h = sec_i // 3600
    m = (sec_i % 3600) // 60
    s = sec_i % 60
    return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'
cur = 0.0
vtt = ['WEBVTT','']
for i, (d, text) in enumerate(zip(durations, segments), start=1):
    start, end = cur, min(audio_dur, cur+d)
    vtt += [str(i), f'{ts(start)} --> {ts(end)}', text, '']
    cur += d
(BASE / 'subtitles_35s.vtt').write_text('\n'.join(vtt), encoding='utf-8')

# Create a clean cover PNG with the same palette, no dense text.
W,H=1080,1920
font_path='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
font_title=ImageFont.truetype(font_path, 92)
font_mid=ImageFont.truetype(font_path, 54)
font_small=ImageFont.truetype(font_path, 42)
img=Image.new('RGB',(W,H),'#07111F')
d=ImageDraw.Draw(img)
# background panels
for y, col in [(130,'#0D1B2F'),(1050,'#0D1B2F')]:
    d.rounded_rectangle([70,y,W-70,y+650], radius=52, fill=col, outline='#19D3FF', width=5)
d.text((95,170),'學生迷思',font=font_title,fill='#FFD84D')
d.text((95,285),'先別丟給 AI',font=font_title,fill='#F4F7FB')
d.rounded_rectangle([95,450,985,570], radius=36, fill='#132846', outline='#89A3B8', width=3)
d.text((125,480),'保留原句 → 老師分類 → AI 追問',font=font_small,fill='#F4F7FB')
# simple teacher/AI cards
cards=[('學生原句','#F4F7FB','#89A3B8'),('老師判斷','#FFD84D','#FFD84D'),('AI 整理','#19D3FF','#19D3FF')]
x=105
for label, color, stroke in cards:
    d.rounded_rectangle([x,690,x+250,910], radius=32, fill='#10243D', outline=stroke, width=4)
    d.text((x+36,760),label,font=font_mid,fill=color)
    x+=310
# CTA bottom
d.text((95,1130),'不是讓 AI 代判斷，',font=font_mid,fill='#F4F7FB')
d.text((95,1210),'是讓老師更快看見迷思。',font=font_mid,fill='#FFD84D')
d.rounded_rectangle([95,1450,985,1585], radius=36, fill='#19D3FF')
d.text((145,1485),'30 秒教師工作流',font=font_mid,fill='#07111F')
d.text((95,1690),'AI Agent × 物理教學',font=font_small,fill='#89A3B8')
cover = BASE / 'cover-student-misconception-before-ai.png'
img.save(cover)

# Build ffconcat for slides
concat = BASE / 'slides.ffconcat'
slide_names = ['slide_01_hook.png','slide_02_collect.png','slide_03_sort.png','slide_04_prompt.png','slide_05_cta.png']
lines=['ffconcat version 1.0']
for name,dur in zip(slide_names,durations):
    lines.append(f"file '{(SLIDES/name).as_posix()}'")
    lines.append(f'duration {dur:.3f}')
# repeat last file per ffconcat convention
lines.append(f"file '{(SLIDES/slide_names[-1]).as_posix()}'")
concat.write_text('\n'.join(lines)+'\n', encoding='utf-8')

silent_mp4 = BASE / 'student-misconception-before-ai-video-only.mp4'
final_mp4 = BASE / 'student-misconception-before-ai-short-v1.mp4'
subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat),'-vf','fps=30,format=yuv420p','-c:v','libx264','-movflags','+faststart',str(silent_mp4)], check=True)
subprocess.run(['ffmpeg','-y','-i',str(silent_mp4),'-i',str(mp3),'-c:v','copy','-c:a','aac','-b:a','128k','-shortest','-movflags','+faststart',str(final_mp4)], check=True)

# Extract frames and QA contact sheet: cover + 3 video frames
for sec, name in [(1,'frame_01_hook.jpg'), (audio_dur*0.45,'frame_02_mid.jpg'), (max(1,audio_dur-3),'frame_03_end.jpg')]:
    subprocess.run(['ffmpeg','-y','-ss',f'{sec:.2f}','-i',str(final_mp4),'-frames:v','1','-q:v','2',str(CHECKS/name)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
thumbs=[]
for p in [cover, CHECKS/'frame_01_hook.jpg', CHECKS/'frame_02_mid.jpg', CHECKS/'frame_03_end.jpg']:
    im=Image.open(p).convert('RGB')
    im.thumbnail((360,640))
    thumbs.append((p.name, im.copy()))
sheet=Image.new('RGB',(800,1420),'#07111F')
d=ImageDraw.Draw(sheet)
font_label=ImageFont.truetype(font_path,26)
positions=[(30,60),(410,60),(30,735),(410,735)]
for (label,im),(x,y) in zip(thumbs,positions):
    sheet.paste(im,(x,y))
    d.text((x,y+im.height+12),label,font=font_label,fill='#F4F7FB')
sheet.save(CHECKS/'video_qa_sheet.png')

# Manifest and upload kit
probe_v = subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,avg_frame_rate,codec_name','-show_entries','format=duration,size','-of','json',str(final_mp4)], text=True)
probe_a = subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=codec_name,sample_rate,channels','-of','json',str(final_mp4)], text=True)
manifest = {
    'project': 'student-misconception-before-ai-20260510',
    'title': '把學生迷思丟給 AI 前，老師先做什麼？',
    'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
    'files': {
        'mp4': final_mp4.name,
        'cover': cover.name,
        'narration': 'narration_35s.txt',
        'audio': mp3.name,
        'subtitles': 'subtitles_35s.vtt',
        'upload_kit': 'youtube-upload-kit.md',
        'qa_sheet': 'checks/video_qa_sheet.png'
    },
    'ffprobe_video': json.loads(probe_v),
    'ffprobe_audio': json.loads(probe_a),
}
(BASE/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

upload = f'''# YouTube Upload Kit｜把學生迷思丟給 AI 前，老師先做什麼？

狀態：本機 Shorts 草稿完成，等待使用者登入 YouTube/Google 後手動上傳。

## 檔案

- 影片：`student-misconception-before-ai-short-v1.mp4`
- 封面：`cover-student-misconception-before-ai.png`
- 旁白稿：`narration_35s.txt`
- 字幕：`subtitles_35s.vtt`
- QA：`checks/video_qa_sheet.png`
- 壓縮包：`student-misconception-before-ai-upload-kit-v1.tar.gz`

## 建議標題

1. 把學生迷思丟給 AI 前，老師先做什麼？
2. 學生卡住時，別急著問 AI：先做這 3 步
3. AI 可以整理迷思，但老師要先保留這件事

## 建議描述

學生卡住時，不是把問題丟給 AI 就結束。  
這支 30 秒 Shorts 示範一個教師可用的小流程：先保留學生原句，再由老師初步分類，最後才請 AI 幫忙整理與設計追問。

適合自然／物理教師用來思考：AI 是備課助教，不是替老師做最後判斷的人。

## Hashtags

#AI教學 #物理教學 #生成式AI #教師工作流 #AI備課 #探究教學

## 置頂留言草稿

你最常遇到哪一種學生迷思？  
A 概念混淆｜B 圖像誤判｜C 單位或方向問題  
留言一個例子，我可以把它改成下一支「AI 幫老師整理迷思」示範。

## 人工上傳前檢查

- [ ] 確認頻道名稱／品牌是否用 `AI 物理備課室`。
- [ ] 若替換為真實學生回答，需先確認可公開性並去識別化。
- [ ] 由使用者在已登入的 YouTube/Google 環境手動上傳。
'''
(BASE/'youtube-upload-kit.md').write_text(upload, encoding='utf-8')

# Update README status section conservatively
readme = BASE/'README.md'
text = readme.read_text(encoding='utf-8')
text = text.replace('狀態：30 秒 Shorts storyboard 包已完成（尚未製作旁白／字幕／MP4）。', '狀態：30 秒 Shorts 本機草稿已完成（旁白／VTT 字幕／MP4／封面／YouTube upload kit 已補齊）。')
text = text.replace('## 下一個可自動推進\n\n- 為這支 storyboard 製作 zh-TW 30–35 秒旁白稿、VTT 字幕與本機 MP4 草稿，再補 YouTube upload kit。', '## 本次新增輸出\n\n- `narration_35s.txt`\n- `narration_35s_zhTW_HsiaoYu.mp3`\n- `subtitles_35s.vtt`\n- `student-misconception-before-ai-short-v1.mp4`\n- `cover-student-misconception-before-ai.png`\n- `youtube-upload-kit.md`\n- `manifest.json`\n- `checks/video_qa_sheet.png`\n- `student-misconception-before-ai-upload-kit-v1.tar.gz`\n\n## 下一個可自動推進\n\n- 若 YouTube 登入仍未處理，改推進下一個未完成題庫：候選題 1「AI 偷換條件，答案再漂亮也錯」的 5 張 storyboard 包；或把長片候選題 4「老師檢查 AI 解題的 5 句追問」講義擴成正式可分享版本。')
readme.write_text(text, encoding='utf-8')

# Archive after all docs are written
archive = BASE/'student-misconception-before-ai-upload-kit-v1.tar.gz'
include = ['README.md','youtube-upload-kit.md','manifest.json','narration_35s.txt','narration_35s_zhTW_HsiaoYu.mp3','subtitles_35s.vtt','student-misconception-before-ai-short-v1.mp4','cover-student-misconception-before-ai.png','render_storyboard.py','build_video_package.py']
with tarfile.open(archive,'w:gz') as tar:
    for name in include:
        tar.add(BASE/name, arcname=f'student-misconception-before-ai-20260510/{name}')
    for p in sorted(SLIDES.glob('*.png')):
        tar.add(p, arcname=f'student-misconception-before-ai-20260510/slides/{p.name}')
    for p in sorted(CHECKS.glob('*')):
        tar.add(p, arcname=f'student-misconception-before-ai-20260510/checks/{p.name}')

print(json.dumps({'audio_duration': audio_dur, 'mp4': str(final_mp4), 'archive': str(archive)}, ensure_ascii=False, indent=2))
