#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, textwrap

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/draw-to-verify-ai-explanation-20260510')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
FONT_PATH = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W, H = 1080, 1920
BG = (13, 20, 33)
PANEL = (25, 38, 61)
CYAN = (83, 220, 255)
YELLOW = (255, 206, 84)
PINK = (255, 112, 160)
GREEN = (112, 232, 168)
WHITE = (248, 250, 252)
MUTED = (172, 188, 210)
RED = (255, 96, 96)

F = lambda size: ImageFont.truetype(FONT_PATH, size)
font_title = F(78)
font_subtitle = F(48)
font_body = F(42)
font_small = F(34)
font_tag = F(30)
font_big = F(104)

def wrap_text(text, font, max_width):
    lines, cur = [], ''
    for ch in text:
        test = cur + ch
        if font.getlength(test) <= max_width or not cur:
            cur = test
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines

def draw_round(draw, box, radius, fill, outline=None, width=3):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)

def center_text(draw, y, text, font, fill=WHITE, max_width=900, line_gap=14):
    lines = []
    for part in text.split('\n'):
        lines += wrap_text(part, font, max_width)
    total = sum(font.getbbox(line)[3]-font.getbbox(line)[1] for line in lines) + line_gap*(len(lines)-1)
    yy = y
    for line in lines:
        bbox = draw.textbbox((0,0), line, font=font)
        draw.text(((W-(bbox[2]-bbox[0]))/2, yy), line, font=font, fill=fill)
        yy += (bbox[3]-bbox[1]) + line_gap
    return yy

def top_brand(draw, idx):
    draw.text((70, 62), 'AI 解釋審稿課', font=font_tag, fill=MUTED)
    draw.text((850, 62), f'{idx}/5', font=font_tag, fill=MUTED)
    draw.line((70, 118, 1010, 118), fill=(46, 68, 100), width=3)

def note(draw, xy, title, body, color=CYAN):
    x,y,w,h = xy
    draw_round(draw, (x,y,x+w,y+h), 28, PANEL, color, 4)
    draw.text((x+32,y+28), title, font=font_subtitle, fill=color)
    yy = y+100
    for line in wrap_text(body, font_body, w-64):
        draw.text((x+32, yy), line, font=font_body, fill=WHITE)
        yy += 58

def arrow(draw, start, end, fill=YELLOW):
    draw.line((start, end), fill=fill, width=10)
    ex, ey = end; sx, sy = start
    # simple downward/right arrowhead variants
    draw.polygon([(ex,ey),(ex-28,ey-18),(ex-16,ey+32)], fill=fill)

slides = []

# Slide 1 Hook
img = Image.new('RGB', (W,H), BG); d=ImageDraw.Draw(img); top_brand(d,1)
center_text(d, 210, 'AI 解釋太順？', font_big, YELLOW)
center_text(d, 350, '先不要急著點頭', font_title, WHITE)
draw_round(d, (130, 540, 950, 930), 36, PANEL, CYAN, 5)
center_text(d, 610, '越順的說明，\n越要畫一張圖驗證。', font_subtitle, WHITE, 760, 18)
# fake AI bubble
draw_round(d, (160,1050,920,1285), 34, (32,50,80), None)
d.text((210,1098), 'AI：所以答案很明顯是向右。', font=font_body, fill=WHITE)
d.text((210,1170), '老師：圖在哪？方向怎麼定？', font=font_body, fill=PINK)
draw_round(d, (210,1420,870,1545), 24, (42,34,24), YELLOW, 4)
center_text(d, 1452, '本集：用「畫圖」抓出含糊解釋', font_small, YELLOW, 620)
slides.append(('slide_01_hook.png', img))

# Slide 2 Problem
img = Image.new('RGB', (W,H), BG); d=ImageDraw.Draw(img); top_brand(d,2)
center_text(d, 180, '順，可能只是「像懂」', font_title, WHITE)
note(d, (100,390,880,330), '常見狀況', 'AI 把受力、運動方向、電路流向講得很完整，但沒有圖。', CYAN)
note(d, (100,790,880,330), '老師要問', '它的箭頭、正方向、已知量，真的和題目一致嗎？', PINK)
# diagram placeholder
draw_round(d, (150,1260,930,1590), 30, (18, 28, 45), MUTED, 3)
d.line((250,1450,820,1450), fill=MUTED, width=6)
d.polygon([(820,1450),(780,1428),(780,1472)], fill=MUTED)
d.rectangle((435,1365,585,1450), fill=(70,88,120), outline=WHITE, width=4)
d.line((510,1365,510,1235), fill=GREEN, width=9); d.polygon([(510,1235),(484,1280),(536,1280)], fill=GREEN)
d.text((545,1245), 'N', font=font_small, fill=GREEN)
d.line((585,1405,755,1405), fill=YELLOW, width=9); d.polygon([(755,1405),(710,1378),(710,1432)], fill=YELLOW)
d.text((655,1348), '？', font=font_subtitle, fill=YELLOW)
slides.append(('slide_02_problem.png', img))

# Slide 3 Three-step check
img = Image.new('RGB', (W,H), BG); d=ImageDraw.Draw(img); top_brand(d,3)
center_text(d, 170, '請學生畫 3 件事', font_title, YELLOW)
items=[('1','物體/系統','先圈出正在分析誰'),('2','箭頭方向','力、速度、電流都畫出來'),('3','正方向','寫清楚「向哪邊算正」')]
y=390
for num,title,body in items:
    draw_round(d,(105,y,870,y+245),32,PANEL,None)
    d.ellipse((145,y+58,245,y+158),fill=(34,55,86),outline=CYAN,width=5)
    bbox=d.textbbox((0,0),num,font=font_subtitle)
    d.text((195-(bbox[2]-bbox[0])/2,y+82),num,font=font_subtitle,fill=CYAN)
    d.text((285,y+50),title,font=font_subtitle,fill=WHITE)
    d.text((285,y+120),body,font=font_body,fill=MUTED)
    y+=305
center_text(d, 1520, '沒有圖，就不能說「方向很明顯」。', font_body, PINK, 880)
slides.append(('slide_03_three_steps.png', img))

# Slide 4 Classroom activity
img = Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(img); top_brand(d,4)
center_text(d, 170, '5 分鐘課堂玩法', font_title, WHITE)
note(d,(95,360,890,250),'第 1 分鐘','給學生一段 AI 解釋，不先公布對錯。',CYAN)
note(d,(95,675,890,250),'第 2–4 分鐘','學生補圖：箭頭、已知量、正方向、疑點。',YELLOW)
note(d,(95,990,890,250),'第 5 分鐘','只問一句：圖和 AI 說法有沒有衝突？',GREEN)
draw_round(d,(130,1360,950,1585),30,(42,28,44),PINK,4)
center_text(d, 1405, '重點不是「AI 錯了」\n而是學生能說出哪裡要驗證。', font_body, WHITE, 760)
slides.append(('slide_04_activity.png',img))

# Slide 5 CTA
img = Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(img); top_brand(d,5)
center_text(d, 190, '下次遇到順口答案', font_title, YELLOW)
center_text(d, 320, '先加一句：', font_subtitle, MUTED)
draw_round(d,(120,520,960,900),42,(27,47,73),CYAN,5)
center_text(d, 630, '「請把圖畫出來，\n再解釋一次。」', font_title, WHITE, 800)
# checklist
checks=['受力圖 / 運動圖 / 電路圖','箭頭方向有標清楚','正方向與題目一致']
y=1040
for c in checks:
    d.ellipse((160,y,208,y+48),fill=GREEN)
    d.text((173,y+2),'OK',font=font_tag,fill=BG)
    d.text((240,y-2),c,font=font_body,fill=WHITE)
    y+=105
center_text(d, 1510, '留言告訴我：你最常叫學生畫哪一種圖？', font_body, PINK, 860)
slides.append(('slide_05_cta.png',img))

manifest=[]
for name,img in slides:
    path=SLIDES/name
    img.save(path, quality=95)
    manifest.append({'file': str(path.relative_to(BASE)), 'size': img.size, 'mode': img.mode})

# contact sheet 3+2 layout
thumb_w, thumb_h = 324, 576
sheet = Image.new('RGB',(1180, 1370),(9,14,24))
sd=ImageDraw.Draw(sheet)
sd.text((40,30),'AI 解釋太順時，請學生畫圖驗證｜Storyboard QA',font=F(38),fill=WHITE)
positions=[(40,110),(428,110),(816,110),(234,740),(622,740)]
for i,(name,img) in enumerate(slides):
    thumb=img.resize((thumb_w,thumb_h), Image.LANCZOS)
    x,y=positions[i]
    sheet.paste(thumb,(x,y))
    sd.rectangle((x,y,x+thumb_w,y+thumb_h),outline=(67,89,125),width=3)
    sd.text((x,y+thumb_h+12),f'{i+1}. {name}',font=F(22),fill=MUTED)
sheet.save(CHECKS/'contact_sheet.png', quality=95)

(BASE/'manifest.json').write_text(json.dumps({'project':'draw-to-verify-ai-explanation-20260510','slides':manifest,'contact_sheet':'checks/contact_sheet.png'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'base':str(BASE),'slides':len(slides),'contact_sheet':str(CHECKS/'contact_sheet.png')},ensure_ascii=False))
