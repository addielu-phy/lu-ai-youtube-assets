#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/draw-to-verify-ai-explanation-20260510')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
CHECKS.mkdir(exist_ok=True)
FONT_PATH = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W, H = 1080, 1920
BG = (13, 20, 33)
PANEL = (25, 38, 61)
CYAN = (83, 220, 255)
YELLOW = (255, 206, 84)
PINK = (255, 112, 160)
GREEN = (112, 232, 168)
WHITE = (248, 250, 252)
MUTED = (172, 188, 210)
F = lambda size: ImageFont.truetype(FONT_PATH, size)

def wrap_text(text, font, max_width):
    lines, cur = [], ''
    for ch in text:
        test = cur + ch
        if font.getlength(test) <= max_width or not cur:
            cur = test
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines

def center(draw, y, text, font, fill=WHITE, max_width=900, gap=14):
    yy = y
    for part in text.split('\n'):
        for line in wrap_text(part, font, max_width):
            box = draw.textbbox((0, 0), line, font=font)
            draw.text(((W - (box[2]-box[0]))/2, yy), line, font=font, fill=fill)
            yy += (box[3]-box[1]) + gap
    return yy

# Cover: simpler than slide 1 for YouTube cover readability.
img = Image.new('RGB', (W, H), BG)
d = ImageDraw.Draw(img)
d.rounded_rectangle((70, 64, 1010, 134), radius=28, fill=(23, 35, 56), outline=CYAN, width=3)
center(d, 84, 'AI 解釋審稿課', F(32), MUTED, 820)
center(d, 250, 'AI 解釋太順？', F(98), YELLOW, 940, 18)
center(d, 400, '先畫圖驗證', F(112), WHITE, 930, 18)
d.rounded_rectangle((110, 650, 970, 1050), radius=48, fill=PANEL, outline=CYAN, width=6)
center(d, 725, '學生只要畫 3 件事', F(60), WHITE, 780)
items = ['分析誰', '箭頭往哪', '正方向怎麼定']
y = 850
for item, color in zip(items, [CYAN, YELLOW, GREEN]):
    d.rounded_rectangle((210, y, 870, y+76), radius=32, fill=(18, 28, 45), outline=color, width=3)
    center(d, y+16, item, F(38), color, 590)
    y += 105
# footer safe above Shorts UI danger area
d.rounded_rectangle((135, 1380, 945, 1540), radius=34, fill=(42, 28, 44), outline=PINK, width=4)
center(d, 1428, '越順，越要驗證', F(54), PINK, 760)
center(d, 1635, '5 分鐘課堂活動', F(44), MUTED, 860)
cover = BASE / 'cover_draw_to_verify_ai_explanation_v1.png'
img.save(cover, quality=95)

# ffconcat matching ~34.8s narration.
durations = [5.4, 7.0, 8.0, 7.0, 7.376]
slide_names = ['slide_01_hook.png','slide_02_problem.png','slide_03_three_steps.png','slide_04_activity.png','slide_05_cta.png']
concat = BASE / 'slides_concat_35s.ffconcat'
with concat.open('w', encoding='utf-8') as f:
    f.write('ffconcat version 1.0\n')
    for name, dur in zip(slide_names, durations):
        f.write(f"file '{(SLIDES/name).as_posix()}'\n")
        f.write(f'duration {dur:.3f}\n')
    f.write(f"file '{(SLIDES/slide_names[-1]).as_posix()}'\n")

manifest_path = BASE / 'manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
manifest.update({
    'cover': cover.relative_to(BASE).as_posix(),
    'narration': 'narration_35s.txt',
    'audio': 'narration_35s_edge_hsiaoyu.mp3',
    'subtitles': 'narration_35s_edge_hsiaoyu.vtt',
    'concat': concat.relative_to(BASE).as_posix(),
    'draft_mp4': 'draw-to-verify-ai-explanation-35s-v1.mp4',
    'duration_plan_seconds': sum(durations),
})
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'cover': str(cover), 'concat': str(concat), 'duration_plan_seconds': sum(durations)}, ensure_ascii=False))
