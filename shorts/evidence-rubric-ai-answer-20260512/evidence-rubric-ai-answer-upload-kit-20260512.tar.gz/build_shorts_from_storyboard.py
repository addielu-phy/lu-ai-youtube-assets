#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, subprocess, os, textwrap, tarfile, shutil
BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/evidence-rubric-ai-answer-20260512')
W,H=1080,1920
font_candidates=[
 '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
 '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
 '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
 '/usr/share/fonts/truetype/arphic/uming.ttc',
]
def font(size,bold=False):
    paths = font_candidates[:]
    if bold:
        paths = ['/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'] + paths
    for p in paths:
        if Path(p).exists(): return ImageFont.truetype(p,size)
    return ImageFont.load_default()
def wrap(draw,text,ft,max_w):
    lines=[]
    for para in text.split('\n'):
        cur=''
        for ch in para:
            test=cur+ch
            if draw.textbbox((0,0),test,font=ft)[2] <= max_w:
                cur=test
            else:
                if cur: lines.append(cur)
                cur=ch
        if cur: lines.append(cur)
    return lines
# cover
cover=Image.new('RGB',(W,H),(247,249,252)); d=ImageDraw.Draw(cover)
# background panels
d.rectangle([0,0,W,260], fill=(27,56,92)); d.rectangle([70,330,1010,1570], fill=(255,255,255), outline=(224,231,241), width=6)
d.rounded_rectangle([105,360,975,660], radius=36, fill=(255,244,219), outline=(238,190,89), width=4)
d.text((130,410),'AI 答案對一半', font=font(70,True), fill=(33,43,56))
d.text((130,535),'分數怎麼給？', font=font(80,True), fill=(204,87,66))
ft=font(48); y=760
for line in ['不是只看對錯，','而是看證據夠不夠。','四格規準：概念・證據・條件・圖像／單位']:
    for l in wrap(d,line,ft,820):
        d.text((130,y),l,font=ft,fill=(45,58,75)); y+=70
    y+=18
# rubric mini cards
labels=[('概念','說清楚'),('證據','接結論'),('條件','沒偷換'),('圖像／單位','能支持')]
colors=[(92,132,190),(87,158,123),(216,134,74),(146,110,188)]
x0,y0=130,1160
for i,(a,b) in enumerate(labels):
    x=x0+(i%2)*430; y=y0+(i//2)*185
    d.rounded_rectangle([x,y,x+380,y+135], radius=28, fill=colors[i])
    d.text((x+28,y+24),a,font=font(44,True),fill='white')
    d.text((x+28,y+78),b,font=font(34),fill='white')
d.rectangle([0,1710,W,H], fill=(27,56,92))
d.text((95,1758),'把懷疑變成評分規準', font=font(56,True), fill='white')
d.text((95,1842),'YouTube Shorts 草稿封面', font=font(32), fill=(210,225,243))
cover.save(BASE/'cover_evidence_rubric_ai_answer_v1.png')
# concat file: hold 5 slides for 7s = 35s
concat=BASE/'ffconcat_slides.txt'
with concat.open('w',encoding='utf-8') as f:
    f.write('ffconcat version 1.0\n')
    for i in range(1,6):
        f.write(f"file 'slides/slide_{i:02d}.png'\n")
        f.write('duration 7.0\n')
    f.write("file 'slides/slide_05.png'\n")
# make mp4 with padded audio to 35s
out=BASE/'evidence-rubric-ai-answer-shorts-35s.mp4'
cmd=['ffmpeg','-y','-safe','0','-f','concat','-i',str(concat),'-i',str(BASE/'narration_35s_edge_hsiaoyu.mp3'),'-vf','fps=25,format=yuv420p','-af','apad','-t','35.0','-c:v','libx264','-preset','veryfast','-crf','20','-c:a','aac','-b:a','128k',str(out)]
subprocess.run(cmd,check=True,cwd=BASE)
# simple SRT from VTT cues
vtt=(BASE/'narration_35s_edge_hsiaoyu.vtt').read_text(encoding='utf-8')
srt=[]; idx=1
for block in [b.strip() for b in vtt.split('\n\n') if '-->' in b]:
    lines=block.splitlines(); cue=[l for l in lines if '-->' in l][0]
    text='\n'.join(l for l in lines if '-->' not in l and not l.startswith('WEBVTT'))
    if text.strip():
        srt.append(str(idx)); srt.append(cue.replace('.',',')); srt.append(text.strip()); srt.append(''); idx+=1
(BASE/'narration_35s_edge_hsiaoyu.srt').write_text('\n'.join(srt),encoding='utf-8')
# extract frames and contact sheet
checks=BASE/'checks'; checks.mkdir(exist_ok=True)
for name,ss in [('frame_hook.png','1.5'),('frame_mid.png','16.0'),('frame_cta.png','32.0')]:
    subprocess.run(['ffmpeg','-y','-ss',ss,'-i',str(out),'-frames:v','1',str(checks/name)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
imgs=[Image.open(BASE/'cover_evidence_rubric_ai_answer_v1.png'),Image.open(checks/'frame_hook.png'),Image.open(checks/'frame_mid.png'),Image.open(checks/'frame_cta.png')]
thumbs=[]
for im in imgs:
    im=im.copy(); im.thumbnail((360,640)); thumbs.append(im)
sheet=Image.new('RGB',(840,1440),(240,244,249)); sd=ImageDraw.Draw(sheet)
labels=['cover','hook','middle','cta']
for i,im in enumerate(thumbs):
    x=50+(i%2)*410; y=70+(i//2)*690
    sheet.paste(im,(x,y+40)); sd.text((x,y),labels[i],font=font(28),fill=(30,40,55))
sheet.save(checks/'qa_sheet_video_v1.png')
# ffprobe info
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,avg_frame_rate,pix_fmt,sample_rate,channels','-show_entries','format=duration,size','-of','json',str(out)],text=True))
# upload kit
upload = '''# YouTube Upload Kit｜讓學生幫 AI 打分：不是對錯，是證據夠不夠\n\n## 建議標題\n1. 讓學生幫 AI 打分：不是對錯，是證據夠不夠\n2. AI 答案對一半，老師怎麼評分？\n3. 4 格規準：讓學生判斷 AI 回答能不能信\n\n## Shorts 說明\nAI 答案看起來很順，不代表證據足夠。這支 Shorts 示範用「概念、證據、條件、圖像／單位」四格規準，讓學生練習替 AI 回答打分，並寫出一句扣分理由。\n\n## Hashtags\n#AI教學 #物理教學 #教師備課 #AI素養 #評量規準\n\n## 置頂留言\n你會把「證據夠不夠」放進學生檢查 AI 答案的規準嗎？留言寫一格你最想先檢查的項目。\n\n## 檔案\n- 影片：`evidence-rubric-ai-answer-shorts-35s.mp4`\n- 封面：`cover_evidence_rubric_ai_answer_v1.png`\n- 旁白：`narration_35s_edge_hsiaoyu.mp3`\n- 字幕：`narration_35s_edge_hsiaoyu.vtt` / `narration_35s_edge_hsiaoyu.srt`\n- QA：`checks/qa_sheet_video_v1.png`\n\n## 人工卡點\n需要使用者在已登入 Google / YouTube 的環境中建立頻道或上傳影片；本機素材已可交接。\n'''
(BASE/'youtube-upload-kit.md').write_text(upload,encoding='utf-8')
manifest=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
manifest.setdefault('files', [])
manifest.setdefault('verified', {})
manifest['format']='Shorts 35s MP4 upload package'
manifest['status']='storyboard expanded into 35s zh-TW narrated Shorts draft, cover, subtitles, upload kit, QA sheet, and archive'
manifest['next_auto_push']='pick next unfinished second-season Shorts/storyboard or handout if YouTube login remains blocked'
for f in ['README.md','manifest.json','render_storyboard.py','checks/contact_sheet.png','slides/slide_01.png','slides/slide_02.png','slides/slide_03.png','slides/slide_04.png','slides/slide_05.png','build_shorts_from_storyboard.py','narration_35s.txt','narration_35s_edge_hsiaoyu.mp3','narration_35s_edge_hsiaoyu.vtt','narration_35s_edge_hsiaoyu.srt','evidence-rubric-ai-answer-shorts-35s.mp4','cover_evidence_rubric_ai_answer_v1.png','youtube-upload-kit.md','checks/qa_sheet_video_v1.png','checks/frame_hook.png','checks/frame_mid.png','checks/frame_cta.png','ffconcat_slides.txt']:
    if f not in manifest['files']: manifest['files'].append(f)
manifest['verified']['ffprobe']=probe
manifest['verified']['video_qa']='passed after second vision QA: Traditional Chinese readable; no tofu/cropping/overlap/overcrowding; cover title spacing, middle line break, and QA labels fixed'
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
# archive
archive=BASE/'evidence-rubric-ai-answer-upload-kit-20260512.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for rel in manifest['files']:
        p=BASE/rel
        if p.exists(): tf.add(p,arcname=f'evidence-rubric-ai-answer-20260512/{rel}')
# verify archive names
with tarfile.open(archive,'r:gz') as tf:
    names=tf.getnames()
(BASE/'checks/archive_listing.txt').write_text('\n'.join(names),encoding='utf-8')
print(json.dumps({'mp4':str(out),'archive':str(archive),'duration':probe['format']['duration'],'archive_count':len(names)},ensure_ascii=False,indent=2))
