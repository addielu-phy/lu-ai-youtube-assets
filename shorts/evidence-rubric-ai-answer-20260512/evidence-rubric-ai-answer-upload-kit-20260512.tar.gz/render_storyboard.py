from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, tarfile

BASE = Path('/home/adl/youtube-lu-ai-channel')
PKG = BASE / 'shorts' / 'evidence-rubric-ai-answer-20260512'
SLIDES = PKG / 'slides'
CHECKS = PKG / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
W, H = 1080, 1920
FONT_CANDIDATES = [
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
    '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    '/usr/share/fonts/truetype/arphic/uming.ttc',
]

def font_path():
    for p in FONT_CANDIDATES:
        if Path(p).exists():
            return p
    return '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'

FP = font_path()
def f(size):
    return ImageFont.truetype(FP, size)

def wrap(draw, text, font, max_width):
    lines = []
    for para in text.split('\n'):
        cur = ''
        for ch in para:
            test = cur + ch
            if draw.textbbox((0, 0), test, font=font)[2] <= max_width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = ch
        if cur:
            lines.append(cur)
    return lines

def draw_text_box(draw, xy, text, font, fill, max_width, line_gap=12):
    x, y = xy
    for line in wrap(draw, text, font, max_width):
        draw.text((x, y), line, font=font, fill=fill)
        y += font.size + line_gap
    return y

slides = [
    {'k':'HOOK','title':'答案對一半，\n分數怎麼給？','body':'不要只問：對不對。\n先問：證據夠不夠。','tag':'第二季優先題 8'},
    {'k':'CASE','title':'AI 回答看起來很順','body':'例：它說「摩擦力變大，速度就變小」。\n句子像答案，但少了條件、方向、圖像證據。','tag':'假答案示範'},
    {'k':'RUBRIC','title':'四格評分規準','body':'1 概念是否正確\n2 證據是否對題\n3 條件是否說清楚\n4 圖像／單位是否一致','tag':'老師可直接複製'},
    {'k':'ACTIVITY','title':'讓學生幫 AI 打分','body':'每組先給 0–2 分。\n再補一句：\n「我扣分是因為……」','tag':'課堂 5 分鐘活動'},
    {'k':'CTA','title':'把懷疑變成規準','body':'AI 不是答案販賣機。\n它是學生練習判斷證據的材料。','tag':'下一步：MP4／講義'},
]
BG=(18,24,38); CARD=(248,250,252); CYAN=(56,189,248); YELLOW=(250,204,21); RED=(248,113,113); GREEN=(74,222,128); INK=(17,24,39)
footers=['老師把關句：證據在哪裡？','老師把關句：這句有條件嗎？','老師把關句：給分前先找證據','學生句型：我扣分是因為……','結尾：把 AI 變成可評分材料']
for i, s in enumerate(slides, 1):
    im = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([54,58,1026,180], radius=34, fill=(30,41,59), outline=CYAN, width=3)
    d.text((88,90), s['k'], font=f(52), fill=YELLOW)
    d.text((720,104), s['tag'], font=f(30), fill=(203,213,225))
    d.rounded_rectangle([70,260,1010,1550], radius=46, fill=CARD)
    d.rounded_rectangle([110,310,970,520], radius=34, fill=(239,246,255), outline=(125,211,252), width=3)
    draw_text_box(d, (140,330), s['title'], f(72), INK, 800, 18)
    if i == 3:
        colors=[CYAN,YELLOW,GREEN,RED]
        items=['概念正確','證據切題','條件清楚','圖像一致']
        for idx, it in enumerate(items):
            x = 140 + (idx % 2) * 430
            yy = 660 + (idx // 2) * 210
            d.rounded_rectangle([x, yy, x+360, yy+160], radius=28, fill=(255,255,255), outline=colors[idx], width=5)
            d.text((x+32, yy+36), str(idx+1), font=f(58), fill=colors[idx])
            draw_text_box(d, (x+104, yy+50), it, f(43), INK, 210, 10)
        draw_text_box(d, (140,1180), '給 AI 回答打分時，\n先看「證據鏈」，不是只看結論。', f(48), INK, 780, 14)
    else:
        draw_text_box(d, (140,610), s['body'], f(55), INK, 800, 18)
    d.rounded_rectangle([96,1605,984,1788], radius=34, fill=(15,23,42), outline=(148,163,184), width=2)
    draw_text_box(d, (136,1650), footers[i-1], f(45), (248,250,252), 800, 14)
    d.text((500,1836), f'{i}/5', font=f(42), fill=(148,163,184))
    im.save(SLIDES / f'slide_{i:02d}.png')

sheet = Image.new('RGB', (1120, 1440), (226,232,240))
sd = ImageDraw.Draw(sheet)
for idx in range(5):
    im = Image.open(SLIDES / f'slide_{idx+1:02d}.png').resize((320,569))
    if idx < 3:
        x, y = 35 + idx*360, 40
    else:
        x, y = 215 + (idx-3)*360, 760
    sheet.paste(im, (x,y))
    sd.text((x, y+578), f'slide {idx+1}', font=f(24), fill=(15,23,42))
sheet.save(CHECKS / 'contact_sheet.png')

readme = '''# 第二季優先題 8｜讓學生幫 AI 打分：不是對錯，是證據夠不夠

狀態：本機 Shorts storyboard 包完成，尚未做旁白／MP4。

## 30 秒製作簡報
- 3 秒鉤子：答案對一半時，分數怎麼給？
- 核心觀點：不要只問 AI 答案「對不對」，要讓學生用規準判斷「證據夠不夠」。
- 老師把關句：證據在哪裡？這句有條件嗎？
- 課堂延伸：4 格評分規準（概念、證據、條件、圖像／單位）＋一句扣分理由。

## 圖卡
1. `slides/slide_01.png` Hook：答案對一半，分數怎麼給？
2. `slides/slide_02.png` Case：AI 回答看起來很順，但缺證據。
3. `slides/slide_03.png` Rubric：四格評分規準。
4. `slides/slide_04.png` Activity：讓學生幫 AI 打分。
5. `slides/slide_05.png` CTA：把懷疑變成規準。

## 已驗證
- 5 張圖卡皆為 1080×1920 RGB。
- `checks/contact_sheet.png` 為 1120×1440 RGB，用於手機快速審閱。
- 壓縮包：`evidence-rubric-ai-answer-storyboard-kit-20260512.tar.gz`。

## 下一個可自動推進項目
若 YouTube/Google 登入仍未完成，下一輪可把本 storyboard 擴成 35 秒 zh-TW 旁白、VTT/SRT、MP4、封面與 YouTube upload kit；或先延伸成「AI 回答證據評分規準」可列印講義。
'''
(PKG / 'README.md').write_text(readme, encoding='utf-8')
manifest = {
    'id': 'season02-priority08-evidence-rubric-ai-answer',
    'title': '讓學生幫 AI 打分：不是對錯，是證據夠不夠',
    'format': 'Shorts storyboard package',
    'created': '2026-05-12',
    'dimensions': '1080x1920 RGB for five slides',
    'next_auto_push': 'expand storyboard into 35s zh-TW narration/VTT/MP4/cover/upload kit, or extend into printable AI-answer evidence rubric handout',
    'files': []
}
(PKG / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
archive = PKG / 'evidence-rubric-ai-answer-storyboard-kit-20260512.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for rel in ['README.md','manifest.json','render_storyboard.py']:
        tf.add(PKG/rel, arcname=f'evidence-rubric-ai-answer-20260512/{rel}')
    for sub in ['slides','checks']:
        for p in sorted((PKG/sub).glob('*')):
            tf.add(p, arcname=f'evidence-rubric-ai-answer-20260512/{sub}/{p.name}')
print(f'rendered {PKG}')
