from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap, json
BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/three-questions-ai-trust-20260509')
SLIDES = BASE/'slides'
CHECKS = BASE/'checks'
SLIDES.mkdir(parents=True, exist_ok=True); CHECKS.mkdir(exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(size):
    return ImageFont.truetype(FONT, size)
W,H = 1080,1920
BG = (14, 22, 38)
CARD = (247, 243, 232)
YELLOW = (255, 204, 92)
RED = (237, 86, 86)
CYAN = (94, 221, 220)
INK = (30, 36, 50)
WHITE = (250,250,250)
slides = [
('slide_01_hook.png','答案看起來對，\n先別急著信','學生要問哪三題？','AI 很順 ≠ 可以直接抄',YELLOW),
('slide_02_question_1.png','第一問','AI 有沒有\n偷偷改條件？','原題條件 → AI 回答\n數字、方向、限制都要對上',RED),
('slide_03_question_2.png','第二問','單位和量級\n合理嗎？','單位不合、量級荒謬\n先暫停，不急著重算',CYAN),
('slide_04_question_3.png','第三問','畫圖後\n還說得通嗎？','受力圖、運動圖、電路圖\n能抓出漂亮但空的解釋',YELLOW),
('slide_05_classroom_use.png','課堂用法','先三問，\n再決定要不要重算','留言「三問」\n下一支做成學生小卡',CYAN),
]
def round_rect(draw, xy, r, fill, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)
def multiline_center(draw, text, y, fnt, fill, spacing=18, max_width=14):
    lines=[]
    for part in text.split('\n'):
        if len(part)>max_width:
            lines += textwrap.wrap(part, width=max_width)
        else: lines.append(part)
    total=sum(draw.textbbox((0,0), ln, font=fnt)[3] for ln in lines)+spacing*(len(lines)-1)
    yy=y-total//2
    for ln in lines:
        bbox=draw.textbbox((0,0), ln, font=fnt)
        draw.text(((W-(bbox[2]-bbox[0]))/2, yy), ln, font=fnt, fill=fill)
        yy += (bbox[3]-bbox[1])+spacing
for idx,(fn,kicker,title,body,accent) in enumerate(slides,1):
    im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    # top accent
    d.rectangle((0,0,W,22), fill=accent)
    round_rect(d,(82,118,998,326),44,fill=(24,36,60),outline=accent,width=4)
    # Top label may wrap on slide 1; draw with smaller font + explicit spacing to avoid crowding.
    d.multiline_text((120,158), kicker, font=font(56), fill=WHITE, spacing=10)
    # main card
    round_rect(d,(82,390,998,1188),56,fill=CARD,outline=accent,width=8)
    multiline_center(d,title,790,font(104),INK,spacing=24,max_width=8)
    # simple visual motif
    if idx==1:
        d.ellipse((408,1240,672,1504), outline=accent, width=12); d.text((452,1300),'AI',font=font(92),fill=accent)
        d.line((540,1512,540,1610), fill=accent, width=10); d.line((500,1570,540,1610,580,1570), fill=accent, width=10)
    elif idx==2:
        d.text((150,1260),'原題',font=font(54),fill=WHITE); d.text((730,1260),'AI',font=font(54),fill=WHITE)
        d.line((320,1295,690,1295), fill=RED, width=10); d.line((650,1255,695,1295,650,1335), fill=RED, width=10)
        d.text((210,1395),'條件 A',font=font(52),fill=YELLOW); d.text((660,1395),'條件 B?',font=font(52),fill=RED)
    elif idx==3:
        d.text((190,1280),'m/s',font=font(86),fill=CYAN); d.text((625,1280),'km/h',font=font(86),fill=YELLOW)
        d.text((260,1425),'約 1億？',font=font(90),fill=RED)
    elif idx==4:
        d.line((200,1500,880,1500),fill=WHITE,width=8); d.line((540,1280,540,1680),fill=WHITE,width=8)
        d.line((540,1500,780,1370),fill=YELLOW,width=12); d.line((730,1358,780,1370,748,1412),fill=YELLOW,width=12)
    else:
        for i,txt in enumerate(['條件','單位','圖像']):
            y=1260+i*145
            round_rect(d,(210,y,870,y+100),30,fill=(24,36,60),outline=accent,width=4)
            d.text((425,y+22), txt, font=font(52), fill=WHITE)
            # Avoid checkmark glyph tofu in CJK font; use ASCII OK badge instead.
            d.text((742,y+24),'OK',font=font(46),fill=accent)
    # body footer
    round_rect(d,(82,1660,998,1816),38,fill=(24,36,60),outline=None)
    multiline_center(d,body,1738,font(48),WHITE,spacing=8,max_width=17)
    im.save(SLIDES/fn, quality=95)
# contact sheet 3+2, large enough
thumb_w, thumb_h = 324,576
sheet = Image.new('RGB',(1160,1440),(245,245,245)); sd=ImageDraw.Draw(sheet)
positions=[(44,54),(418,54),(792,54),(230,784),(604,784)]
for i,(fn,_,_,_,_) in enumerate(slides):
    im=Image.open(SLIDES/fn).resize((thumb_w,thumb_h), Image.LANCZOS)
    x,y=positions[i]; sheet.paste(im,(x,y))
    sd.text((x,y+thumb_h+16),f'{i+1}. {fn}',font=font(24),fill=(20,20,20))
sheet.save(CHECKS/'contact_sheet.png')
