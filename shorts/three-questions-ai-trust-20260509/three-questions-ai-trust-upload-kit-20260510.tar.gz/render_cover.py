from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
BASE=Path('/home/adl/youtube-lu-ai-channel/shorts/three-questions-ai-trust-20260509')
FONT='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(s): return ImageFont.truetype(FONT,s)
W,H=1080,1920
BG=(14,22,38); CARD=(247,243,232); YELLOW=(255,204,92); CYAN=(94,221,220); RED=(237,86,86); WHITE=(250,250,250); INK=(30,36,50)
im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
d.rectangle((0,0,W,26), fill=CYAN)
d.rounded_rectangle((70,120,1010,290), radius=44, fill=(24,36,60), outline=CYAN, width=5)
d.text((120,172),'學生判斷 AI 答案',font=font(64),fill=WHITE)
d.rounded_rectangle((70,390,1010,1245), radius=60, fill=CARD, outline=YELLOW, width=10)
# big title centered
lines=['能信嗎？','先問這 3 題']
y=575
for i,line in enumerate(lines):
    f=font(128 if i==0 else 106)
    bbox=d.textbbox((0,0),line,font=f)
    d.text(((W-(bbox[2]-bbox[0]))/2,y), line, font=f, fill=INK if i else RED)
    y += 175
# three chips
chips=[('1','條件有變嗎？'),('2','單位合理嗎？'),('3','畫圖說得通嗎？')]
y=980
for n,txt in chips:
    d.rounded_rectangle((150,y,930,y+96), radius=30, fill=(24,36,60), outline=CYAN, width=4)
    d.ellipse((180,y+18,238,y+76), fill=YELLOW)
    nb=d.textbbox((0,0),n,font=font(42)); d.text((209-(nb[2]-nb[0])/2,y+26),n,font=font(42),fill=INK)
    d.text((275,y+23),txt,font=font(46),fill=WHITE)
    y += 116
# lower classroom motif
d.rounded_rectangle((90,1460,990,1640), radius=42, fill=(24,36,60))
d.text((160,1512),'不是叫學生抄 AI，\n是訓練學生檢查 AI。',font=font(48),fill=WHITE,spacing=8)
d.text((120,1740),'留言「三問」下一支做學生小卡',font=font(42),fill=YELLOW)
im.save(BASE/'cover_three_questions_ai_trust_v1.png', quality=95)
