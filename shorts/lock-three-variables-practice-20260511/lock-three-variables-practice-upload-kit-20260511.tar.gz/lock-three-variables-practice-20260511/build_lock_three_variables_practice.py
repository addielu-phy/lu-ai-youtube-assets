from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import json, textwrap, subprocess, math

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/lock-three-variables-practice-20260511')
SLIDES = BASE/'slides'
CHECKS = BASE/'checks'
for p in [SLIDES, CHECKS]:
    p.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W,H = 1080,1920
BG = (11,18,32)
BLUE = (77,163,255)
CYAN = (104,224,207)
YELLOW = (255,211,105)
RED = (255,112,112)
WHITE = (246,248,252)
MUTED = (180,190,205)
CARD = (246,248,252)
INK = (19,29,46)

def font(size):
    return ImageFont.truetype(FONT, size)

def wrap(draw, text, fnt, max_w):
    out=[]
    for para in text.split('\n'):
        line=''
        for ch in para:
            test=line+ch
            if draw.textbbox((0,0), test, font=fnt)[2] <= max_w:
                line=test
            else:
                if line: out.append(line)
                line=ch
        if line: out.append(line)
    return out

def text_block(draw, xy, text, fnt, fill, max_w, line_gap=12, anchor=None):
    x,y=xy
    lines=wrap(draw,text,fnt,max_w)
    for line in lines:
        draw.text((x,y), line, font=fnt, fill=fill, anchor=anchor)
        y += fnt.size + line_gap
    return y

def round_rect(draw, box, r, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)

def base_draw(idx, title, subtitle):
    img=Image.new('RGB',(W,H),BG)
    d=ImageDraw.Draw(img)
    # soft background grid
    for x in range(80,W,180):
        d.line((x,0,x,H), fill=(16,27,47), width=2)
    for y in range(120,H,220):
        d.line((0,y,W,y), fill=(16,27,47), width=2)
    d.ellipse((-250,-180,460,430), fill=(22,60,102))
    d.ellipse((680,1450,1280,2080), fill=(19,72,73))
    round_rect(d,(70,70,1010,180),38,(20,35,60),outline=(48,90,140),width=3)
    d.text((105,100), f'第二季 Shorts｜{idx}/5', font=font(36), fill=CYAN)
    d.text((70,230), title, font=font(72), fill=WHITE)
    text_block(d,(74,330),subtitle,font(42),YELLOW,920,10)
    return img,d

slides = []
# 1
img,d=base_draw(1,'AI 分層練習題','分層不是變簡單\n是先鎖住三個變因')
round_rect(d,(90,560,990,1180),52,CARD)
text_block(d,(140,625),'同一個概念，AI 可以一秒產三層題。',font(54),INK,800,16)
text_block(d,(140,820),'但如果每一題都同時改數字、情境、圖像——學生到底在練什麼？',font(46),(45,58,80),800,14)
d.text((140,1090),'老師把關句：先鎖變因，再談難度。',font=font(42),fill=RED)
slides.append((img,'slide_01_hook.png'))
# 2
img,d=base_draw(2,'第一鎖：概念','三層題都要練同一個核心')
round_rect(d,(90,530,990,1290),52,CARD)
text_block(d,(140,600),'先寫一句學習目標：',font(48),INK,800,10)
round_rect(d,(140,720,940,900),32,(232,242,255),outline=(112,162,220),width=3)
text_block(d,(180,755),'學生能判斷「淨力方向」\n和「加速度方向」的關係。',font(44),INK,720,8)
text_block(d,(140,980),'AI 產題後，每一層都回頭對照這一句。',font(46),(45,58,80),800,14)
d.text((140,1190),'若概念變了，這不是分層，是換題。',font=font(42),fill=RED)
slides.append((img,'slide_02_concept.png'))
# 3
img,d=base_draw(3,'第二鎖：表示法','文字、圖像、表格不要一次全換')
round_rect(d,(90,510,990,1340),52,CARD)
labels=[('Level 1','純文字題',YELLOW),('Level 2','同文字＋多一張圖',CYAN),('Level 3','同圖＋要求解釋理由',BLUE)]
y=590
for lab,body,col in labels:
    round_rect(d,(140,y,940,y+150),28,(238,244,252),outline=col,width=4)
    d.text((175,y+30),lab,font=font(38),fill=(30,45,70))
    d.text((390,y+35),body,font=font(44),fill=INK)
    y+=190
text_block(d,(140,1190),'一次只改一種表示法，學生才知道困難來自哪裡。',font(42),(45,58,80),800,12)
slides.append((img,'slide_03_representation.png'))
#4
img,d=base_draw(4,'第三鎖：數字範圍','數字變大，不等於題目變好')
round_rect(d,(90,510,990,1350),52,CARD)
text_block(d,(140,585),'先固定：單位、量級、可計算範圍。',font(48),INK,800,12)
# sliders
for i,(name,val,col) in enumerate([('質量 0.5–5 kg','OK',CYAN),('力 1–50 N','OK',CYAN),('摩擦係數 0–1','OK',CYAN)]):
    y=780+i*150
    d.text((150,y),name,font=font(40),fill=(45,58,80))
    round_rect(d,(510,y+10,890,y+58),24,(220,230,242))
    d.rectangle((535,y+24,760,y+43),fill=col)
    d.ellipse((745,y+2,805,y+62),fill=col)
    d.text((815,y+4),val,font=font(36),fill=INK)
text_block(d,(140,1240),'超出範圍時，先問：這還像真實物理情境嗎？',font(38),RED,800,8)
slides.append((img,'slide_04_numbers.png'))
#5
img,d=base_draw(5,'給 AI 的一句 prompt','請先產出「可檢查」的三層題')
round_rect(d,(90,500,990,1390),52,CARD)
prompt='請用同一個學習目標，產生三層練習題。每一層只改一個變因：概念不變、表示法逐步增加、數字範圍合理。最後列出你改了哪一個變因。'
text_block(d,(145,575),prompt,font(44),INK,790,12)
round_rect(d,(145,1095,935,1280),30,(255,246,219),outline=YELLOW,width=3)
text_block(d,(180,1130),'老師最後檢查：三層題真的只差一個變因嗎？',font(40),INK,720,10)
# 不放小字署名，避免手機縮圖把「盧」誤讀；品牌文字保留在 README / upload kit。
slides.append((img,'slide_05_prompt.png'))

slide_paths=[]
for img,name in slides:
    path=SLIDES/name
    img.save(path, quality=95)
    slide_paths.append(str(path))
# cover from slide 1 with extra text
cover=slides[0][0].copy(); d=ImageDraw.Draw(cover)
round_rect(d,(135,1340,945,1590),42,(255,211,105),outline=None)
d.text((180,1375),'分層三鎖',font=font(92),fill=INK)
d.text((180,1490),'概念｜表示法｜數字範圍',font=font(44),fill=INK)
cover_path=BASE/'cover_lock_three_variables_practice_v1.png'; cover.save(cover_path, quality=95)
# contact sheet 3+2 large
thumbs=[]
for p in slide_paths+[str(cover_path)]:
    im=Image.open(p).resize((270,480))
    thumbs.append((p,im))
sheet=Image.new('RGB',(900,1100),(245,247,250)); sd=ImageDraw.Draw(sheet)
for idx,(p,im) in enumerate(thumbs):
    x=30+(idx%3)*290; y=35+(idx//3)*525
    sheet.paste(im,(x,y)); sd.text((x,y+488),Path(p).name[:22],font=font(22),fill=(30,40,55))
sheet_path=CHECKS/'contact_sheet.png'; sheet.save(sheet_path)
# narration and subtitles
narration = '''分層練習題，不是把題目變簡單而已。\n老師要先鎖三個變因。\n第一，鎖概念。三層題都要練同一個學習目標。\n第二，鎖表示法。一次只增加文字、圖像或解釋要求中的一種。\n第三，鎖數字範圍。單位、量級和情境要合理。\n你可以這樣請 AI：每一層只改一個變因，最後列出你改了什麼。\n老師最後只檢查一句：三層題真的只差一個變因嗎？'''
(BASE/'narration_35s.txt').write_text(narration,encoding='utf-8')
# coarse vtt/srt placeholders based on 35 sec target
vtt='''WEBVTT\n\n00:00.000 --> 00:04.500\n分層練習題，不是把題目變簡單而已。\n\n00:04.500 --> 00:10.000\n老師要先鎖三個變因：概念、表示法、數字範圍。\n\n00:10.000 --> 00:17.000\n三層題都要練同一個學習目標，一次只改一種表示法。\n\n00:17.000 --> 00:25.000\n數字的單位、量級和情境也要合理。\n\n00:25.000 --> 00:35.000\n最後檢查：三層題真的只差一個變因嗎？\n'''
(BASE/'narration_35s.vtt').write_text(vtt,encoding='utf-8')
srt='''1\n00:00:00,000 --> 00:00:04,500\n分層練習題，不是把題目變簡單而已。\n\n2\n00:00:04,500 --> 00:00:10,000\n老師要先鎖三個變因：概念、表示法、數字範圍。\n\n3\n00:00:10,000 --> 00:00:17,000\n三層題都要練同一個學習目標，一次只改一種表示法。\n\n4\n00:00:17,000 --> 00:00:25,000\n數字的單位、量級和情境也要合理。\n\n5\n00:00:25,000 --> 00:00:35,000\n最後檢查：三層題真的只差一個變因嗎？\n'''
(BASE/'narration_35s.srt').write_text(srt,encoding='utf-8')
manifest={
 'title':'AI 分層練習題：老師要先鎖哪三個變因？',
 'created':'2026-05-11 scheduled autopush',
 'format':'Shorts 1080x1920 static slide draft',
 'slides':[str(Path(p).relative_to(BASE)) for p in slide_paths],
 'cover':cover_path.name,
 'contact_sheet':'checks/contact_sheet.png',
 'narration':'narration_35s.txt',
 'voice':'zh-TW-HsiaoYuNeural via edge-tts',
 'next':'若登入完成，上傳；否則可延伸成可列印「三鎖檢查表」。'
}
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
README=f'''# AI 分層練習題：老師要先鎖哪三個變因？\n\n狀態：第二季優先題 5 Shorts 本機草稿包；執行 edge-tts／ffmpeg 後可組成完整 upload kit。\n\n## 內容定位\n- 3 秒鉤子：分層不是變簡單，是控制變因。\n- 老師把關句：先鎖概念、表示法、數字範圍，再請 AI 產三層題。\n- 不使用真實學生資料。\n\n## 已產出\n- 5 張 1080×1920 storyboard 圖卡：`slides/`\n- 封面：`cover_lock_three_variables_practice_v1.png`\n- 旁白草稿：`narration_35s.txt`\n- 字幕：`narration_35s.vtt` / `narration_35s.srt`\n- QA contact sheet：`checks/contact_sheet.png`\n- manifest：`manifest.json`\n\n## 組裝提示\n- edge-tts 產生 zh-TW HsiaoYu 旁白 mp3\n- ffmpeg 組成 9:16 MP4\n- ffprobe、PIL、視覺 QA、壓縮包讀回驗證\n\n## 下一步\n若 YouTube/Google 登入仍未完成，下一個低風險自動推進可做：把本支延伸成教師可列印「三鎖檢查表」。\n'''
(BASE/'README.md').write_text(README,encoding='utf-8')
upload=f'''# YouTube Upload Kit｜AI 分層練習題：老師要先鎖哪三個變因？\n\n## 建議標題\n1. AI 分層練習題：老師要先鎖哪三個變因？\n2. 分層不是變簡單：老師請 AI 出題前先做三鎖\n3. AI 出三層題，先檢查這三件事\n\n## 說明欄\n分層練習題不是只把題目變簡單。老師可以先鎖住三個變因：概念、表示法、數字範圍，再請 AI 產生三層題。最後檢查：三層題真的只差一個變因嗎？\n\n#AI教學 #物理教學 #教師備課 #生成式AI #分層教學\n\n## 置頂留言\n你請 AI 產分層練習時，最容易失控的是概念、圖像，還是數字範圍？\n\n## 封面字\n分層三鎖\n概念｜表示法｜數字範圍\n\n## 人工操作卡點\nYouTube/Google 登入、頻道建立與實際上傳仍需使用者操作。\n'''
(BASE/'youtube-upload-kit.md').write_text(upload,encoding='utf-8')
print(BASE)
