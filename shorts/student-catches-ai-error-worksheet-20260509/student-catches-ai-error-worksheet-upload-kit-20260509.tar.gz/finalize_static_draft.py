
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, tarfile, os, shutil
BASE=Path('/home/adl/youtube-lu-ai-channel/shorts/student-catches-ai-error-worksheet-20260509')
W,H=1080,1920
slides=BASE/'slides'
checks=BASE/'checks'
checks.mkdir(exist_ok=True)
# Validate slides
manifest={"project":"student-catches-ai-error-worksheet-20260509","kind":"youtube-shorts-static-draft","created":"2026-05-09","assets":[]}
for i in range(1,6):
    p=slides/f'slide_{i:02d}.png'
    im=Image.open(p)
    manifest['assets'].append({"file":str(p.relative_to(BASE)),"size":im.size,"mode":im.mode})
    if im.size!=(W,H): raise SystemExit(f'bad slide size {p}: {im.size}')
# Create simple cover from slide 1 with bolder bottom CTA chip
cover=Image.open(slides/'slide_01.png').convert('RGB')
d=ImageDraw.Draw(cover)
def font(size,bold=False):
    candidates=[
        '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc' if bold else '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
        '/usr/share/fonts/truetype/arphic/uming.ttc',
    ]
    for c in candidates:
        if c and Path(c).exists(): return ImageFont.truetype(c,size)
    return ImageFont.load_default()
fb=font(68, True); fm=font(42, False)
# darken lower card and add CTA
x0,y0,x1,y1=80,1470,1000,1735
d.rounded_rectangle([x0,y0,x1,y1], radius=42, fill=(7,17,31), outline=(25,211,255), width=6)
d.text((135,1515),'5 分鐘學習單',font=fb,fill=(255,216,77))
d.text((135,1605),'AI 說法｜我懷疑｜我要驗證',font=fm,fill=(235,245,255))
d.text((135,1670),'留言「抓錯」拿可複製版',font=fm,fill=(25,211,255))
cover_path=BASE/'cover-student-catches-ai-error-worksheet.png'
cover.save(cover_path, quality=95)
manifest['assets'].append({"file":cover_path.name,"size":Image.open(cover_path).size,"mode":Image.open(cover_path).mode})
# ffconcat timings sum around audio duration
segments=[3.2,6.4,8.2,7.2,6.4]
concat=BASE/'slides_concat.ffconcat'
with concat.open('w',encoding='utf-8') as f:
    f.write('ffconcat version 1.0\n')
    for dur,i in zip(segments, range(1,6)):
        f.write(f"file '{(slides/f'slide_{i:02d}.png').as_posix()}'\n")
        f.write(f'duration {dur}\n')
    f.write(f"file '{(slides/'slide_05.png').as_posix()}'\n")
# simple human-friendly VTT aligned to slide durations
lines=[
('00:00.000','00:03.200','今天不是叫學生問 AI，而是叫學生抓 AI。'),
('00:03.200','00:09.600','AI 的答案常常很順，但學生要練的是懷疑。'),
('00:09.600','00:17.800','一張五分鐘學習單，只留三欄：AI 說什麼、我懷疑哪裡、我要怎麼驗證。'),
('00:17.800','00:25.000','老師不用每題重講，改成讓學生圈疑點、找證據、說理由。'),
('00:25.000','00:31.400','想要可複製版，留言「抓錯」，我下一支整理。'),]
vtt=BASE/'student-catches-ai-error-worksheet-35s.vtt'
with vtt.open('w',encoding='utf-8') as f:
    f.write('WEBVTT\n\n')
    for idx,(a,b,t) in enumerate(lines,1):
        f.write(f'{idx}\n{a} --> {b}\n{t}\n\n')
manifest['assets'] += [{"file":"slides_concat.ffconcat"},{"file":"student-catches-ai-error-worksheet-35s.vtt"},{"file":"narration_35s.txt"},{"file":"narration_35s_hsiaoyu.mp3"},{"file":"narration_35s_hsiaoyu.vtt"}]
# Contact sheet with cover + 5 slides
thumbs=[('cover',cover_path)]+[(f'slide {i}',slides/f'slide_{i:02d}.png') for i in range(1,6)]
canvas=Image.new('RGB',(1800,2600),(10,18,32)); dd=ImageDraw.Draw(canvas); fl=font(36,False)
for idx,(label,p) in enumerate(thumbs):
    col=idx%2; row=idx//2; x=80+col*860; y=80+row*820
    im=Image.open(p).convert('RGB'); im.thumbnail((720,720))
    canvas.paste(im,(x+(720-im.width)//2,y))
    dd.text((x,y+730),label,font=fl,fill=(235,245,255))
cs=checks/'final_contact_sheet.png'; canvas.save(cs, quality=92)
manifest['assets'].append({"file":"checks/final_contact_sheet.png","size":canvas.size,"mode":canvas.mode})
(BASE/'manifest-final.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('prepared', BASE)
