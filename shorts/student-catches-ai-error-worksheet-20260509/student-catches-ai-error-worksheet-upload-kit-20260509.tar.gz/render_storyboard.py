from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap, math
BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/student-catches-ai-error-worksheet-20260509')
SLIDES = BASE/'slides'
CHECKS = BASE/'checks'
SLIDES.mkdir(parents=True, exist_ok=True); CHECKS.mkdir(parents=True, exist_ok=True)
W,H=1080,1920
FONT='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(size): return ImageFont.truetype(FONT,size)
def wrap_zh(text, max_chars):
    lines=[]
    for para in text.split('\n'):
        cur=''
        for ch in para:
            cur += ch
            if len(cur)>=max_chars:
                lines.append(cur); cur=''
        if cur: lines.append(cur)
    return lines
palette={
 'bg':(18,24,38),'card':(253,247,232),'ink':(28,38,55),'muted':(96,108,128),
 'cyan':(53,214,226),'yellow':(255,205,72),'red':(255,103,103),'green':(88,222,150),'white':(250,252,255)
}
def rounded(draw, box, fill, outline=None, width=4, r=32):
    draw.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)
def center_text(draw, xy, text, fnt, fill, max_chars=12, gap=10):
    x,y=xy; lines=wrap_zh(text,max_chars)
    heights=[draw.textbbox((0,0),ln,font=fnt)[3] for ln in lines]
    total=sum(heights)+gap*(len(lines)-1)
    yy=y-total/2
    for ln,h in zip(lines,heights):
        bb=draw.textbbox((0,0),ln,font=fnt); tw=bb[2]-bb[0]
        draw.text((x-tw/2,yy),ln,font=fnt,fill=fill)
        yy+=h+gap
def top_brand(draw, idx):
    draw.text((70,70),f'AI-agent × 物理教學｜{idx}/5',font=font(34),fill=palette['cyan'])
    draw.line((70,125,1010,125),fill=(60,75,102),width=3)
def footer(draw, text):
    rounded(draw,(70,1710,1010,1835),fill=(28,38,58),outline=(85,104,140),r=28)
    center_text(draw,(540,1772),text,font(38),palette['white'],max_chars=22,gap=6)
def slide1():
    im=Image.new('RGB',(W,H),palette['bg']); d=ImageDraw.Draw(im); top_brand(d,1)
    d.ellipse((760,190,1040,470),fill=(31,50,73),outline=palette['cyan'],width=5)
    center_text(d,(540,520),'今天不是\n問 AI',font(92),palette['white'],max_chars=6,gap=18)
    center_text(d,(540,760),'是讓學生\n抓 AI',font(112),palette['yellow'],max_chars=6,gap=20)
    rounded(d,(130,1010,950,1440),fill=palette['card'],outline=palette['yellow'],width=7,r=40)
    d.text((190,1080),'課堂活動目標',font=font(42),fill=palette['muted'])
    center_text(d,(540,1260),'從「看答案」\n變成「找證據」',font(62),palette['ink'],max_chars=8,gap=14)
    footer(d,'30 秒：一張 5 分鐘學習單')
    return im
def slide2():
    im=Image.new('RGB',(W,H),palette['bg']); d=ImageDraw.Draw(im); top_brand(d,2)
    center_text(d,(540,270),'AI 答案看起來很順',font(62),palette['white'],max_chars=11)
    rounded(d,(105,410,975,1190),fill=palette['card'],outline=(230,220,190),r=38)
    d.text((160,470),'AI 說：',font=font(44),fill=palette['muted'])
    example='因為力變大，所以速度一定立刻變大；答案選 B。'
    for i,ln in enumerate(wrap_zh(example,13)):
        d.text((160,555+i*72),ln,font=font(58),fill=palette['ink'])
    d.line((145,780,925,780),fill=palette['red'],width=12)
    d.text((160,840),'學生任務：標出你懷疑的地方',font=font(45),fill=palette['red'])
    center_text(d,(540,1370),'順 ≠ 對\n要留下「懷疑點」',font(72),palette['yellow'],max_chars=8,gap=16)
    footer(d,'先練懷疑，不急著抄答案')
    return im
def slide3():
    im=Image.new('RGB',(W,H),palette['bg']); d=ImageDraw.Draw(im); top_brand(d,3)
    center_text(d,(540,260),'學習單只留三欄',font(72),palette['yellow'],max_chars=9)
    xs=[85,385,685]; titles=['AI 說法','我懷疑','我要驗證']; colors=[palette['cyan'],palette['yellow'],palette['green']]
    for x,t,c in zip(xs,titles,colors):
        rounded(d,(x,440,x+280,1360),fill=palette['card'],outline=c,width=7,r=30)
        center_text(d,(x+140,520),t,font(44),palette['ink'],max_chars=4)
    bullets=[['抄一句\nAI 原話','圈關鍵詞'],['哪裡怪？','條件？','單位？','方向？'],['畫圖','代回題目','找反例']]
    for x,bs in zip(xs,bullets):
        yy=690
        for b in bs:
            center_text(d,(x+140,yy),b,font(41),palette['ink'],max_chars=5,gap=6); yy+=150
    footer(d,'三欄：說法｜懷疑｜驗證')
    return im
def slide4():
    im=Image.new('RGB',(W,H),palette['bg']); d=ImageDraw.Draw(im); top_brand(d,4)
    center_text(d,(540,250),'老師的流程更簡單',font(68),palette['white'],max_chars=10)
    steps=[('1','丟一段\nAI 錯解',palette['red']),('2','學生標\n疑點',palette['yellow']),('3','找證據\n修一句',palette['green'])]
    y=430
    for num,txt,c in steps:
        rounded(d,(155,y,925,y+260),fill=(28,38,58),outline=c,width=7,r=34)
        d.ellipse((195,y+65,315,y+185),fill=c)
        center_text(d,(255,y+125),num,font(68),palette['ink'],max_chars=2)
        center_text(d,(610,y+130),txt,font(58),palette['white'],max_chars=8,gap=12)
        y+=330
    center_text(d,(540,1500),'不是老師一直講\n而是學生拿證據說話',font(58),palette['yellow'],max_chars=10,gap=12)
    footer(d,'5 分鐘也能做一次判讀練習')
    return im
def slide5():
    im=Image.new('RGB',(W,H),palette['bg']); d=ImageDraw.Draw(im); top_brand(d,5)
    center_text(d,(540,350),'想要可複製版？',font(76),palette['white'],max_chars=9)
    rounded(d,(135,560,945,1210),fill=palette['card'],outline=palette['cyan'],width=8,r=42)
    center_text(d,(540,760),'留言',font(58),palette['muted'],max_chars=6)
    center_text(d,(540,940),'「抓錯」',font(120),palette['ink'],max_chars=4)
    center_text(d,(540,1330),'下一支整理成\n老師可改的學習單',font(65),palette['yellow'],max_chars=10,gap=15)
    footer(d,'先把 AI 錯誤變成課堂活動')
    return im
slides=[slide1(),slide2(),slide3(),slide4(),slide5()]
for i,im in enumerate(slides,1): im.save(SLIDES/f'slide_{i:02d}.png',quality=95)
# contact sheet 3+2 large previews
thumb_w, thumb_h = 324,576
sheet=Image.new('RGB',(1150,1420),(245,248,252)); d=ImageDraw.Draw(sheet)
d.text((40,30),'Storyboard contact sheet｜讓學生抓 AI 錯',font=font(42),fill=(20,30,45))
positions=[(40,110),(413,110),(786,110),(225,780),(598,780)]
for i,im in enumerate(slides,1):
    th=im.resize((thumb_w,thumb_h))
    x,y=positions[i-1]
    sheet.paste(th,(x,y))
    d.rectangle((x,y,x+thumb_w,y+thumb_h),outline=(80,90,110),width=3)
    d.text((x,y+thumb_h+12),f'slide_{i:02d}.png',font=font(30),fill=(35,45,65))
sheet.save(CHECKS/'contact_sheet.png',quality=95)
print('wrote', BASE)
