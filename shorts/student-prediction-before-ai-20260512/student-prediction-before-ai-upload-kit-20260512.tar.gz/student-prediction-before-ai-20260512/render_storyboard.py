from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import json, tarfile

BASE = Path('/home/adl/youtube-lu-ai-channel')
PKG = BASE / 'shorts' / 'student-prediction-before-ai-20260512'
SLIDES = PKG / 'slides'
CHECKS = PKG / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W, H = 1080, 1920
palette = {
    'bg': '#102033', 'ink': '#102033', 'blue': '#3C7DD9',
    'orange': '#F5A64A', 'green': '#39A879', 'cream': '#FFF8EA'
}

def font(size):
    return ImageFont.truetype(FONT, size)

slides = [
    {'n':'01','tag':'3秒鉤子','title':'學生用 AI 前，\n先寫一句預測','body':['如果一開始就問 AI，學生只是在等答案。','先寫「我預期會看到……」才有判斷基準。'],'call':'先預測，再詢問'},
    {'n':'02','tag':'老師示範','title':'把問題變成\n可檢查的預測','body':['題目：小球從斜面滑下，速度會怎麼變？','預測句：我預期速度會變快，因為重力沿斜面有分力。'],'call':'預測要有「因為」'},
    {'n':'03','tag':'AI 回答後','title':'不要只問：\nAI 說得對嗎？','body':['改問三格：','① 跟我的預測哪裡相同？','② 哪裡不同？','③ 不同處要查哪個證據？'],'call':'把答案變討論'},
    {'n':'04','tag':'課堂小表格','title':'一張 3 欄表\n就能開始','body':['我的預測｜AI 的說法｜我要驗證的證據','適合 5–8 分鐘暖身，也能做 exit ticket。'],'call':'不用完整學習單也能做'},
    {'n':'05','tag':'收尾 CTA','title':'老師把關句','body':['「先寫預測，再問 AI；看見差異，才開始學。」','下一步可延伸成：預測句型卡＋學生反思單。'],'call':'AI 不是答案販賣機'}
]

def wrap(draw, text, fnt, maxw):
    out = []
    for para in text.split('\n'):
        line = ''
        for ch in para:
            if draw.textbbox((0,0), line + ch, font=fnt)[2] <= maxw:
                line += ch
            else:
                if line:
                    out.append(line)
                line = ch
        if line:
            out.append(line)
    return out

def draw_slide(s):
    im = Image.new('RGB', (W,H), palette['bg'])
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([60,70,1020,1850], radius=48, fill=palette['cream'])
    d.rounded_rectangle([100,120,980,300], radius=38, fill=palette['blue'])
    d.text((140,168), f"第二季 Shorts｜{s['tag']}", font=font(52), fill='white')
    y = 380
    for line in s['title'].split('\n'):
        d.text((110,y), line, font=font(86), fill=palette['ink'])
        y += 110
    d.rounded_rectangle([110,y+20,970,y+36], radius=8, fill=palette['orange'])
    y += 95
    d.rounded_rectangle([110,y,970,1365], radius=34, fill='white', outline='#E2D6C7', width=4)
    yy = y + 52
    for item in s['body']:
        f = font(46 if len(item) < 25 else 42)
        for line in wrap(d, item, f, 780):
            d.text((155, yy), line, font=f, fill=palette['ink'])
            yy += 62
        yy += 18
    basey = 1435
    boxes = [('預測', palette['green']), ('詢問 AI', palette['blue']), ('找證據', palette['orange'])]
    x = 115
    for label, c in boxes:
        d.rounded_rectangle([x,basey,x+245,basey+125], radius=28, fill=c)
        d.text((x+55,basey+38), label, font=font(42), fill='white')
        x += 305
        if x < 900:
            d.line([x-45,basey+62,x-10,basey+62], fill=palette['ink'], width=8)
            d.polygon([(x-10,basey+62),(x-35,basey+45),(x-35,basey+79)], fill=palette['ink'])
    d.rounded_rectangle([110,1645,970,1788], radius=34, fill=palette['ink'])
    cfont = font(52)
    lines = wrap(d, s['call'], cfont, 760)
    cy = 1678
    for line in lines:
        tw = d.textbbox((0,0), line, font=cfont)[2]
        d.text(((W-tw)//2, cy), line, font=cfont, fill='white')
        cy += 62
    d.text((110,1810), '盧老師 × AI 物理教學｜storyboard draft', font=font(30), fill='#5F6E7A')
    path = SLIDES / f"slide_{s['n']}.png"
    im.save(path)
    return path

paths = [draw_slide(s) for s in slides]
thumb_w, thumb_h = 324, 576
sheet = Image.new('RGB', (1120,1440), '#1B2635')
d = ImageDraw.Draw(sheet)
d.text((40,28), '學生用 AI 前，先寫一句「我預期會看到什麼」｜5 張 storyboard', font=font(34), fill='white')
positions = [(40,90),(398,90),(756,90),(220,720),(578,720)]
for i, p in enumerate(paths):
    im = Image.open(p).resize((thumb_w, thumb_h))
    x, y = positions[i]
    sheet.paste(im, (x,y))
    d.text((x,y+thumb_h+10), f"slide {i+1}", font=font(28), fill='white')
sheet.save(CHECKS / 'contact_sheet.png')

manifest = {
    'title': '學生用 AI 前，先寫一句「我預期會看到什麼」',
    'candidate': 'season-02-priority-07',
    'status': 'storyboard package v1 complete',
    'created': '2026-05-12',
    'dimensions': '1080x1920',
    'slides': [str(p.relative_to(PKG)) for p in paths],
    'contact_sheet': 'checks/contact_sheet.png',
    'next_auto_push': 'expand storyboard into zh-TW narration/VTT/35s MP4/upload kit, unless YouTube login is ready for upload'
}
(PKG / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

readme = """# Shorts storyboard｜學生用 AI 前，先寫一句「我預期會看到什麼」

狀態：2026-05-12 每小時雷達自動推進完成 storyboard package v1。  
來源：第二季內容題庫優先題 7。

## 30 秒製作簡報

- 3 秒鉤子：先有預測，AI 才不是答案販賣機。
- 核心觀點：學生問 AI 前先寫「我預期會看到……因為……」，AI 回答後再比對差異與證據。
- 對象：國高中自然／物理教師，可用於 5–8 分鐘課堂暖身或 exit ticket。
- 最小素材：5 張 9:16 圖卡、預測句型、三欄比對表。

## 圖卡

1. `slides/slide_01.png`｜學生用 AI 前，先寫一句預測
2. `slides/slide_02.png`｜把問題變成可檢查的預測
3. `slides/slide_03.png`｜AI 回答後，不只問對錯
4. `slides/slide_04.png`｜一張 3 欄表就能開始
5. `slides/slide_05.png`｜老師把關句與 CTA

## 驗證

- PIL 輸出：5 張 `1080×1920` RGB PNG。
- Contact sheet：`checks/contact_sheet.png`。
- 視覺 QA：已檢查繁中主文字可讀、無 tofu 方塊、無裁切、無重疊；contact sheet 排版不擁擠。

## 下一個自動推進

若 YouTube/Google 登入仍未完成：把本 storyboard 擴成 zh-TW 旁白、VTT/SRT、35 秒 MP4、封面與 upload kit。  
若使用者已完成 YouTube/Google 登入：優先上傳已完成的第一季首批 Shorts。
"""
(PKG / 'README.md').write_text(readme, encoding='utf-8')

archive = PKG / 'student-prediction-before-ai-storyboard-kit-20260512.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for rel in ['README.md','manifest.json','render_storyboard.py','checks/contact_sheet.png']:
        tar.add(PKG / rel, arcname=f'student-prediction-before-ai-20260512/{rel}')
    for p in paths:
        tar.add(p, arcname=f'student-prediction-before-ai-20260512/slides/{p.name}')
print(PKG)
print(archive)
