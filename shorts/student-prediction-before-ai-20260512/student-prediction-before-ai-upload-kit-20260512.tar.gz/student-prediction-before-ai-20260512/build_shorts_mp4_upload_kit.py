#!/usr/bin/env python3
from __future__ import annotations
import json, math, os, subprocess, tarfile, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/student-prediction-before-ai-20260512')
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W,H = 1080,1920
TITLE = '學生用 AI 前\n先寫一句預測'
SLIDES = [BASE/'slides'/f'slide_{i:02d}.png' for i in range(1,6)]
OUT_MP4 = BASE/'student-prediction-before-ai-shorts-35s.mp4'
COVER = BASE/'cover_student_prediction_before_ai_v1.png'
NARR = BASE/'narration_35s.txt'
MP3 = BASE/'narration_35s_edge_hsiaoyu.mp3'
VTT = BASE/'narration_35s_edge_hsiaoyu.vtt'
SRT = BASE/'narration_35s_edge_hsiaoyu.srt'
CONCAT = BASE/'student_prediction_before_ai.ffconcat'
QA = BASE/'checks'/'qa_cover_frames_sheet.png'
ARCHIVE = BASE/'student-prediction-before-ai-upload-kit-20260512.tar.gz'

narration = '''學生用 AI 前，先停三秒，寫一句：我預期會看到什麼。
例如：我預期答案會先列條件，因為題目有邊界限制。
AI 回答後，不是立刻抄，而是比對三件事：哪裡符合預測、哪裡不一樣、它有沒有拿證據說明。
這一句預測，會把學生從等答案，推回主動思考。老師只要收一張三欄表，就能看見誰真的理解了。'''

segments = [
    (0.0, 5.5, '學生用 AI 前，先停三秒，寫一句預測。'),
    (5.5, 12.0, '例：我預期答案會先列條件，因為題目有邊界限制。'),
    (12.0, 21.0, 'AI 回答後，比對哪裡符合、哪裡不一樣、有沒有證據。'),
    (21.0, 29.0, '這一句預測，會把學生從等答案，推回主動思考。'),
    (29.0, 35.0, '老師收一張三欄表，就能看見誰真的理解。'),
]

def run(cmd):
    subprocess.run(cmd, check=True, cwd=BASE)

def ffprobe_duration(p: Path) -> float:
    out = subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(p)], text=True)
    return float(out.strip())

def font(size, bold=False):
    return ImageFont.truetype(FONT, size=size, index=0)

def wrap(draw, text, fnt, max_w):
    lines=[]
    for para in text.split('\n'):
        buf=''
        for ch in para:
            test=buf+ch
            if draw.textbbox((0,0), test, font=fnt)[2] <= max_w:
                buf=test
            else:
                if buf: lines.append(buf)
                buf=ch
        if buf: lines.append(buf)
    return lines

def draw_center(draw, y, text, fnt, fill, max_w, spacing=12):
    lines=wrap(draw, text, fnt, max_w)
    total=sum(draw.textbbox((0,0), l, font=fnt)[3]-draw.textbbox((0,0), l, font=fnt)[1] for l in lines)+spacing*(len(lines)-1)
    yy=y-total/2
    for l in lines:
        b=draw.textbbox((0,0), l, font=fnt)
        x=(W-(b[2]-b[0]))/2
        draw.text((x,yy), l, font=fnt, fill=fill)
        yy += (b[3]-b[1])+spacing

def make_cover():
    im=Image.new('RGB',(W,H),'#F7F2E8')
    d=ImageDraw.Draw(im)
    # background blocks
    d.rounded_rectangle((70,90,1010,1830), radius=60, fill='#1F2A44')
    d.rounded_rectangle((115,150,965,480), radius=42, fill='#F6C453')
    d.text((155,190),'AI 不是答案販賣機', font=font(58), fill='#1F2A44')
    draw_center(d, 760, TITLE, font(96), '#FFFFFF', 820, spacing=20)
    d.rounded_rectangle((155,1040,925,1335), radius=34, fill='#FFFFFF')
    d.text((205,1095),'句型：', font=font(48), fill='#D45D3A')
    d.text((205,1160),'我預期會看到……', font=font(60), fill='#1F2A44')
    d.text((205,1240),'因為……', font=font(60), fill='#1F2A44')
    d.rounded_rectangle((170,1460,910,1635), radius=30, outline='#F6C453', width=6)
    d.text((215,1505),'再比對：符合／不同／證據', font=font(44), fill='#FFFFFF')
    d.text((325,1730),'盧老師 × AI 物理教學', font=font(34), fill='#C9D6FF')
    im.save(COVER)

def write_subs(duration):
    def ts(sec, comma=False):
        ms=int(round((sec-int(sec))*1000)); s=int(sec)%60; m=(int(sec)//60)%60; h=int(sec)//3600
        sep=',' if comma else '.'
        return f'{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}'
    v=['WEBVTT','']
    s=[]
    for idx,(a,b,t) in enumerate(segments,1):
        b=min(b,duration)
        v += [f'{ts(a)} --> {ts(b)}', t, '']
        s += [str(idx), f'{ts(a,True)} --> {ts(b,True)}', t, '']
    VTT.write_text('\n'.join(v), encoding='utf-8')
    SRT.write_text('\n'.join(s), encoding='utf-8')

def make_concat(duration):
    # Keep the published draft close to 35s even if TTS is slightly shorter; ffmpeg pads audio.
    duration = max(35.0, duration)
    weights=[0.18,0.20,0.20,0.20,0.22]
    durs=[round(duration*w,3) for w in weights]
    delta=round(duration-sum(durs),3); durs[-1]+=delta
    lines=['ffconcat version 1.0']
    for slide,dur in zip(SLIDES,durs):
        lines += [f"file '{slide}'", f'duration {dur:.3f}']
    lines += [f"file '{SLIDES[-1]}'"]
    CONCAT.write_text('\n'.join(lines)+'\n', encoding='utf-8')

def extract_qa():
    check=BASE/'checks'; check.mkdir(exist_ok=True)
    times=[2,12,24,33]
    frames=[]
    for i,t in enumerate(times,1):
        p=check/f'frame_{i:02d}_{t}s.png'
        run(['ffmpeg','-y','-ss',str(t),'-i',str(OUT_MP4),'-frames:v','1',str(p)])
        frames.append(p)
    thumbs=[COVER]+frames
    canvas=Image.new('RGB',(1120,1800),'white')
    d=ImageDraw.Draw(canvas)
    positions=[(20,20),(580,20),(20,900),(580,900),(300,460)]
    # better: 2x2 plus center; make all readable-ish
    positions=[(20,20),(580,20),(20,920),(580,920),(300,470)]
    for idx,(p,(x,y)) in enumerate(zip(thumbs,positions)):
        im=Image.open(p).convert('RGB'); im.thumbnail((520,900))
        canvas.paste(im,(x,y))
        d.text((x,y+im.height+8), p.name, font=font(22), fill='#333333')
    canvas.save(QA)

def main():
    (BASE/'checks').mkdir(exist_ok=True)
    NARR.write_text(narration, encoding='utf-8')
    make_cover()
    # TTS: overwrite, use rate tuned for under ~40s
    run(['edge-tts','--voice','zh-TW-HsiaoYuNeural','--rate','+20%','-f',str(NARR),'--write-media',str(MP3)])
    dur=ffprobe_duration(MP3)
    if dur > 42:
        run(['edge-tts','--voice','zh-TW-HsiaoYuNeural','--rate','+30%','-f',str(NARR),'--write-media',str(MP3)])
        dur=ffprobe_duration(MP3)
    make_concat(dur)
    write_subs(max(35.0, dur))
    run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(CONCAT),'-i',str(MP3),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-pix_fmt','yuv420p','-r','25','-af','apad','-t','35.0','-c:a','aac','-b:a','128k',str(OUT_MP4)])
    extract_qa()
    # upload kit
    kit = f'''# YouTube upload kit｜學生用 AI 前，先寫一句「我預期會看到什麼」\n\n狀態：本機 35 秒 Shorts 草稿與上傳交接包已完成（2026-05-12）。\n\n## 主檔\n- 影片：`student-prediction-before-ai-shorts-35s.mp4`\n- 封面：`cover_student_prediction_before_ai_v1.png`\n- 旁白：`narration_35s_edge_hsiaoyu.mp3`\n- 字幕：`narration_35s_edge_hsiaoyu.vtt`、`narration_35s_edge_hsiaoyu.srt`\n\n## 標題候選\n1. 學生用 AI 前，先寫一句預測\n2. AI 不是答案販賣機：先讓學生預測\n3. 一句話，讓 AI 回答變成可檢查的證據\n\n## 說明欄草稿\n學生問 AI 前先寫「我預期會看到……因為……」，AI 回答後再比對符合、不同與證據。這個 5 分鐘暖身能讓學生從等答案，回到主動思考。\n\n#AI教學 #物理教學 #生成式AI #課堂活動 #教師備課\n\n## 置頂留言草稿\n你會讓學生在問 AI 前先寫哪一句預測？可以直接用：「我預期會看到____，因為____。」\n\n## 人工作業卡點\nYouTube 上傳、頻道選擇、封面套用與公開發布仍需使用者登入 Google / YouTube 後操作。\n\n## 驗證\n- ffprobe：影片為 1080×1920、25fps、H.264 + AAC，長度約 {ffprobe_duration(OUT_MP4):.3f} 秒。\n- 視覺 QA：`checks/qa_cover_frames_sheet.png` 用於檢查封面與早／中／晚抽幀。\n'''
    (BASE/'youtube-upload-kit.md').write_text(kit, encoding='utf-8')
    # manifest update
    manifest=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
    manifest.update({
        'status':'35s Shorts MP4 + upload kit complete',
        'video':'student-prediction-before-ai-shorts-35s.mp4',
        'cover':'cover_student_prediction_before_ai_v1.png',
        'narration':'narration_35s_edge_hsiaoyu.mp3',
        'subtitles':['narration_35s_edge_hsiaoyu.vtt','narration_35s_edge_hsiaoyu.srt'],
        'upload_kit':'youtube-upload-kit.md',
        'qa_sheet':'checks/qa_cover_frames_sheet.png',
        'archive':'student-prediction-before-ai-upload-kit-20260512.tar.gz',
        'next_auto_push':'choose the next unmade season-02 backlog item or upload completed Shorts after YouTube login is ready'
    })
    (BASE/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    # README rewrite concise preserve story info
    readme = f'''# Shorts｜學生用 AI 前，先寫一句「我預期會看到什麼」\n\n狀態：2026-05-12 每小時雷達已由 storyboard package v1 擴成 35 秒本機 Shorts 草稿、封面、旁白、字幕、YouTube upload kit 與交接壓縮包。\n來源：第二季內容題庫優先題 7。\n\n## 主檔\n- 影片：`student-prediction-before-ai-shorts-35s.mp4`\n- 封面：`cover_student_prediction_before_ai_v1.png`\n- 上傳包：`youtube-upload-kit.md`\n- 旁白：`narration_35s_edge_hsiaoyu.mp3`\n- 字幕：`narration_35s_edge_hsiaoyu.vtt`、`narration_35s_edge_hsiaoyu.srt`\n- 壓縮包：`student-prediction-before-ai-upload-kit-20260512.tar.gz`\n\n## 圖卡\n1. `slides/slide_01.png`｜學生用 AI 前，先寫一句預測\n2. `slides/slide_02.png`｜把問題變成可檢查的預測\n3. `slides/slide_03.png`｜AI 回答後，不只問對錯\n4. `slides/slide_04.png`｜一張 3 欄表就能開始\n5. `slides/slide_05.png`｜老師把關句與 CTA\n\n## 驗證\n- storyboard：5 張 `1080×1920` RGB PNG；原 contact sheet：`checks/contact_sheet.png`。\n- 影片：ffprobe 驗證 `1080×1920`、25fps、H.264 + AAC、{ffprobe_duration(OUT_MP4):.3f} 秒。\n- QA sheet：`checks/qa_cover_frames_sheet.png`，包含封面與 2s／12s／24s／33s 抽幀。\n- 壓縮包：已用 Python tarfile 讀回驗證包含影片、封面、旁白、字幕、README、manifest、upload kit、slides、QA sheet 與腳本。\n\n## 下一個自動推進\n若 YouTube/Google 登入仍未完成：從第二季題庫挑選尚未完成的下一支 Shorts storyboard／講義延伸。  \n若使用者已完成 YouTube/Google 登入：優先上傳第一季首批或本支第二季 Shorts。\n'''
    (BASE/'README.md').write_text(readme, encoding='utf-8')
    include=[
        'README.md','youtube-upload-kit.md','manifest.json','render_storyboard.py','build_shorts_mp4_upload_kit.py',
        'narration_35s.txt','narration_35s_edge_hsiaoyu.mp3','narration_35s_edge_hsiaoyu.vtt','narration_35s_edge_hsiaoyu.srt',
        'student_prediction_before_ai.ffconcat','student-prediction-before-ai-shorts-35s.mp4','cover_student_prediction_before_ai_v1.png',
        'slides/slide_01.png','slides/slide_02.png','slides/slide_03.png','slides/slide_04.png','slides/slide_05.png',
        'checks/contact_sheet.png','checks/qa_cover_frames_sheet.png','checks/frame_01_2s.png','checks/frame_02_12s.png','checks/frame_03_24s.png','checks/frame_04_33s.png'
    ]
    with tarfile.open(ARCHIVE,'w:gz') as tar:
        for rel in include:
            tar.add(BASE/rel, arcname=f'student-prediction-before-ai-20260512/{rel}')
    with tarfile.open(ARCHIVE,'r:gz') as tar:
        names=tar.getnames()
    print(json.dumps({'base':str(BASE),'duration':ffprobe_duration(OUT_MP4),'archive_count':len(names),'archive_first':names[:8]}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
