from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/near-light-speed-by-ai-20260509')
SLIDES = BASE / 'slides'
SLIDES.mkdir(parents=True, exist_ok=True)
W, H = 1080, 1920
SCALE = 2
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size)

F_TITLE = font(116)
F_BIG = font(92)
F_MED = font(58)
F_SMALL = font(42)
F_TINY = font(34)

def text_center(draw, xy, text, fnt, fill, stroke=0, stroke_fill=(0,0,0)):
    x, y = xy
    bbox = draw.textbbox((0,0), text, font=fnt, stroke_width=stroke)
    draw.text((x-(bbox[2]-bbox[0])/2, y-(bbox[3]-bbox[1])/2), text, font=fnt, fill=fill, stroke_width=stroke, stroke_fill=stroke_fill)

def rounded(draw, box, r, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)

def bg():
    img = Image.new('RGB', (W*SCALE,H*SCALE), '#050918')
    d = ImageDraw.Draw(img)
    for y in range(H*SCALE):
        t = y/(H*SCALE)
        r = int(5 + 8*t); g = int(9 + 12*t); b = int(24 + 30*t)
        d.line([(0,y),(W*SCALE,y)], fill=(r,g,b))
    glow = Image.new('RGBA', img.size, (0,0,0,0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((650*SCALE, -150*SCALE, 1450*SCALE, 650*SCALE), fill=(0,190,255,55))
    gd.ellipse((-280*SCALE, 950*SCALE, 520*SCALE, 1850*SCALE), fill=(130,70,255,45))
    glow = glow.filter(ImageFilter.GaussianBlur(90*SCALE))
    img = Image.alpha_composite(img.convert('RGBA'), glow)
    d = ImageDraw.Draw(img)
    # subtle grid
    for x in range(0,W*SCALE,90*SCALE):
        d.line((x,0,x,H*SCALE), fill=(120,200,255,18), width=1)
    for y in range(0,H*SCALE,120*SCALE):
        d.line((0,y,W*SCALE,y), fill=(120,200,255,14), width=1)
    return img

def draw_card(img, box, title, body_lines, accent=(255,216,77), warn=False):
    d=ImageDraw.Draw(img)
    box=tuple(int(v*SCALE) for v in box)
    rounded(d, box, 34*SCALE, fill=(11,20,44,210), outline=(120,200,255,70), width=3*SCALE)
    x1,y1,x2,y2=box
    d.text((x1+48*SCALE,y1+34*SCALE), title, font=F_MED, fill=accent)
    y=y1+125*SCALE
    for line in body_lines:
        d.text((x1+52*SCALE,y), line, font=F_SMALL, fill=(238,247,255))
        y += 62*SCALE
    if warn:
        d.rounded_rectangle((x2-170*SCALE,y1+32*SCALE,x2-40*SCALE,y1+106*SCALE), radius=22*SCALE, fill=(255,66,88,230))
        d.text((x2-145*SCALE,y1+44*SCALE), 'WARN', font=F_TINY, fill='white')

def speedometer(img, center, radius, value=0.88):
    d=ImageDraw.Draw(img)
    cx,cy = [int(v*SCALE) for v in center]
    r=int(radius*SCALE)
    d.arc((cx-r,cy-r,cx+r,cy+r), 200, 340, fill=(90,180,220,120), width=22*SCALE)
    d.arc((cx-r,cy-r,cx+r,cy+r), 292, 340, fill=(255,66,88,230), width=26*SCALE)
    ang=math.radians(200+140*value)
    x=cx+int(math.cos(ang)*r*0.76); y=cy+int(math.sin(ang)*r*0.76)
    d.line((cx,cy,x,y), fill=(255,230,80), width=12*SCALE)
    d.ellipse((cx-20*SCALE,cy-20*SCALE,cx+20*SCALE,cy+20*SCALE), fill=(255,230,80))
    text_center(d,(cx/SCALE, (cy+150*SCALE)/SCALE),'2.0e8 m/s',F_BIG,(255,255,255),stroke=3*SCALE,stroke_fill=(0,0,0))

def finish(img, filename):
    img = img.resize((W,H), Image.Resampling.LANCZOS).convert('RGB')
    img.save(SLIDES/filename, quality=95)

slides=[]
# 1
img=bg(); d=ImageDraw.Draw(img)
d.text((72*SCALE,120*SCALE),'接近光速？',font=F_TITLE,fill=(255,224,80),stroke_width=5*SCALE,stroke_fill=(0,0,0))
draw_card(img,(80,360,1000,760),'AI 最後答案',['普通球的運動','v = 2.0e8 m/s'],warn=True)
speedometer(img,(540,1180),330,0.92)
d.text((95*SCALE,1635*SCALE),'日常題算到光速等級，先不要急著抄。',font=F_SMALL,fill=(230,245,255))
finish(img,'slide_01.png')
# 2
img=bg(); d=ImageDraw.Draw(img)
d.text((72*SCALE,120*SCALE),'先別重算',font=F_TITLE,fill=(255,224,80),stroke_width=5*SCALE,stroke_fill=(0,0,0))
draw_card(img,(85,360,995,760),'步驟很多 ≠ 可信',['公式排得很漂亮','但量級已經亮紅燈'])
# pause button
d.ellipse((330*SCALE,900*SCALE,750*SCALE,1320*SCALE),fill=(255,214,67,235),outline=(255,255,255,150),width=8*SCALE)
d.rounded_rectangle((460*SCALE,1005*SCALE,505*SCALE,1210*SCALE),radius=14*SCALE,fill=(8,15,32))
d.rounded_rectangle((575*SCALE,1005*SCALE,620*SCALE,1210*SCALE),radius=14*SCALE,fill=(8,15,32))
d.text((110*SCALE,1500*SCALE),'先問：這像不像真實世界？',font=F_MED,fill=(236,247,255))
finish(img,'slide_02.png')
#3
img=bg(); d=ImageDraw.Draw(img)
d.text((72*SCALE,120*SCALE),'世界有尺度',font=F_TITLE,fill=(255,224,80),stroke_width=5*SCALE,stroke_fill=(0,0,0))
items=[('走路','1 m/s',260,(80,230,170)),('車子','30 m/s',610,(65,180,255)),('光','3e8 m/s',1000,(255,70,90))]
for label,val,y,color in items:
    rounded(d,(110*SCALE,y*SCALE,970*SCALE,(y+190)*SCALE),30*SCALE,fill=(10,24,51,220),outline=color+(120,),width=4*SCALE)
    d.text((160*SCALE,(y+42)*SCALE),label,font=F_MED,fill=color)
    d.text((520*SCALE,(y+42)*SCALE),val,font=F_MED,fill=(245,250,255))
d.text((100*SCALE,1450*SCALE),'課本日常情境突然跑到光速端，通常不是小誤差。',font=F_SMALL,fill=(235,245,255))
finish(img,'slide_03.png')
#4
img=bg(); d=ImageDraw.Draw(img)
d.text((72*SCALE,120*SCALE),'錯在哪？',font=F_TITLE,fill=(255,224,80),stroke_width=5*SCALE,stroke_fill=(0,0,0))
buttons=[('條件',250,True),('單位',560,True),('公式',870,False)]
for txt,y,hot in buttons:
    color=(255,70,90) if hot else (70,210,255)
    rounded(d,(170*SCALE,y*SCALE,910*SCALE,(y+210)*SCALE),40*SCALE,fill=(14,26,58,230),outline=color+(180,),width=6*SCALE)
    text_center(d,(540,y+105),txt,F_BIG,color,stroke=2*SCALE)
d.text((100*SCALE,1330*SCALE),'量級怪，通常要回頭查：條件、單位、公式。',font=F_SMALL,fill=(235,245,255))
finish(img,'slide_04.png')
#5
img=bg(); d=ImageDraw.Draw(img)
d.text((72*SCALE,100*SCALE),'先暫停',font=F_TITLE,fill=(255,224,80),stroke_width=5*SCALE,stroke_fill=(0,0,0))
d.text((72*SCALE,250*SCALE),'量級怪怪的',font=F_BIG,fill=(255,255,255),stroke_width=4*SCALE,stroke_fill=(0,0,0))
checks=['像不像真實世界？','單位對不對？','條件有沒有偷換？']
for i,line in enumerate(checks):
    y=480+i*240
    rounded(d,(95*SCALE,y*SCALE,985*SCALE,(y+165)*SCALE),30*SCALE,fill=(10,24,51,230),outline=(110,210,255,120),width=4*SCALE)
    d.ellipse((145*SCALE,(y+50)*SCALE,220*SCALE,(y+125)*SCALE),fill=(255,214,67))
    d.text((164*SCALE,(y+54)*SCALE),str(i+1),font=F_TINY,fill=(5,10,24))
    d.text((260*SCALE,(y+52)*SCALE),line,font=F_MED,fill=(240,248,255))
d.text((115*SCALE,1380*SCALE),'留言給我：你看過哪種 AI 量級翻車？',font=F_SMALL,fill=(255,224,80))
finish(img,'slide_05.png')

# contact sheet: roomy 3+2 layout so thumbnail previews are readable during QA.
thumbs=[Image.open(SLIDES/f'slide_{i:02d}.png').resize((324,576),Image.Resampling.LANCZOS) for i in range(1,6)]
sheet=Image.new('RGB',(3*364+60,2*636+40),'#071022')
d=ImageDraw.Draw(sheet)
for i,t in enumerate(thumbs):
    col=i%3; row=i//3
    x=30+col*364; y=24+row*636
    sheet.paste(t,(x,y))
    d.text((x+145,y+584),f'slide {i+1}',font=ImageFont.truetype(FONT,24),fill=(255,224,80))
sheet.save(BASE/'contact_sheet_near_light_speed_v1.png',quality=95)
print('rendered', SLIDES)
