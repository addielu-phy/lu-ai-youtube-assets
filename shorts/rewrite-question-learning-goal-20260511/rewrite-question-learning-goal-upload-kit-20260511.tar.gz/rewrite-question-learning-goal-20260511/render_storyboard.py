from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, tarfile
BASE=Path('/home/adl/youtube-lu-ai-channel')
PKG=BASE/'shorts/rewrite-question-learning-goal-20260511'
SL=PKG/'slides'; CK=PKG/'checks'; CF=PKG/'check_frames'
for p in [SL,CK,CF]: p.mkdir(parents=True,exist_ok=True)
font_candidates=['/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','/usr/share/fonts/truetype/arphic/uming.ttc']
font_path=next((f for f in font_candidates if Path(f).exists()), '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
def font(size): return ImageFont.truetype(font_path,size)
W,H=1080,1920
bg=(14,24,42); cyan=(80,220,235); yellow=(255,214,102); white=(248,250,252); muted=(180,196,216); green=(100,235,170)
def wrap(draw,text,f,maxw):
    lines=[]
    for para in text.split('\n'):
        line=''
        for ch in para:
            test=line+ch
            if draw.textbbox((0,0),test,font=f)[2] <= maxw or not line: line=test
            else: lines.append(line); line=ch
        if line: lines.append(line)
    return lines
def draw_textbox(draw,xy,w,text,f,fill=white,lh=1.22):
    x,y=xy; yy=y
    for line in wrap(draw,text,f,w):
        draw.text((x,yy),line,font=f,fill=fill); yy+=int(f.size*lh)
    return yy
def card(draw,xy,wh,title,body,accent=cyan):
    x,y=xy; w,h=wh
    draw.rounded_rectangle([x,y,x+w,y+h],radius=34,fill=(23,38,64),outline=accent,width=5)
    draw_textbox(draw,(x+36,y+34),w-72,title,font(54),accent)
    draw_textbox(draw,(x+36,y+116),w-72,body,font(40),white)
def base(title,subtitle,tag):
    im=Image.new('RGB',(W,H),bg); d=ImageDraw.Draw(im)
    d.rounded_rectangle([70,70,1010,1850],radius=48,outline=(50,78,116),width=4)
    d.text((92,98),'盧老師 × AI 物理教學',font=font(32),fill=muted)
    d.rounded_rectangle([760,92,986,142],radius=24,fill=(34,54,86)); d.text((785,101),tag,font=font(26),fill=cyan)
    y=210
    y=draw_textbox(d,(92,y),895,title,font(78),yellow,1.12)+24
    draw_textbox(d,(96,y),880,subtitle,font(42),white,1.25)
    return im,d
slides=[
('改寫題目，\n最怕改掉學習目標','AI 把題目變順，\n但可能把「要考什麼」也換掉。','S2-04', [('原題：看學生是否懂力與加速度方向','改寫後：只剩代公式算答案')]),
('第一步：\n先貼上學習目標','不是先叫 AI 潤稿，\n而是先鎖住這題要測的概念。','LOCK', [('目標標籤','受力圖｜方向判斷｜條件辨識')]),
('第二步：\n要求 AI 保留核心條件','請它改文字，\n但不得改變變因、圖像線索與作答證據。','CHECK', [('保留','已知條件、圖像、要學生說明的理由'),('可改','情境包裝、句子順序、生活化文字')]),
('第三步：\n改完要做對照表','不要只看新題漂不漂亮，\n要逐格比對學習目標還在不在。','COMPARE', [('對照三欄','原題目標｜AI 改寫｜是否仍能測到')]),
('給老師的 10 秒口訣','改寫可以交給 AI，\n學習目標不能交出去。','CTA', [('下次 prompt 加一句','「請列出哪些地方沒有改動學習目標。」')])]
paths=[]
for i,(t,s,tag,cards) in enumerate(slides,1):
    im,d=base(t,s,tag); y=760
    for c in cards:
        title,body=c; card(d,(115,y),(850,300),title,body,green if i in (2,3) else cyan); y+=340
    d.rounded_rectangle([115,1645,965,1775],radius=28,fill=yellow)
    footer=['目標別被改','先鎖目標，再請 AI 改寫','保留條件與作答證據','三欄對照：目標有沒有消失','改寫給 AI，目標老師守'][i-1]
    draw_textbox(d,(150,1682),780,footer,font(45),bg,1.15)
    p=SL/f'slide_{i:02d}.png'; im.save(p); paths.append(str(p.relative_to(PKG)))
im,d=base('目標別被改','叫 AI 改寫題目前，\n先把學習目標釘住。','COVER')
card(d,(115,860),(850,420),'3 步檢查','1 鎖學習目標\n2 保留核心條件\n3 改完做對照表',yellow)
d.rounded_rectangle([115,1510,965,1710],radius=34,fill=yellow)
draw_textbox(d,(150,1560),780,'改寫可以交給 AI\n目標不能交出去',font(54),bg,1.16)
cover=PKG/'cover_rewrite_question_learning_goal_v1.png'; im.save(cover)
thumbs=[Image.open(SL/f'slide_{i:02d}.png').resize((216,384)) for i in range(1,6)]
cover_t=Image.open(cover).resize((216,384))
sheet=Image.new('RGB',(900,920),(12,18,32)); sd=ImageDraw.Draw(sheet)
for idx,img in enumerate([cover_t]+thumbs):
    x=(idx%3)*300+42; y=(idx//3)*460+30
    sheet.paste(img,(x,y)); sd.text((x,y+390),('cover' if idx==0 else f'slide {idx}'),font=font(28),fill=white)
sheet.save(CK/'qa_contact_sheet.png')
narr='''AI 幫老師改寫題目時，最怕的不是文字不好看，而是學習目標被偷偷改掉。
第一步，先把這題要測的概念貼在 prompt 裡，例如受力圖、方向判斷、條件辨識。
第二步，要求 AI 只能改情境和句子，不能改核心條件、圖像線索，或學生必須說明的理由。
第三步，改完請它做三欄對照：原題目標、AI 改寫、是否仍能測到。
記住：改寫可以交給 AI，學習目標不能交出去。'''
(PKG/'narration_35s.txt').write_text(narr,encoding='utf-8')
segments=[('00:00:00.000','00:00:06.800','AI 幫老師改寫題目時，最怕的不是文字不好看，而是學習目標被偷偷改掉。'),('00:00:06.800','00:00:14.000','第一步，先把這題要測的概念貼在 prompt 裡，例如受力圖、方向判斷、條件辨識。'),('00:00:14.000','00:00:22.000','第二步，要求 AI 只能改情境和句子，不能改核心條件、圖像線索，或學生必須說明的理由。'),('00:00:22.000','00:00:29.500','第三步，改完請它做三欄對照：原題目標、AI 改寫、是否仍能測到。'),('00:00:29.500','00:00:35.000','記住：改寫可以交給 AI，學習目標不能交出去。')]
(PKG/'narration_35s.vtt').write_text('WEBVTT\n\n'+'\n\n'.join([f'{a} --> {b}\n{txt}' for a,b,txt in segments])+'\n',encoding='utf-8')
(PKG/'narration_35s.srt').write_text('\n\n'.join([f'{i}\n{a.replace(".",",")} --> {b.replace(".",",")}\n{txt}' for i,(a,b,txt) in enumerate(segments,1)])+'\n',encoding='utf-8')
(PKG/'render_storyboard.py').write_text(Path('/tmp/build_rewrite_pkg.py').read_text(encoding='utf-8'),encoding='utf-8')
manifest={'title':'叫 AI 改寫題目，最怕它改掉學習目標','package':'shorts/rewrite-question-learning-goal-20260511','slides':paths,'cover':cover.name,'narration':'narration_35s.txt','next_auto_push':'若 YouTube/Google 登入仍未完成，下一步改做第二季優先題 5「AI 分層練習題：老師要先鎖哪三個變因？」的 Shorts storyboard／MP4；若已完成登入，優先上傳第一季首批或本支第二季 Shorts。'}
(PKG/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pkg':str(PKG),'font':font_path,'slides':len(paths)},ensure_ascii=False))
