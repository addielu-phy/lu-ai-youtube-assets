# Shorts 02 草稿包｜AI Agent 幫老師備課，但不亂教

本資料夾為 2026-05-08 每小時雷達自動推進產物。

## 內容
- `narration.txt`：60 秒內旁白草稿
- `slides/slide_01.png`～`slide_05.png`：9:16 分鏡圖（1080×1920）
- `make_episode02_slides.py`：可重生分鏡圖的腳本
- `narration_edge_hsiaoyu.mp3`：zh-TW Edge TTS 試聽旁白（58.392 秒）
- `episode-02-ai-agent-lesson-planning-draft-v1.mp4`：9:16 本機可預覽草稿（1080×1920 / 30fps / H.264 + AAC）
- `checks/frame_03s.png`、`frame_28s.png`、`frame_54s.png`：驗證抽幀

## 驗證紀錄
- `ffprobe`：1080×1920、30fps、58.392 秒。
- 視覺抽幀檢查：中文字可讀，無 tofu 方塊，無明顯裁切或重疊。

## 上傳標題候選
1. AI Agent 可以幫老師備課嗎？先檢查這 3 件事 #Shorts
2. AI 幫你備課，不代表可以直接上課 #Shorts
3. 把 AI 當助教，不是代課老師 #Shorts

## 下一步
可直接預覽 `episode-02-ai-agent-lesson-planning-draft-v1.mp4`；若要更適合首輪試發，下一步可製作 30 秒剪短版或壓縮成上傳交接包。
