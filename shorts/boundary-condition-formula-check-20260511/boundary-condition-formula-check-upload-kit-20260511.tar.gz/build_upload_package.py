from pathlib import Path
import subprocess, json, re, tarfile
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/boundary-condition-formula-check-20260511')
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
SLIDES = [
    'slides/slide_01_hook.png',
    'slides/slide_02_formula_flag.png',
    'slides/slide_03_slope_case.png',
    'slides/slide_04_teacher_three_questions.png',
    'slides/slide_05_classroom_use.png',
]
TITLE = '邊界條件\n沒寫？'
SUBTITLE = 'AI 的公式先打問號'
FOOTER = '盧老師 × AI 物理教學'

def font(size):
    return ImageFont.truetype(FONT, size)

def text_center(draw, xy, text, fnt, fill, spacing=8):
    lines = text.split('\n')
    y = xy[1]
    for line in lines:
        box = draw.textbbox((0,0), line, font=fnt)
        x = xy[0] - (box[2]-box[0])//2
        draw.text((x,y), line, font=fnt, fill=fill)
        y += (box[3]-box[1]) + spacing

def render_cover():
    W,H = 1080,1920
    img = Image.new('RGB', (W,H), '#11263a')
    d = ImageDraw.Draw(img)
    # gradient bands
    for y in range(H):
        r = 17 + int(18*y/H)
        g = 38 + int(34*y/H)
        b = 58 + int(40*y/H)
        d.line([(0,y),(W,y)], fill=(r,g,b))
    d.rounded_rectangle((82,140,998,1780), radius=64, fill='#f7f1df')
    d.rounded_rectangle((130,220,950,500), radius=44, fill='#f2b84b')
    text_center(d, (540,260), '條件在哪？', font(92), '#1b2430')
    d.rounded_rectangle((180,650,900,1080), radius=36, fill='#ffffff', outline='#2a4058', width=6)
    text_center(d, (540,705), TITLE, font(112), '#10253a', spacing=30)
    d.text((230,1055), '公式成立前，先補這張卡：', font=font(42), fill='#22364f')
    checks = ['系統邊界', '忽略了什麼', '初始／邊界狀態']
    y = 1150
    for item in checks:
        d.rounded_rectangle((210,y,870,y+96), radius=26, fill='#e8f3f0')
        d.ellipse((245,y+28,285,y+68), fill='#2a7b6f')
        d.text((315,y+22), item, font=font(46), fill='#10253a')
        y += 125
    d.rounded_rectangle((160,1585,920,1695), radius=34, fill='#1f6f8b')
    text_center(d, (540,1608), SUBTITLE, font(50), '#ffffff')
    text_center(d, (540,1775), FOOTER, font(34), '#f7f1df')
    out = BASE/'cover_boundary_condition_formula_check_v1.png'
    img.save(out)
    return out

def probe_duration(path):
    out = subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)], text=True)
    return float(out.strip())

def write_concat(duration):
    weights = [0.16,0.20,0.23,0.22,0.19]
    durations = [duration*w for w in weights]
    lines=[]
    for slide,dur in zip(SLIDES,durations):
        lines.append(f"file '{(BASE/slide).as_posix()}'")
        lines.append(f'duration {dur:.3f}')
    lines.append(f"file '{(BASE/SLIDES[-1]).as_posix()}'")
    p=BASE/'slides_35s.ffconcat'
    p.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    return p

def vtt_to_srt():
    vtt=(BASE/'narration_35s_edge_hsiaoyu.vtt').read_text(encoding='utf-8')
    blocks=[]; idx=1
    for block in re.split(r'\n\s*\n', vtt.strip()):
        block=block.strip()
        if not block or block.startswith('WEBVTT'):
            continue
        lines=block.splitlines()
        timing_i=next((i for i,l in enumerate(lines) if '-->' in l), None)
        if timing_i is None: continue
        timing=lines[timing_i].replace('.', ',')
        text='\n'.join(lines[timing_i+1:]).strip()
        if not text: continue
        blocks.append(f'{idx}\n{timing}\n{text}\n')
        idx+=1
    out=BASE/'narration_35s_edge_hsiaoyu.srt'
    out.write_text('\n'.join(blocks), encoding='utf-8')
    return out

def assemble_video(concat):
    out=BASE/'boundary-condition-formula-check-shorts-35s.mp4'
    subprocess.check_call(['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(BASE/'narration_35s_edge_hsiaoyu.mp3'),'-shortest','-r','25','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k',str(out)])
    return out

def extract_checks(video):
    checks=BASE/'checks'; checks.mkdir(exist_ok=True)
    times=[1,18,34]
    frames=[]
    for t in times:
        out=checks/f'frame_{t:02d}s.png'
        subprocess.check_call(['ffmpeg','-y','-ss',str(t),'-i',str(video),'-frames:v','1',str(out)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        frames.append(out)
    cover=BASE/'cover_boundary_condition_formula_check_v1.png'
    imgs=[Image.open(cover).convert('RGB')]+[Image.open(p).convert('RGB') for p in frames]
    thumb_w=360; thumb_h=640
    sheet=Image.new('RGB',(thumb_w*2+60, thumb_h*2+120),'#f5f1e8')
    positions=[(20,50),(400,50),(20,730),(400,730)]
    labels=['cover','1s','18s','34s']
    d=ImageDraw.Draw(sheet)
    lf=font(28)
    for im,pos,label in zip(imgs,positions,labels):
        im=im.resize((thumb_w,thumb_h))
        sheet.paste(im,pos)
        d.text((pos[0],pos[1]-35),label,font=lf,fill='#22364f')
    out=checks/'upload_qa_sheet.png'
    sheet.save(out)
    return frames, out

def verify_images():
    files=[BASE/'cover_boundary_condition_formula_check_v1.png']+[BASE/s for s in SLIDES]+[BASE/'checks/upload_qa_sheet.png']
    return {str(p.relative_to(BASE)): {'size': Image.open(p).size, 'mode': Image.open(p).mode} for p in files}

if __name__ == '__main__':
    cover=render_cover()
    dur=probe_duration(BASE/'narration_35s_edge_hsiaoyu.mp3')
    concat=write_concat(dur)
    srt=vtt_to_srt()
    video=assemble_video(concat)
    frames, qa=extract_checks(video)
    vdur=probe_duration(video)
    print(json.dumps({'audio_duration':dur,'video_duration':vdur,'video':str(video),'cover':str(cover),'srt':str(srt),'qa_sheet':str(qa),'image_verify':verify_images()}, ensure_ascii=False, indent=2))
