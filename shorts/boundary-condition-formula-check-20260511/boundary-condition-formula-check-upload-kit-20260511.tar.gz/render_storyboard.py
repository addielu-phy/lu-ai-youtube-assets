#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, datetime, math
BASE = Path('/home/adl/youtube-lu-ai-channel/shorts/boundary-condition-formula-check-20260511')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
W,H=1080,1920
FONT='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(size): return ImageFont.truetype(FONT, size)
F={'title':font(78),'big':font(70),'mid':font(54),'body':font(44),'small':font(34),'tiny':font(27),'tag':font(30),'formula':font(62)}
P={'bg':(247,250,252),'ink':(26,36,54),'muted':(87,101,123),'blue':(37,99,235),'cyan':(6,182,212),'orange':(234,88,12),'red':(220,38,38),'green':(22,163,74),'white':(255,255,255),'line':(205,216,232),'pale':(232,240,255),'cream':(255,248,231),'dark':(42,52,72)}
slides=[
 {'file':'slide_01_hook.png','kicker':'第二季 02｜錯誤診斷進階','title':'邊界條件沒寫，AI 的公式先打問號','body':['公式看起來對，','但條件沒交代。'],'note':'老師把關句：這個公式在什麼條件下才成立？'},
 {'file':'slide_02_formula_flag.png','kicker':'第一步：先標公式的使用條件','title':'不要只問「公式對不對」','body':['先問：適用範圍是什麼？','忽略哪些因素？','起點／終點如何定義？'],'note':'公式不是答案，是一張有條件的通行證。'},
 {'file':'slide_03_slope_case.png','kicker':'例子：斜面運動','title':'斜面題先看：摩擦、角度、初速','body':['AI 寫出 a = g sinθ','但沒說是否無摩擦','也沒交代從靜止開始嗎？'],'note':'少一個邊界條件，學生會把特例當通則。'},
 {'file':'slide_04_teacher_three_questions.png','kicker':'老師三句檢查','title':'看到漂亮公式，先追三句','body':['1. 這是封閉系統嗎？','2. 什麼量被假設為 0？','3. 初始／邊界狀態在哪裡？'],'note':'把 AI 解答退回「補條件」，比直接改答案更有教學價值。'},
 {'file':'slide_05_classroom_use.png','kicker':'30 秒課堂用法','title':'把公式旁邊補一張條件卡','body':['公式：a = g sinθ','條件卡：無摩擦／剛體／從靜止','任一條不符，就不能直接套。'],'note':'課堂任務：每組挑一題 AI 解答，先補條件卡再判斷能不能套公式。'}]
def wrap(draw,text,fnt,maxw):
    out=[]; line=''
    for ch in text:
        t=line+ch
        if draw.textbbox((0,0), t, font=fnt)[2] <= maxw: line=t
        else:
            if line: out.append(line)
            line=ch
    if line: out.append(line)
    return out
def rounded(d,xy,r,fill,outline=None,width=1): d.rounded_rectangle(xy,radius=r,fill=fill,outline=outline,width=width)
def header(d,k):
    rounded(d,(64,62,1016,128),28,P['pale'])
    d.text((92,80),k,font=F['tag'],fill=P['blue'])
def footer(d,note):
    rounded(d,(64,1688,1016,1836),34,P['cream'],outline=(255,214,150),width=3)
    y=1718
    for line in wrap(d,note,F['small'],850)[:3]:
        d.text((108,y),line,font=F['small'],fill=P['ink']); y+=44
def arrow(d,start,end,color,label=None):
    d.line((start,end),fill=color,width=9)
    sx,sy=start; ex,ey=end; ang=math.atan2(ey-sy,ex-sx)
    for da in (2.55,-2.55):
        x=ex-32*math.cos(ang+da); y=ey-32*math.sin(ang+da)
        d.line((ex,ey,x,y),fill=color,width=9)
    if label: d.text((ex+12 if ex>sx else ex-88, ey-32),label,font=F['small'],fill=color)
def draw_formula_card(d,idx):
    rounded(d,(96,800,984,1380),46,P['white'],outline=P['line'],width=4)
    if idx==0:
        d.text((210,900),'公式很漂亮',font=F['mid'],fill=P['muted'])
        d.text((250,995),'a = g sinθ',font=F['formula'],fill=P['blue'])
        rounded(d,(205,1140,875,1280),34,(255,255,255),outline=P['red'],width=5)
        d.text((250,1174),'條件在哪？',font=F['big'],fill=P['red'])
    elif idx==1:
        d.text((155,860),'公式旁邊要有「條件卡」',font=F['mid'],fill=P['ink'])
        rows=['適用範圍','忽略因素','起點／終點']
        y=965
        for r in rows:
            d.rounded_rectangle((160,y,920,y+90),radius=24,fill=P['pale'],outline=P['line'],width=2)
            d.text((205,y+18),r,font=F['body'],fill=P['blue']); y+=120
    elif idx==2:
        d.line((210,1190,850,930),fill=P['dark'],width=9)
        block=[(455,935),(625,870),(690,1045),(520,1110)]
        d.polygon(block,fill=(219,234,254),outline=P['blue'])
        d.arc((690,1000,820,1130),205,252,fill=P['orange'],width=5)
        d.text((745,1012),'θ',font=F['small'],fill=P['orange'])
        d.text((230,835),'AI：a = g sinθ',font=F['mid'],fill=P['blue'])
        d.text((220,1275),'缺：無摩擦？從靜止？',font=F['mid'],fill=P['red'])
    elif idx==3:
        questions=['系統邊界','被忽略的量','初始／邊界狀態']
        y=875
        for n,q in enumerate(questions,1):
            d.ellipse((150,y,226,y+76),fill=P['orange'])
            d.text((174,y+11),str(n),font=F['body'],fill=P['white'])
            d.text((270,y+9),q,font=F['big'],fill=P['ink'])
            y+=145
    else:
        d.text((165,850),'公式',font=F['small'],fill=P['muted'])
        d.text((165,900),'a = g sinθ',font=F['formula'],fill=P['blue'])
        d.text((165,1015),'條件卡',font=F['small'],fill=P['muted'])
        items=['□ 無摩擦','□ 剛體／質點模型','□ 從靜止釋放']
        y=1075
        for item in items:
            d.text((205,y),item,font=F['mid'],fill=P['green']); y+=95
def render(s,idx):
    img=Image.new('RGB',(W,H),P['bg']); d=ImageDraw.Draw(img)
    header(d,s['kicker'])
    y=180
    for line in wrap(d,s['title'],F['title'],920):
        d.text((64,y),line,font=F['title'],fill=P['ink']); y+=96
    rounded(d,(64,500,1016,735),36,P['white'],outline=P['line'],width=3)
    by=530
    for b in s['body']:
        for line in wrap(d,b,F['body'],840):
            d.text((112,by),line,font=F['body'],fill=P['ink']); by+=58
        by+=8
    draw_formula_card(d,idx)
    footer(d,s['note'])
    d.rectangle((32,32,W-32,H-32),outline=(230,236,245),width=2)
    out=SLIDES/s['file']; img.save(out); return out
paths=[render(s,i) for i,s in enumerate(slides)]
# readable 3+2 contact sheet
thumb_w,thumb_h=324,576
sheet=Image.new('RGB',(1200,1500),(250,252,255)); d=ImageDraw.Draw(sheet)
d.text((40,24),'第二季優先題 2｜邊界條件沒寫，AI 的公式先打問號 storyboard',font=F['small'],fill=P['ink'])
positions=[(48,100),(438,100),(828,100),(240,785),(630,785)]
for idx,(p,pos) in enumerate(zip(paths,positions),1):
    im=Image.open(p).resize((thumb_w,thumb_h)); sheet.paste(im,pos)
    d.text((pos[0],pos[1]+thumb_h+12),f'{idx}. {p.name}',font=F['tiny'],fill=P['muted'])
sheet.save(CHECKS/'contact_sheet.png')
manifest={'project':'boundary-condition-formula-check-20260511','season_priority':2,'title':'邊界條件沒寫，AI 的公式先打問號','created_at':datetime.datetime.now().isoformat(timespec='seconds'),'format':'Shorts storyboard package, 1080x1920 PNG slides','slides':[str(p.relative_to(BASE)) for p in paths],'contact_sheet':'checks/contact_sheet.png','font':FONT,'next_auto_push':'已擴成 37.5 秒 Shorts MP4；下一步改做第二季下一個未完成題的 storyboard 或 upload handoff。'}
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
