#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-answer-rubric-class-activity-20260511')
SLIDES = BASE / 'slides'
CHECKS = BASE / 'checks'
SLIDES.mkdir(parents=True, exist_ok=True)
CHECKS.mkdir(parents=True, exist_ok=True)
FONT_CANDIDATES = [
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/usr/share/fonts/truetype/arphic/uming.ttc',
]
FONT_PATH = next((p for p in FONT_CANDIDATES if Path(p).exists()), '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

def font(size):
    return ImageFont.truetype(FONT_PATH, size)

def wrap(draw, text, fnt, width):
    lines = []
    for para in text.split('\n'):
        cur = ''
        for ch in para:
            test = cur + ch
            if draw.textbbox((0, 0), test, font=fnt)[2] <= width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = ch
        if cur:
            lines.append(cur)
    return lines

def rounded(draw, xy, fill, outline=None, width=1, r=24):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

SLIDE_DATA = [
    {'kicker':'第二季長片｜課堂落地與評量','title':'一堂課怎麼安排「AI 回答評分規準」活動','subtitle':'把學生的懷疑，變成一張可評分、可討論、可修正的規準。','bullets':['不是問 AI 對不對而已','改問：證據夠不夠？條件有沒有寫清楚？','老師保留最後把關權'],'accent':'#ffb703'},
    {'kicker':'活動痛點','title':'答案對一半時，分數怎麼給？','subtitle':'學生常卡在「看起來合理」與「其實缺證據」之間。','bullets':['只看最終答案：容易放過偷換條件','只叫學生重算：討論成本太高','用 rubric：把判斷拆成可觀察證據'],'accent':'#ef476f'},
    {'kicker':'四格 rubric','title':'先評四件事：條件、步驟、圖像、結論','subtitle':'每格 0–2 分；重點是寫理由，不是搶答。','bullets':['條件：題目給的限制有沒有保留？','步驟：推理跳步時，有沒有補證據？','圖像：力圖／示意圖是否支撐文字？','結論：答案與單位、量級是否合理？'],'accent':'#06d6a0'},
    {'kicker':'45 分鐘流程','title':'先個人評，再小組對分，最後全班修規準','subtitle':'AI 回答變成可比較的文本，學生練習說出判準。','bullets':['0–8 分：讀題與 AI 回答，圈出疑點','8–20 分：個人用 rubric 打分並寫理由','20–35 分：小組討論分數差異','35–45 分：老師收斂成班級版規準'],'accent':'#118ab2'},
    {'kicker':'老師把關句','title':'「你給這分數的證據在哪裡？」','subtitle':'這句話讓學生從相信答案，轉成檢查答案。','bullets':['可下載：rubric 草稿與學生互評表','可延伸：下一支 Shorts「讓學生幫 AI 打分」','公開前：真實學生作品與題目需再匿名／授權'],'accent':'#8338ec'},
]

def render_slide(i, s):
    W, H = 1920, 1080
    img = Image.new('RGB', (W, H), '#0b1020')
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 150), fill=s['accent'])
    d.rectangle((0, 150, W, H), fill='#0b1020')
    d.ellipse((1450, -120, 2100, 520), fill='#17213f')
    d.ellipse((-200, 700, 420, 1280), fill='#132b3a')
    d.text((90, 48), s['kicker'], font=font(48), fill='#06111f')
    y = 205
    for line in wrap(d, s['title'], font(82), 1200):
        d.text((90, y), line, font=font(82), fill='#ffffff')
        y += 100
    y += 10
    for line in wrap(d, s['subtitle'], font(42), 1230):
        d.text((94, y), line, font=font(42), fill='#dbe7ff')
        y += 58
    rounded(d, (1260, 250, 1810, 870), fill='#f8fafc', outline=s['accent'], width=5, r=38)
    d.text((1310, 295), '課堂產出', font=font(54), fill='#0b1020')
    card_lines = ['AI 回答樣本', '4 格評分規準', '學生互評理由', '班級版修正版']
    cy = 390
    for cl in card_lines:
        d.ellipse((1310, cy + 8, 1346, cy + 44), fill=s['accent'])
        d.text((1365, cy), cl, font=font(40), fill='#111827')
        cy += 95
    by = 620
    for b in s['bullets']:
        rounded(d, (105, by - 12, 1180, by + 58), fill='#111a33', outline='#26365f', width=2, r=18)
        d.text((130, by), '•', font=font(44), fill=s['accent'])
        for k, line in enumerate(wrap(d, b, font(36), 930)):
            d.text((178, by + k * 44), line, font=font(36), fill='#f2f6ff')
        by += 92
    d.text((90, 1010), '盧老師 × AI 物理教學｜storyboard v1', font=font(32), fill='#9fb0d0')
    img.save(SLIDES / f'slide_{i:02d}.png')

def render_contact_sheet():
    thumb_w, thumb_h = 576, 324
    sheet = Image.new('RGB', (1920, 1080), '#eef2f7')
    d = ImageDraw.Draw(sheet)
    d.text((50, 30), 'AI 回答評分規準活動｜5 張 16:9 storyboard contact sheet', font=font(42), fill='#111827')
    positions = [(50, 110), (672, 110), (1294, 110), (360, 570), (982, 570)]
    for idx, pos in enumerate(positions, 1):
        im = Image.open(SLIDES / f'slide_{idx:02d}.png').resize((thumb_w, thumb_h))
        sheet.paste(im, pos)
        d.text((pos[0], pos[1] + thumb_h + 10), f'slide {idx:02d}', font=font(26), fill='#374151')
    sheet.save(CHECKS / 'contact_sheet.png')

if __name__ == '__main__':
    for idx, slide in enumerate(SLIDE_DATA, 1):
        render_slide(idx, slide)
    render_contact_sheet()
    print(f'Rendered 5 slides and contact sheet under {BASE}')
