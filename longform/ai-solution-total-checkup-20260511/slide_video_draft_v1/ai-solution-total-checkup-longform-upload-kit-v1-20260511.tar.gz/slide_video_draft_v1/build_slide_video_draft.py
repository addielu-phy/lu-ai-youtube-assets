#!/usr/bin/env python3
from __future__ import annotations
import json, math, subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-solution-total-checkup-20260511')
OUT = BASE / 'slide_video_draft_v1'
SLIDES = [BASE / 'slides' / f'slide_{i:02d}.png' for i in range(1, 6)]
AUDIO = OUT / 'narration_edge_hsiaoyu.mp3'
MP4 = OUT / 'ai-solution-total-checkup-slide-video-draft-v1.mp4'
TITLE = '用一題物理題示範：老師怎麼做 AI 解答總體檢'
SEGMENTS = [
    ('00:00', '開場：不是重算一遍，而是照順序找破口'),
    ('', '第一關：條件有沒有被偷換？'),
    ('', '第二關：圖像與方向先過關'),
    ('', '第三、四關：單位、量級與極端情況'),
    ('', '第五關：結論是否回答原題，並轉成學生工作單'),
]

def run(cmd):
    return subprocess.check_output(cmd, text=True).strip()

def duration(path: Path) -> float:
    return float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)]))

def ts(seconds: float, comma=False):
    ms = int(round((seconds - int(seconds))*1000))
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    sep = ',' if comma else '.'
    return f'{h:02d}:{m:02d}:{sec:02d}{sep}{ms:03d}'

def make_subtitles(total: float):
    weights = [0.16,0.20,0.20,0.24,0.20]
    # normalize and keep a tiny pad so final slide remains visible
    scale = total / sum(weights)
    bounds=[0.0]
    for w in weights:
        bounds.append(bounds[-1] + w*scale)
    titles=[s[1] for s in SEGMENTS]
    vtt=['WEBVTT','']
    srt=[]
    for i,title in enumerate(titles, start=1):
        start=bounds[i-1]
        end=min(bounds[i], total)
        vtt += [f'{ts(start)} --> {ts(end)}', title, '']
        srt += [str(i), f'{ts(start, True)} --> {ts(end, True)}', title, '']
    (OUT/'narration_edge_hsiaoyu.vtt').write_text('\n'.join(vtt), encoding='utf-8')
    (OUT/'narration_edge_hsiaoyu.srt').write_text('\n'.join(srt), encoding='utf-8')
    return [bounds[i]-bounds[i-1] for i in range(1,6)], bounds

def make_concat(durs):
    lines=[]
    for slide,dur in zip(SLIDES,durs):
        lines.append(f"file '{slide}'")
        lines.append(f'duration {dur:.3f}')
    lines.append(f"file '{SLIDES[-1]}'")
    (OUT/'slides.ffconcat').write_text('\n'.join(lines)+'\n', encoding='utf-8')

def make_contact_sheet():
    frames_dir = OUT/'check_frames'
    frames_dir.mkdir(exist_ok=True)
    # frames extracted by ffmpeg outside this script if MP4 exists
    imgs=[]
    for p in sorted(frames_dir.glob('frame_*.png'))[:5]:
        im=Image.open(p).convert('RGB').resize((480,270))
        imgs.append((p.name, im))
    if not imgs:
        imgs=[(p.name, Image.open(p).convert('RGB').resize((480,270))) for p in SLIDES]
    W,H=1600,980
    sheet=Image.new('RGB',(W,H),(245,242,234))
    draw=ImageDraw.Draw(sheet)
    font_path='/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
    font=ImageFont.truetype(font_path,28)
    title_font=ImageFont.truetype(font_path,38)
    draw.text((50,28),'AI 解答總體檢｜slide-video QA contact sheet',font=title_font,fill=(32,45,62))
    coords=[(50,100),(560,100),(1070,100),(300,520),(810,520)]
    for (name,im),(x,y) in zip(imgs,coords):
        sheet.paste(im,(x,y))
        draw.rectangle([x,y,x+480,y+270],outline=(32,45,62),width=3)
        draw.text((x,y+285),name,font=font,fill=(32,45,62))
    out=OUT/'checks'
    out.mkdir(exist_ok=True)
    sheet.save(out/'contact_sheet_slide_video_v1.png')

def main():
    OUT.mkdir(exist_ok=True)
    if not AUDIO.exists():
        raise SystemExit(f'Missing audio: {AUDIO}')
    total=duration(AUDIO)
    durs,bounds=make_subtitles(total)
    make_concat(durs)
    cmd=[
        'ffmpeg','-y','-hide_banner','-loglevel','error',
        '-f','concat','-safe','0','-i',str(OUT/'slides.ffconcat'),
        '-i',str(AUDIO),'-vf','fps=30,format=yuv420p',
        '-c:v','libx264','-preset','veryfast','-crf','20',
        '-c:a','aac','-b:a','128k','-shortest',str(MP4)
    ]
    subprocess.check_call(cmd)
    frames=OUT/'check_frames'; frames.mkdir(exist_ok=True)
    # sample at 10%, 30%, 50%, 70%, 90%
    for idx,pct in enumerate([0.10,0.30,0.50,0.70,0.90], start=1):
        subprocess.check_call(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',f'{total*pct:.3f}','-i',str(MP4),'-frames:v','1',str(frames/f'frame_{idx:02d}.png')])
    make_contact_sheet()
    verification={}
    for p in SLIDES + sorted(frames.glob('frame_*.png')) + [OUT/'checks/contact_sheet_slide_video_v1.png']:
        im=Image.open(p)
        verification[str(p.relative_to(BASE))]={'size': list(im.size), 'mode': im.mode}
    manifest={
        'title': TITLE,
        'slug':'ai-solution-total-checkup-20260511',
        'format':'longform slide-video draft v1',
        'video': str(MP4.relative_to(BASE)),
        'audio': str(AUDIO.relative_to(BASE)),
        'narration_text':'slide_video_draft_v1/narration_zh_tw.txt',
        'subtitles':['slide_video_draft_v1/narration_edge_hsiaoyu.vtt','slide_video_draft_v1/narration_edge_hsiaoyu.srt'],
        'ffconcat':'slide_video_draft_v1/slides.ffconcat',
        'check_frames':[str(p.relative_to(BASE)) for p in sorted(frames.glob('frame_*.png'))],
        'contact_sheet':'slide_video_draft_v1/checks/contact_sheet_slide_video_v1.png',
        'duration_seconds': round(duration(MP4),3),
        'verification': verification,
        'next_auto_push':'若 YouTube 登入仍未完成，將教師檢查表講義草稿擴成正式可分享講義／Google Docs-ready handout；若已完成登入，優先上傳第一季首批 Shorts。'
    }
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    readme=f'''# AI 解答總體檢｜slide-video draft v1\n\n狀態：已由 storyboard 擴成長片本機草稿。\n\n## 檔案\n- 影片：`{MP4.relative_to(BASE)}`\n- 旁白：`slide_video_draft_v1/narration_edge_hsiaoyu.mp3`\n- 旁白全文：`slide_video_draft_v1/narration_zh_tw.txt`\n- 字幕：`slide_video_draft_v1/narration_edge_hsiaoyu.vtt`、`slide_video_draft_v1/narration_edge_hsiaoyu.srt`\n- 抽幀：`slide_video_draft_v1/check_frames/`\n- QA contact sheet：`slide_video_draft_v1/checks/contact_sheet_slide_video_v1.png`\n- manifest：`slide_video_draft_v1/manifest.json`\n\n## 驗證\n- ffprobe：{round(duration(MP4),3)} 秒，1920×1080，H.264 + AAC。\n- PIL：抽幀與 contact sheet 已寫入 manifest。\n- 視覺 QA：待本次巡視用 vision 檢查 contact sheet。\n\n## 下一個可自動推進項目\n若 YouTube 登入仍未完成，將教師檢查表講義草稿擴成正式可分享講義／Google Docs-ready handout；若已完成登入，優先上傳第一季首批 Shorts。\n'''
    (OUT/'README.md').write_text(readme,encoding='utf-8')
    print(json.dumps({'video':str(MP4),'duration':duration(MP4),'manifest':str(OUT/'manifest.json')},ensure_ascii=False))
if __name__=='__main__':
    main()
