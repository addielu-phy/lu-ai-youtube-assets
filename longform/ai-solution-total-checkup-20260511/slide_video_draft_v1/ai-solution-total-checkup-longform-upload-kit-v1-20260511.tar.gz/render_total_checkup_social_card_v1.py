from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import json

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-solution-total-checkup-20260511')
OUT = BASE / 'social-assets'
OUT.mkdir(parents=True, exist_ok=True)
W, H = 1080, 1920
S = 2
CANVAS = (W*S, H*S)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size):
    return ImageFont.truetype(FONT, size*S)

def rounded_rect(draw, xy, r, fill, outline=None, width=1):
    xy = tuple(int(v*S) for v in xy)
    draw.rounded_rectangle(xy, radius=int(r*S), fill=fill, outline=outline, width=max(1, int(width*S)))

def text_center(draw, box, text, fnt, fill, spacing=8, stroke_fill=None, stroke_width=0):
    x1,y1,x2,y2 = [v*S for v in box]
    lines = text.split('\n')
    metrics=[]
    total=0
    for line in lines:
        b=draw.textbbox((0,0), line, font=fnt, stroke_width=stroke_width)
        w=b[2]-b[0]; h=b[3]-b[1]
        metrics.append((line,w,h)); total += h
    total += max(0, len(lines)-1)*spacing*S
    y = y1 + (y2-y1-total)/2
    for line,w,h in metrics:
        x = x1 + (x2-x1-w)/2
        draw.text((x,y), line, font=fnt, fill=fill, stroke_width=stroke_width, stroke_fill=stroke_fill)
        y += h + spacing*S

img = Image.new('RGB', CANVAS, '#07111f')
d = ImageDraw.Draw(img)
# background gradient
for y in range(CANVAS[1]):
    t = y / CANVAS[1]
    r = int(5 + 14*t); g = int(14 + 26*t); b = int(31 + 42*t)
    d.line([(0,y),(CANVAS[0],y)], fill=(r,g,b))
# glows
for cx, cy, color, rad in [(210,240,(64,214,240),260),(920,430,(255,181,75),330),(760,1450,(89,238,180),330)]:
    layer = Image.new('RGBA', CANVAS, (0,0,0,0)); ld=ImageDraw.Draw(layer)
    ld.ellipse(((cx-rad)*S,(cy-rad)*S,(cx+rad)*S,(cy+rad)*S), fill=color+(58,))
    layer = layer.filter(ImageFilter.GaussianBlur(95*S))
    img = Image.alpha_composite(img.convert('RGBA'), layer).convert('RGB'); d=ImageDraw.Draw(img)
# subtle grid
for x in range(80, 1080, 160):
    d.line([(x*S,0),(x*S,H*S)], fill=(255,255,255,11), width=S)
for y in range(120, 1920, 160):
    d.line([(0,y*S),(W*S,y*S)], fill=(255,255,255,9), width=S)
# top chip
rounded_rect(d, (70,78,455,142), 24, (15,33,56), (96,224,240), 2)
d.text((96*S,96*S), 'AI 物理解答審稿', font=font(28), fill=(170,239,247))
# main title
text_center(d, (70,168,1010,405), 'AI 解答\n總體檢', font(98), (255,229,105), spacing=16, stroke_width=3*S, stroke_fill=(0,0,0))
d.text((128*S,426*S), '五關找破口，不是重算一遍', font=font(42), fill=(236,246,255))
# central card
rounded_rect(d, (78,520,1002,1668), 44, (13,25,43), (91,125,160), 2)
rounded_rect(d, (122,570,958,666), 28, (20,45,72), (96,220,238), 2)
d.text((156*S,596*S), '拿到 AI 解答，先照順序檢查', font=font(41), fill=(255,255,255))
items = [
    ('1', '條件', '有沒有偷換、漏掉或新增？', '#ff6b6b'),
    ('2', '圖像／方向', '箭頭與受力圖有沒有來源？', '#ffd166'),
    ('3', '單位', '等式左右與答案的單位是否一致？', '#4cc9f0'),
    ('4', '量級', '結果符合真實世界與極端情況嗎？', '#80ed99'),
    ('5', '結論', '最後一句真的回答原題嗎？', '#c77dff'),
]
y = 718
for num, title, body, hexcol in items:
    rgb = tuple(int(hexcol[i:i+2],16) for i in (1,3,5))
    rounded_rect(d, (128,y,952,y+145), 28, (18,36,58), rgb, 4)
    d.ellipse((162*S,(y+31)*S,232*S,(y+101)*S), fill=rgb, outline=(255,255,255), width=3*S)
    text_center(d, (162,y+31,232,y+101), num, font(38), (6,14,26), spacing=0)
    d.text((264*S,(y+23)*S), title, font=font(44), fill=(255,255,255))
    d.text((264*S,(y+84)*S), body, font=font(29), fill=(212,229,242))
    y += 166
# CTA
rounded_rect(d, (110,1540,970,1645), 28, (255,226,88), None, 1)
text_center(d, (130,1544,950,1644), '讓學生找證據、說理由、標出需要老師確認的地方', font(30), (8,17,31), spacing=2)
rounded_rect(d, (70,1700,1010,1810), 30, (7,17,31), (74,226,239), 2)
d.text((105*S,1726*S), '可搭配長片：AI 解答總體檢', font=font(31), fill=(196,240,246))
d.text((105*S,1768*S), '盧老師 × AI 物理教學', font=font(26), fill=(142,165,190))
img = img.resize((W,H), Image.Resampling.LANCZOS)
out = OUT / 'ai-solution-total-checkup-social-card-v1.png'
img.save(out)
manifest = {
    'asset': str(out),
    'size': [W,H],
    'mode': 'RGB',
    'purpose': '1080x1920 Shorts cover / community post card derived from AI solution total checkup handout',
    'text': ['AI 解答總體檢','五關找破口','條件','圖像／方向','單位','量級','結論'],
    'source': 'ai-solution-total-checkup-shareable-handout-v1.md',
    'font': FONT,
}
(OUT/'ai-solution-total-checkup-social-card-v1-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(out)
