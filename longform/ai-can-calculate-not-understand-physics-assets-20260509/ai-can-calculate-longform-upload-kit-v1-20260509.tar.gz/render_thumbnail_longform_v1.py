
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math
BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-can-calculate-not-understand-physics-assets-20260509')
OUT = BASE / 'thumbnail_longform_ai_understands_physics_v2.png'
W, H = 1280, 720
S = 2
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
def font(size): return ImageFont.truetype(FONT, size*S)
YELLOW=(255,222,89); CYAN=(57,222,255); VIOLET=(150,94,255); RED=(255,65,82); WHITE=(246,249,255); MUTED=(160,178,205)
BG1=(7,10,22); BG2=(16,24,52); PANEL=(18,28,60,230)
img = Image.new('RGB',(W*S,H*S),BG1)
pix=img.load()
for y in range(H*S):
    for x in range(W*S):
        t=(x/(W*S)*0.65+y/(H*S)*0.35)
        pix[x,y]=tuple(int(BG1[i]*(1-t)+BG2[i]*t) for i in range(3))
canvas=img.convert('RGBA')
glow=Image.new('RGBA',canvas.size,(0,0,0,0)); gd=ImageDraw.Draw(glow)
def ell(box, color): gd.ellipse(tuple(int(v*S) for v in box), fill=color)
ell((720,-120,1520,560),(57,222,255,58)); ell((760,330,1450,950),(150,94,255,46)); ell((-260,420,420,900),(255,222,89,30))
canvas=Image.alpha_composite(canvas, glow.filter(ImageFilter.GaussianBlur(42*S)))
d=ImageDraw.Draw(canvas)
def xy(box): return tuple(int(v*S) for v in box)
def txt(pos,s,f,fill,anchor=None,stroke=0,stroke_fill=(0,0,0)):
    d.text((pos[0]*S,pos[1]*S),s,font=f,fill=fill,anchor=anchor,stroke_width=stroke*S,stroke_fill=stroke_fill)
def rounded(box,r,fill,outline=(100,150,210,120),width=2):
    d.rounded_rectangle(xy(box), radius=r*S, fill=fill, outline=outline, width=width*S)
# left dark wash for text
wash=Image.new('RGBA',canvas.size,(0,0,0,0)); wd=ImageDraw.Draw(wash); wd.rounded_rectangle(xy((35,40,690,680)), radius=38*S, fill=(3,7,18,170)); canvas=Image.alpha_composite(canvas,wash); d=ImageDraw.Draw(canvas)
# headline: one question + short hook
rounded((58,52,300,112),22,(255,222,89,32),(255,222,89,145),2)
txt((80,80),'老師一定要問',font(30),YELLOW,anchor='lm')
txt((70,178),'AI 真的',font(94),WHITE,stroke=2,stroke_fill=(0,0,0))
txt((70,296),'懂物理嗎？',font(88),YELLOW,stroke=2,stroke_fill=(0,0,0))
# equation hook
rounded((74,430,460,548),28,(10,18,38,235),(255,222,89,130),3)
txt((267,490),'會算 ≠ 懂',font(58),WHITE,anchor='mm',stroke=1,stroke_fill=(0,0,0))
txt((82,630),'檢查：方向｜單位｜意義',font(34),CYAN)
# right visual blackboard panel
rounded((740,72,1225,645),32,(14,24,50,235),(65,220,255,135),3)
txt((778,116),'AI 解答',font(34),CYAN)
# formula content
for i,line in enumerate(['v = v0 + at','F = ma','方向錯了！']):
    txt((790,190+i*67),line,font(34),WHITE if i<2 else MUTED)
# trajectory axes and object
d.line(xy((805,470,1160,470)),fill=(180,200,230,150),width=3*S)
d.line(xy((835,555,835,360)),fill=(180,200,230,120),width=3*S)
# predicted cyan curve
pts=[]
for k in range(80):
    x=845+k*3.7; y=520-125*math.sin(k/79*math.pi)
    pts.append((int(x*S),int(y*S)))
d.line(pts,fill=CYAN,width=5*S)
# real red arrow/trajectory clash
d.line(xy((1010,410,930,548)),fill=RED,width=9*S)
d.polygon([xy((930,548))[0:2], (958*S,538*S), (940*S,515*S)], fill=RED)
txt((1082,402),'方向？',font(36),YELLOW,anchor='mm',stroke=1,stroke_fill=(0,0,0))
txt((1100,536),'單位？',font(36),YELLOW,anchor='mm',stroke=1,stroke_fill=(0,0,0))
# red X circle
for off in range(0,5):
    d.line(xy((780+off,138,1180+off,604)),fill=(255,65,82,210),width=5*S)
    d.line(xy((1180+off,138,780+off,604)),fill=(255,65,82,210),width=5*S)
# small teacher pointer badge
rounded((650,516,874,642),28,(42,18,32,245),(255,65,82,160),3)
txt((762,556),'老師抓包',font(34),RED,anchor='mm')
txt((762,604),'別只看答案',font(28),WHITE,anchor='mm')
# subtle brand
# downsample
canvas=canvas.convert('RGB').resize((W,H), Image.Resampling.LANCZOS)
canvas.save(OUT, quality=95)
print(OUT)
