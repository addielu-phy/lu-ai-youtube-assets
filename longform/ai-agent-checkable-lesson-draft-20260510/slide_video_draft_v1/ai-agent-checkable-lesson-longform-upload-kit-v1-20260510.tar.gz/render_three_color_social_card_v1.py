from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import json, math, textwrap

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-agent-checkable-lesson-draft-20260510')
OUT = BASE / 'social-assets'
OUT.mkdir(parents=True, exist_ok=True)
W, H = 1080, 1920
S = 2
CANVAS = (W*S, H*S)
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'

def font(size, bold=False):
    return ImageFont.truetype(FONT, size*S)

def rounded_rect(draw, xy, r, fill, outline=None, width=1):
    xy = tuple(int(v*S) for v in xy)
    draw.rounded_rectangle(xy, radius=int(r*S), fill=fill, outline=outline, width=max(1, int(width*S)))

def text_center(draw, box, text, fnt, fill, spacing=8, stroke_fill=None, stroke_width=0):
    x1,y1,x2,y2 = [v*S for v in box]
    lines = text.split('\n')
    heights = []
    widths = []
    for line in lines:
        b = draw.textbbox((0,0), line, font=fnt, stroke_width=stroke_width)
        widths.append(b[2]-b[0]); heights.append(b[3]-b[1])
    total = sum(heights) + (len(lines)-1)*spacing*S
    y = y1 + (y2-y1-total)/2
    for line, h, w in zip(lines, heights, widths):
        x = x1 + (x2-x1-w)/2
        draw.text((x,y), line, font=fnt, fill=fill, stroke_width=stroke_width, stroke_fill=stroke_fill)
        y += h + spacing*S

def wrap_by_chars(s, n):
    out=[]
    for seg in s.split('\n'):
        while len(seg)>n:
            out.append(seg[:n]); seg=seg[n:]
        out.append(seg)
    return '\n'.join(out)

img = Image.new('RGB', CANVAS, '#07111f')
d = ImageDraw.Draw(img)
# background gradient
for y in range(CANVAS[1]):
    t = y / CANVAS[1]
    r = int(6 + 15*t); g = int(14 + 19*t); b = int(28 + 34*t)
    d.line([(0,y),(CANVAS[0],y)], fill=(r,g,b))
# glows
for cx, cy, color, rad in [(200,280,(32,210,230),260),(900,470,(147,96,255),360),(850,1500,(255,210,70),300)]:
    layer = Image.new('RGBA', CANVAS, (0,0,0,0)); ld=ImageDraw.Draw(layer)
    ld.ellipse(((cx-rad)*S,(cy-rad)*S,(cx+rad)*S,(cy+rad)*S), fill=color+(55,))
    layer = layer.filter(ImageFilter.GaussianBlur(100*S))
    img = Image.alpha_composite(img.convert('RGBA'), layer).convert('RGB'); d=ImageDraw.Draw(img)
# border grid lines
for x in range(80, 1080, 160):
    d.line([(x*S,0),(x*S,H*S)], fill=(255,255,255,10), width=1*S)
for y in range(120, 1920, 160):
    d.line([(0,y*S),(W*S,y*S)], fill=(255,255,255,9), width=1*S)
# top chip
rounded_rect(d, (70,80,420,142), 24, (16,32,55), (68,216,235), 2)
d.text((96*S,96*S), 'AI Agent 備課檢查', font=font(28), fill=(160,236,245))
# main title
text_center(d, (70,160,1010,410), '三色筆\n審稿檢查表', font(92), (255,233,120), spacing=18, stroke_width=3*S, stroke_fill=(0,0,0))
d.text((130*S,420*S), 'AI 先交草稿，老師負責把關', font=font(42), fill=(236,246,255))
# document card
rounded_rect(d, (80,520,1000,1680), 44, (13,25,42), (89,121,153), 2)
# document header
rounded_rect(d, (125,570,955,665), 28, (20,45,72), (96,220,238), 2)
d.text((160*S,595*S), '先不要問：能不能直接用？', font=font(44), fill=(255,255,255))
# three color columns
items = [
    ('綠色', '可保留', '符合目標／程度合適', '#22d17c', '保留，標出學習目標'),
    ('黃色', '要改寫', '太抽象／證據不足', '#ffd84d', '改成具體任務或檢核'),
    ('紅色', '不能用', '概念錯／安全個資風險', '#ff5b61', '刪除、重做或查證'),
]
y = 705
for idx, (color_name, title, body, hexcol, action) in enumerate(items):
    rgb = tuple(int(hexcol[i:i+2],16) for i in (1,3,5))
    rounded_rect(d, (130,y,950,y+235), 34, (18,36,58), rgb, 4)
    # color dot
    d.ellipse((166*S,(y+35)*S,236*S,(y+105)*S), fill=rgb, outline=(255,255,255), width=3*S)
    d.text((265*S,(y+28)*S), f'{color_name}｜{title}', font=font(50), fill=(255,255,255))
    d.text((265*S,(y+98)*S), body, font=font(31), fill=(210,226,240), spacing=6*S)
    rounded_rect(d, (235,y+162,920,y+210), 20, (8,19,34), None, 1)
    d.text((265*S,(y+169)*S), action, font=font(27), fill=rgb)
    y += 270
# bottom cta
rounded_rect(d, (110,1532,970,1638), 26, (255,223,83), None, 1)
text_center(d, (130,1538,950,1636), '審稿不是找碴，是把草稿變成能進教室的設計', font(32), (8,17,31), spacing=2)
# footer (kept above platform UI safe area)
rounded_rect(d, (70,1696,1010,1810), 30, (7,17,31), (74,226,239), 2)
d.text((105*S,1724*S), '可搭配長片說明欄：三色筆審稿檢查表', font=font(30), fill=(196,240,246))
d.text((105*S,1766*S), '盧老師 × AI 物理備課室', font=font(26), fill=(142,165,190))
# save
img = img.resize((W,H), Image.Resampling.LANCZOS)
out = OUT / 'three-color-review-social-card-v1.png'
img.save(out)
manifest = {
    'asset': str(out),
    'size': [W,H],
    'purpose': '1080x1920 Shorts cover / community post card derived from the three-color review handout',
    'text': ['三色筆審稿檢查表','AI 先交草稿，老師負責把關','綠色可保留','黃色要改寫','紅色不能用'],
    'source': 'three-color-review-shareable-handout-v1.md',
    'font': FONT,
}
(OUT/'three-color-review-social-card-v1-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(out)
