#!/usr/bin/env python3
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import json, textwrap, math

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-solution-review-class-activity-20260510')
OUTDIR = BASE / 'social-assets'
OUTDIR.mkdir(parents=True, exist_ok=True)
OUT = OUTDIR / 'ai-solution-review-class-activity-social-card-v1.png'
MANIFEST = OUTDIR / 'ai-solution-review-class-activity-social-card-v1-manifest.json'
FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
W, H = 1080, 1920
S = 2
img = Image.new('RGB', (W*S, H*S), (7, 12, 26))
d = ImageDraw.Draw(img)

def sc(v): return int(v*S)
def font(size): return ImageFont.truetype(FONT, sc(size))

def rounded_box(xy, fill, outline=None, width=2, radius=36):
    xy = tuple(sc(v) for v in xy)
    d.rounded_rectangle(xy, radius=sc(radius), fill=fill, outline=outline, width=sc(width))

def text_size(text, f):
    b = d.textbbox((0,0), text, font=f)
    return b[2]-b[0], b[3]-b[1]

def wrap_by_px(text, f, maxw):
    lines=[]
    cur=''
    for ch in text:
        trial=cur+ch
        if text_size(trial, f)[0] <= sc(maxw):
            cur=trial
        else:
            if cur: lines.append(cur)
            cur=ch
    if cur: lines.append(cur)
    return lines

def draw_text_block(x,y,text,f,fill,maxw,spacing=8,anchor=None):
    lines=wrap_by_px(text,f,maxw)
    yy=sc(y)
    for line in lines:
        if anchor=='mm':
            tw,th=text_size(line,f)
            d.text((sc(x)-tw//2,yy),line,font=f,fill=fill)
        else:
            d.text((sc(x),yy),line,font=f,fill=fill)
        yy += f.size + sc(spacing)
    return yy//S

# background glows
for cx, cy, r, color in [(170,260,420,(13,148,255)), (940,430,360,(156,86,255)), (580,1540,520,(12,222,194))]:
    layer=Image.new('RGBA', img.size, (0,0,0,0)); ld=ImageDraw.Draw(layer)
    ld.ellipse((sc(cx-r),sc(cy-r),sc(cx+r),sc(cy+r)), fill=color+(54,))
    layer=layer.filter(ImageFilter.GaussianBlur(sc(95)))
    img=Image.alpha_composite(img.convert('RGBA'), layer).convert('RGB'); d=ImageDraw.Draw(img)

# subtle grid
for x in range(-200, W+220, 120):
    d.line((sc(x),0,sc(x+520),sc(H)), fill=(23,39,68), width=sc(1))
for y in range(120, H, 160):
    d.line((0,sc(y),sc(W),sc(y)), fill=(18,31,55), width=sc(1))

# top chip
rounded_box((70,84,1010,184), fill=(17,30,55), outline=(68,99,148), width=2, radius=34)
d.text((sc(103),sc(112)), '45 分鐘可落地課堂流程', font=font(36), fill=(200,232,255))
d.text((sc(735),sc(112)), '教師 AI 教學', font=font(34), fill=(255,220,110))

# headline
headline_f=font(96)
y=250
for line, col in [('AI 解題，', (255,255,255)), ('學生怎麼審？',(255,222,92))]:
    d.text((sc(72),sc(y)), line, font=headline_f, fill=col)
    y += 108

# central document panel
rounded_box((70,520,1010,1285), fill=(242,247,255), outline=(108,185,255), width=3, radius=46)
d.text((sc(118),sc(570)), '把 AI 錯誤變成討論', font=font(48), fill=(16,30,54))
d.text((sc(120),sc(638)), '不是抓出糗，而是練習用證據判斷', font=font(30), fill=(70,88,116))

roles=[('條件', '題目有沒有被偷換？', (255,91,99)), ('單位', '算式與答案對得上嗎？', (255,184,75)), ('圖像', '方向、斜率合理嗎？', (69,176,255)), ('量級', '結果會不會荒謬？', (94,221,165))]
y0=720
for i,(tag,body,c) in enumerate(roles):
    yy=y0+i*125
    d.rounded_rectangle((sc(118),sc(yy),sc(292),sc(yy+82)), radius=sc(28), fill=c+(255,) if len(c)==4 else c)
    tw,th=text_size(tag,font(42)); d.text((sc(205)-tw//2, sc(yy+17)), tag, font=font(42), fill=(6,12,25))
    d.text((sc(330),sc(yy+7)), body, font=font(36), fill=(22,36,62))
    d.line((sc(330),sc(yy+62),sc(900),sc(yy+62)), fill=(198,211,230), width=sc(2))

# bottom proof cards
rounded_box((70,1340,1010,1730), fill=(14,28,55), outline=(82,123,184), width=2, radius=44)
d.text((sc(118),sc(1388)), '課堂只要三步：', font=font(46), fill=(255,222,92))
steps=[('1', '分組只抓一種錯'), ('2','每組提出一個證據'), ('3','學生改寫可靠說明')]
for i,(num,txt) in enumerate(steps):
    yy=1470+i*75
    d.ellipse((sc(120),sc(yy),sc(170),sc(yy+50)), fill=(36,208,189))
    tw,th=text_size(num,font(28)); d.text((sc(145)-tw//2, sc(yy+8)), num, font=font(28), fill=(5,16,24))
    d.text((sc(195),sc(yy+2)), txt, font=font(36), fill=(230,245,255))

# footer
rounded_box((70,1786,1010,1864), fill=(255,222,92), outline=None, width=0, radius=28)
d.text((sc(112),sc(1807)), '可搭配 45 分鐘活動單／Google Docs 講義', font=font(33), fill=(8,18,35))

# downsample
img = img.resize((W,H), Image.Resampling.LANCZOS)
img.save(OUT)
manifest={
  'asset': str(OUT),
  'size': [W,H],
  'mode': 'RGB',
  'source_project': str(BASE),
  'title': 'AI 解題，學生怎麼審？',
  'subtitle': '45 分鐘課堂流程',
  'font': FONT,
  'created_by': 'scheduled hourly radar autopush',
  'notes': 'Vertical Shorts/community card derived from the longform AI solution review class activity handout.'
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(OUT)
print(MANIFEST)
