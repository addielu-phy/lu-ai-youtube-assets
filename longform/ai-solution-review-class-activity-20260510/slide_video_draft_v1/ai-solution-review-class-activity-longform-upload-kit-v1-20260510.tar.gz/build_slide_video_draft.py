#!/usr/bin/env python3
"""Build a deterministic slide-video draft for the AI solution review class activity longform package."""
from __future__ import annotations
import json, math, os, subprocess, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path('/home/adl/youtube-lu-ai-channel/longform/ai-solution-review-class-activity-20260510')
OUT = BASE / 'slide_video_draft_v1'
SLIDES = [
    BASE / 'slides/01_01_01_hook.png',
    BASE / 'slides/02_02_02_flow.png',
    BASE / 'slides/03_03_03_group_roles.png',
    BASE / 'slides/04_04_04_rubric.png',
    BASE / 'slides/05_05_05_video_plan.png',
]
VOICE = 'zh-TW-HsiaoChenNeural'
RATE = '-8%'

SECTIONS = [
    {
        'title': '開場：把 AI 錯誤變成學生討論',
        'slide': SLIDES[0],
        'text': '''各位老師，這支影片想回答一個很實際的問題：如果學生已經會把題目丟給 AI，我們能不能把這件事變成一堂可控制、可評量、又真的有物理思考的課？今天的主題是，一堂課怎麼安排 AI 解題審稿活動。核心不是叫學生相信 AI，也不是禁止 AI，而是讓學生練習看證據。當 AI 的解答寫得很順、步驟看起來很完整時，我們先不急著說對或錯，而是問：條件有沒有被換掉？單位有沒有對齊？圖像跟方向是否合理？量級會不會離譜？這堂課的目標，就是把 AI 可能犯的錯，轉成學生可以討論、可以圈證據、可以改寫的學習任務。'''
    },
    {
        'title': '45 分鐘四段式流程',
        'slide': SLIDES[1],
        'text': '''我會把整堂課切成四段。第一段，零到五分鐘，全班一起看同一段 AI 解題。老師不用一開始就講解，而是請學生先標出看起來太順、太快、或跳步的位置。第二段，五到十五分鐘，小組分工審稿。有人只看條件，有人只看單位，有人只看圖像和方向，有人只看量級。第三段，十五到三十分鐘，每組提出一個證據。注意，這裡不要求學生完整重算整題，先練習拿得出檢查理由。第四段，三十到四十五分鐘，全班把證據整理成一份簡短的 AI 解題審稿規準，最後用 exit ticket，請每位學生改寫一句更可靠的解題說明。這樣一堂課會有節奏，也比較不會變成自由使用 AI 的混亂時間。'''
    },
    {
        'title': '分組角色：每組只抓一種錯',
        'slide': SLIDES[2],
        'text': '''這個活動最重要的設計，是不要叫每個小組什麼都檢查。初學者如果同時要檢查條件、公式、單位、圖像、量級，很容易最後只剩下重算答案。所以我建議每組只負責一種審稿視角。條件組檢查題目已知量有沒有被 AI 偷換；單位組檢查式子前後單位是否一致；圖像組檢查方向、受力圖、運動圖是否支持文字；量級組檢查答案是否落在合理範圍。每組只要交出一條證據句，例如：因為題目說水平面無摩擦，但 AI 在第二步加入摩擦力，所以這一步不可信。這種證據句，比單純說 AI 錯了，更接近我們希望學生學會的科學論證。'''
    },
    {
        'title': '評量看證據，不看有沒有用 AI',
        'slide': SLIDES[3],
        'text': '''評量規準也要先講清楚。這堂課不是評量學生有沒有使用 AI，而是評量學生能不能提出可檢查的證據。我會用三個層次。第一層，能指出可疑位置，例如某一步驟跳太快。第二層，能說出檢查依據，例如單位不一致，或圖像方向不支持結論。第三層，能改寫成更可靠的解題說明，例如補上限制條件、改正單位，或把不確定的地方標註出來。老師在巡堂時，不必每組都講很多，只要追問兩句：你的證據在哪裡？如果這一步錯了，會影響後面哪個結論？這兩句追問，可以把學生從找答案拉回到做判斷。'''
    },
    {
        'title': '收束：可直接拿去拍成長片',
        'slide': SLIDES[4],
        'text': '''如果要把這個活動做成影片或教師研習材料，長片可以分成五段：先說明為什麼 AI 解題需要審稿，再示範一段 AI 解題，接著介紹四段式課堂流程，然後展示分組角色卡與評量規準，最後給老師一份可複製的課堂小任務。真正上課時，請先選一題公開、可討論、錯誤不會太隱晦的物理題，並避免放入學生個資或未授權作品。這支影片的 CTA 可以很簡單：下一次你看到 AI 解題很漂亮時，先不要問答案對不對，先請學生圈出一條證據。把 AI 變成被審稿的文本，學生才會從使用工具，往理解物理前進。'''
    },
]

def run(cmd):
    print('+', ' '.join(map(str, cmd)))
    subprocess.run([str(c) for c in cmd], check=True)

def fmt_ts(sec, comma=False):
    ms = int(round((sec - math.floor(sec)) * 1000))
    s = int(math.floor(sec))
    h, rem = divmod(s, 3600)
    m, ss = divmod(rem, 60)
    sep = ',' if comma else '.'
    return f'{h:02d}:{m:02d}:{ss:02d}{sep}{ms:03d}'

def audio_duration(path: Path) -> float:
    out = subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)], text=True)
    return float(out.strip())

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'audio').mkdir(exist_ok=True)
    (OUT / 'segments').mkdir(exist_ok=True)
    (OUT / 'checks').mkdir(exist_ok=True)
    narration_lines = []
    cues = []
    cursor = 0.0
    segment_paths = []
    for idx, sec in enumerate(SECTIONS, 1):
        txt_path = OUT / f'narration_{idx:02d}.txt'
        txt_path.write_text(sec['text'].strip() + '\n', encoding='utf-8')
        narration_lines.append(f"## {idx}. {sec['title']}\n\n{sec['text'].strip()}\n")
        mp3 = OUT / 'audio' / f'narration_{idx:02d}.mp3'
        if not mp3.exists():
            run(['edge-tts','--voice',VOICE,f'--rate={RATE}','--text',sec['text'].strip(),'--write-media',mp3])
        dur = audio_duration(mp3) + 0.35
        start, end = cursor, cursor + dur
        cues.append((idx, sec['title'], start, end, sec['text'].strip()))
        cursor = end
        seg = OUT / 'segments' / f'segment_{idx:02d}.mp4'
        run(['ffmpeg','-y','-loop','1','-i',sec['slide'],'-i',mp3,'-t',f'{dur:.3f}','-vf','scale=1920:1080,format=yuv420p','-r','30','-c:v','libx264','-preset','veryfast','-crf','20','-c:a','aac','-b:a','128k','-shortest',seg])
        segment_paths.append(seg)
    (OUT / 'narration_full_text.md').write_text('# 旁白全文｜AI 解題審稿活動\n\n' + '\n'.join(narration_lines), encoding='utf-8')
    srt = []
    vtt = ['WEBVTT\n']
    for idx, title, start, end, text in cues:
        cue_text = title + '\n' + textwrap.shorten(text, width=120, placeholder='…')
        srt += [str(idx), f'{fmt_ts(start, True)} --> {fmt_ts(end, True)}', cue_text, '']
        vtt += [f'{fmt_ts(start)} --> {fmt_ts(end)}', cue_text, '']
    (OUT / 'narration.srt').write_text('\n'.join(srt), encoding='utf-8')
    (OUT / 'narration.vtt').write_text('\n'.join(vtt), encoding='utf-8')
    concat = OUT / 'ffconcat.txt'
    concat.write_text('\n'.join([f"file '{p}'" for p in segment_paths]) + '\n', encoding='utf-8')
    final = OUT / 'ai-solution-review-class-activity-slide-video-draft-v1.mp4'
    run(['ffmpeg','-y','-f','concat','-safe','0','-i',concat,'-c','copy',final])
    # Extract check frames at the midpoint of each cue.
    total_dur = audio_duration(final)
    frame_paths = []
    for idx, title, start, end, text in cues:
        t = (start + end) / 2
        frame = OUT / 'checks' / f'frame_{idx:02d}.png'
        run(['ffmpeg','-y','-ss',f'{t:.3f}','-i',final,'-frames:v','1',frame])
        frame_paths.append(frame)
    # Contact sheet 3+2.
    thumbs = []
    for p in frame_paths:
        im = Image.open(p).convert('RGB')
        im.thumbnail((560,315))
        thumbs.append(im.copy())
    W,H = 1800, 980
    sheet = Image.new('RGB',(W,H),(246,248,252))
    positions = [(40,60),(620,60),(1200,60),(330,520),(910,520)]
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 28)
    except Exception:
        font = ImageFont.load_default()
    draw.text((40,18),'AI 解題審稿活動｜slide-video 抽幀 QA（3+2）',fill=(20,30,45),font=font)
    for i,(im,pos) in enumerate(zip(thumbs,positions),1):
        sheet.paste(im,pos)
        draw.text((pos[0],pos[1]+325),f'Frame {i}',fill=(20,30,45),font=font)
    sheet_path = OUT / 'checks' / 'contact_sheet_frames.png'
    sheet.save(sheet_path)
    manifest = {
        'project': 'ai-solution-review-class-activity-20260510',
        'created_by': 'scheduled hourly radar autopush',
        'voice': VOICE,
        'rate': RATE,
        'video': str(final.relative_to(BASE)),
        'duration_seconds': round(total_dur,3),
        'resolution': '1920x1080',
        'sections': [{'title': t, 'start': round(s,3), 'end': round(e,3)} for _,t,s,e,_ in cues],
        'checks': [str((OUT/'checks'/'contact_sheet_frames.png').relative_to(BASE))],
    }
    (OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f'''# Slide-video draft v1｜一堂課怎麼安排 AI 解題審稿活動

狀態：已由 storyboard 擴成本機 16:9 slide-video 草稿，尚未上傳 YouTube。

## 主要輸出
- 影片：`ai-solution-review-class-activity-slide-video-draft-v1.mp4`
- 旁白全文：`narration_full_text.md`
- 字幕：`narration.srt`、`narration.vtt`
- 抽幀 QA：`checks/contact_sheet_frames.png`
- 建置腳本：`build_slide_video_draft.py`

## 規格
- 解析度：1920×1080
- 長度：{total_dur:.1f} 秒
- 語音：{VOICE}，rate {RATE}
- 內容：5 段 slide-video，對應原 storyboard 5 張卡。

## 已驗證
- `ffprobe` 可讀影片規格。
- 已抽出 5 張代表畫面並產生 contact sheet 供視覺 QA。
- 壓縮包可用 `tar -tzf` 檢查內容。

## 下一步
- 下一個可自動推進項目：製作長片 YouTube upload kit（標題、說明欄、章節時間、置頂留言、縮圖方向）與輕量上架交接包。
- 人工卡點：YouTube 頻道建立／上傳仍需已登入 Google / YouTube 的可操作環境。
'''
    (OUT / 'README.md').write_text(readme, encoding='utf-8')
    archive = BASE / 'ai-solution-review-class-activity-slide-video-draft-v1-20260510.tar.gz'
    run(['tar','-czf',archive,'-C',str(BASE),'slide_video_draft_v1'])
    print(json.dumps({'final': str(final), 'duration': total_dur, 'archive': str(archive), 'contact_sheet': str(sheet_path)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
